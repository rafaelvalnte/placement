import java.awt.Dimension;


public class Solution {
	
	private Dimension dim;
	private Dimension leftDim;
	private Dimension rightDim;
	private String type; //saber se � corte vertical ou horizontal
	private int state = 0; //este atributo serve para saber em que fase do algoritmo de compacta��o se criou a solu��o n�o dominada: Juntar em Ordem(valor 0), 1 Atualizar(valor 1), 2 Atualizar (valor 2)ou 3 Atualizar(valor 3)
	
	public Solution() {
		
	}

	public Dimension getDim() {
		return dim;
	}

	public void setDim(Dimension dim) {
		this.dim = dim;
	}

	public Dimension getLeftSon() {
		return leftDim;
	}

	public void setLeftSon(Dimension leftDim) {
		this.leftDim = leftDim;
	}

	public Dimension getRightSon() {
		return rightDim;
	}

	public void setRightSon(Dimension rightDim) {
		this.rightDim = rightDim;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
