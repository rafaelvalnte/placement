import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



public class Gui extends JFrame{
	
	/**
	 * 
	 */
	private static final String OPT_AREA = "�rea";
	private static final String OPT_SEMI_PERIMETER = "Semiperimetro";
	private static final long serialVersionUID = 1L;
	private Cromossoma crom;
	private int placeInTree = 0; //saber em que n�vel estamos na �rvore --> 0 == root, 1 == primeiro n�vel, 2 == segundo n�vel, ...
	private ArrayList<Solution> listToFindBasic;
	private ArrayList<Dimension> finalListToPaint;
	private static final String[] OPTIONS = { OPT_AREA, OPT_SEMI_PERIMETER };
	private String value;
	private Point whereToStartPainting;

	
	public Gui() {
		finalListToPaint = new ArrayList<>();
		whereToStartPainting = new Point(0,0);
		value = requestSelection("Menu", OPTIONS);
		add(new NewPanel());
	}

	public String getValue() {
		return value;
	}

	public Cromossoma getCrom() {
		return crom;
	}

	public static String requestSelection(String name, String[] options) {
		String option = ((String) JOptionPane.showInputDialog(null,
				"Escolha uma op��o", name, JOptionPane.QUESTION_MESSAGE,
				null, options, options[0]));
		return option;
	}
	
	public void setCrom(Cromossoma crom) {
		this.crom = crom;
	}
	
	public ArrayList<Solution> getListToPaint() {
		return listToFindBasic;
	}

	public void setListToPaint(ArrayList<Solution> a) {
		listToFindBasic = a;
	}

	public void computeSolutionToPaint() {
		Dimension min = crom.getMinimumDimension();
		for(int i = 0; i<listToFindBasic.size(); i++) {
			//se estivermos na dimens�o mais pequena, ou seja, que gerou o melhor fitness
			if(listToFindBasic.get(i).getDim().getHeight() == min.getHeight() && listToFindBasic.get(i).getDim().getWidth() == min.getWidth()) { 
				Solution a = listToFindBasic.get(i);
				findRectangleToPaint(a);
			}
		}		
	}


	private void findRectangleToPaint(Solution a) {
		boolean last = false;
		Dimension left = a.getLeftSon();
		Dimension right = a.getRightSon();
		for(int i=0; i<crom.getListOfAllDimensions().size(); i++) {
			if(crom.getListOfAllDimensions().get(i).contains(left)) {
				last = true;
				break;
			}
		}
		if(last) {
//			if(a.getState() == 0) { //ambos os b�sicos em p�
//				
//			} else {
//				if(a.getState() == 1) { //ambos os b�sicos deitados
//					Dimension leftR = new Dimension();
//					leftR.setSize(left.getHeight(), left.getWidth());
//					Dimension rightR = new Dimension();
//					rightR.setSize(right.getHeight(), right.getWidth());
//					finalListToPaint.add(leftR);
//					finalListToPaint.add(rightR);
//				} else {
//					if(a.getState() == 2) { //primeiro b�sico em p� e segundo deitado
//						finalListToPaint.add(left);
//						Dimension rightR = new Dimension();
//						rightR.setSize(right.getHeight(), right.getWidth());
//						finalListToPaint.add(rightR);
//					} else {
//						if(a.getState() == 3) { //primeiro b�sico deitado e segundo em p�
//							Dimension leftR = new Dimension();
//							leftR.setSize(left.getHeight(), left.getWidth());
//							finalListToPaint.add(leftR);
//							finalListToPaint.add(right);
//						}
//					}
//				}
//			}
			finalListToPaint.add(left);
			finalListToPaint.add(right);
		}
		if(!last) {
			for(int i=0; i<listToFindBasic.size(); i++) {
				if(listToFindBasic.get(i).getDim().getHeight() == left.getHeight() && listToFindBasic.get(i).getDim().getWidth() == left.getWidth()) {
					findRectangleToPaint(listToFindBasic.get(i));
				}
			}
			for(int i=0; i<listToFindBasic.size(); i++) {
				if(listToFindBasic.get(i).getDim().getHeight() == right.getHeight() && listToFindBasic.get(i).getDim().getWidth() == right.getWidth()) {
					findRectangleToPaint(listToFindBasic.get(i));
				}
			}
		}
	}

	public Point getWhereToStartPainting() {
		return whereToStartPainting;
	}

	public void setWhereToStartPainting(Point whereToStartPainting) {
		this.whereToStartPainting = whereToStartPainting;
	}


	public ArrayList<Dimension> getFinalListToPaint() {
		return finalListToPaint;
	}

	public void setFinalListToPaint(ArrayList<Dimension> finalListToPaint) {
		this.finalListToPaint = finalListToPaint;
	}


	class NewPanel extends JPanel {
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
//			g.drawLine(0, 0, 50, 50);
	//		Color color = g.getColor();
//			System.out.println(color.getBlue() + " " + color.getGreen() + " " + color.getRed());
//			for (int i = 0; i<listaComp.size(); i++) {
//				if (g.)
//				g.setColor(listaComp.get(i).getColor());
//			    g.fillRect (a, (b-listaComp.get(i).getHeight()), listaComp.get(i).getWidth(), listaComp.get(i).getHeight());
//			    refreshReferencePoint();
		}
	}
	
	
}
