import java.awt.Dimension;
import java.util.ArrayList;


public class Cromossoma {
	
	private ArrayList<Rectangle> cromossoma;
	private ArrayList<ArrayList<Dimension>> listOfAllDimensions; //lista d[] do anexo
	private ArrayList<Dimension> listOfSolutions; //lista c[] do anexo
	private ArrayList<Solution> listToPaint;
	private double fitness;
	private Dimension minimumDimension;
	
	public Cromossoma() {
		listToPaint = new ArrayList<>();
		cromossoma = new ArrayList<>();
		listOfAllDimensions = new ArrayList<>();
		listOfSolutions = new ArrayList<>();
	}
	
	public void fillListOfAllDimensions() { //colocar em cada �ndice de d[i], a lista com os 2 pares de dimens�es poss�veis para cada rect�ngulo 
		for (int a=(cromossoma.size()/2); a<cromossoma.size(); a++) {
			listOfAllDimensions.add(cromossoma.get(a).getListOfDimensions());
		}
	}

	public ArrayList<Rectangle> getCromossoma() {
		return cromossoma;
	}

	public void setCromossoma(ArrayList<Rectangle> cromossoma) {
		this.cromossoma = cromossoma;
	}

	public ArrayList<ArrayList<Dimension>> getListOfAllDimensions() {
		return listOfAllDimensions;
	}

	public void setListOfAllDimensions(ArrayList<ArrayList<Dimension>> listOfAllDimensions) {
		this.listOfAllDimensions = listOfAllDimensions;
	}

	public ArrayList<Dimension> getListOfSolutions() {
		return listOfSolutions;
	}

	public void setListOfSolutions() {
		listOfSolutions = cromossoma.get(0).getListOfDimensions();
	}

	public void fillListOfNonDominatedSolutions() {
		for (int a=((cromossoma.size()/2)-1); a>=0; a--) {
			Rectangle cut = cromossoma.get(a);
			if(cut.getTipo() == "V") { //corte vertical
				//como em Java o primeiro elemento de um array tem o index 0, i e j s�o inicializados com esse valor
				int i = 0;
				int j = 0;
				Rectangle firstSon = cromossoma.get((a*2)+1);
				Rectangle secondSon = cromossoma.get((a*2)+2);
				// k e m s�o o �ltimo index de um array
				int k = firstSon.getListOfDimensions().size()-1;
				int m = secondSon.getListOfDimensions().size()-1;
				while(i <= k && j <= m) { //Juntar em ordem
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>(); //os elementos que dominados n�o podem ser imediatamente removidos, sen�o existir� um erro IndexOutOfBounds
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(wi+wj,Math.max(hi, hj));
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setType("V");
					sol.setDim(nova);
					sol.setState(0);
					int size = cut.getListOfDimensions().size();
					for (int b=0; b<size; b++) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
							allow = false;
							cut.getListOfDimensions().add(b, nova);
							listToPaint.add(sol);
							break;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
						listToPaint.add(sol);
						cut.getListOfDimensions().add(nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (hi > hj) {
						i++;
					} else {
						if(hi < hj) {
							j++;
						} else {
							i++;
							j++;
						}
					}
				}
				i = k;
				j = m;
				while (i >= 0 && j >= 0) { //primeiro Atualizar
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(hi + hj, Math.max(wi,wj));
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setType("V");
					sol.setDim(nova);
					sol.setState(1);
					int size = cut.getListOfDimensions().size();
					for (int b=0; b<size; b++) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
							allow = false;
							cut.getListOfDimensions().add(b, nova);
							listToPaint.add(sol);
							break;
//							b++;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
						listToPaint.add(sol);
						cut.getListOfDimensions().add(nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (wi > wj) {
						i--;
					} else {
						if(wi < wj) {
							j--;
						} else {
							i--;
							j--;
						}
					}
				}
				i = 0;
				j = m;
				while (i <= k && j >= 0) { //segundo Atualizar
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(hj+ wi, Math.max(hi,wj));
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setType("V");
					sol.setDim(nova);
					sol.setState(2);
					int size = cut.getListOfDimensions().size();
					for (int b=0; b<size; b++) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
							allow = false;
							listToPaint.add(sol);
							cut.getListOfDimensions().add(b, nova);
							break;
//							b++;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
						listToPaint.add(sol);
						cut.getListOfDimensions().add(nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (hi > wj) {
						i++;
					} else {
						if(hi < wj) {
							j--;
						} else {
							i++;
							j--;
						}
					}
				}
				i = k;
				j = 0;
				while (i >= 0 && j <= m) { //terceiro Atualizar
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(hi+ wj, Math.max(wi,hj));
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setType("V");
					sol.setDim(nova);
					sol.setState(3);
					int size = cut.getListOfDimensions().size();
					for (int b=0; b<size; b++) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
							allow = false;
							listToPaint.add(sol);
							cut.getListOfDimensions().add(b, nova);
							break;
//							b++;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
						listToPaint.add(sol);
						cut.getListOfDimensions().add(nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (wi > hj) {
						i--;
					} else {
						if(wi < hj) {
							j++;
						} else {
							i--;
							j++;
						}
					}					
				}
				//garantir que n�o h� duplicados
//				ArrayList<Dimension> dimToDelete = new ArrayList<>();
//				for (int ab=0; ab<cut.getListOfDimensions().size(); ab++) {
//					boolean can = false;
//					Dimension av = cut.getListOfDimensions().get(ab);
//					for (int abc=0; abc<cut.getListOfDimensions().size(); abc++) {
//						if(can) {
//							dimToDelete.add(av);
//						}
//						if(av.equals(cut.getListOfDimensions().get(abc))){
//							can = true;
//						}
//					}
//				}
//				for(int ac=0; ac<dimToDelete.size();ac++) {
//					cut.getListOfDimensions().remove(dimToDelete.get(ac));
//				}
				
			} else { //corte horizontal!!!!!!!!!!!
				int i = 0;
				int j = 0;
				Rectangle firstSon = cromossoma.get((a*2)+1);
				Rectangle secondSon = cromossoma.get((a*2)+2);
				// k e m s�o o �ltimo index de um array
				int k = firstSon.getListOfDimensions().size()-1;
				int m = secondSon.getListOfDimensions().size()-1;
				while(i <= k && j <= m) { //Juntar em ordem
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(Math.max(wi, wj),hi+hj);
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setType("H");
					sol.setDim(nova);
					sol.setState(0);
					int size = cut.getListOfDimensions().size();
					for (int b=size-1; b>=0; b--) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha largura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
							allow = false;
							listToPaint.add(sol);
//							listToPaint.add((b+1), sol);
							cut.getListOfDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
							break;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeiro da lista
						listToPaint.add(0, sol);
						cut.getListOfDimensions().add(0, nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (hi > hj) {
						i++;
					} else {
						if(hi < hj) {
							j++;
						} else {
							i++;
							j++;
						}
					}
				}
				i = k;
				j = m;
				while (i >= 0 && j >= 0) { //primeiro Atualizar
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(Math.max(hi,hj),wi + wj);
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setType("H");
					sol.setDim(nova);
					sol.setState(1);
					int size = cut.getListOfDimensions().size();
					for (int b=size-1; b>=0; b--) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha largura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
							allow = false;
							listToPaint.add(sol);
							cut.getListOfDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
							break;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeir da lista
						listToPaint.add(0, sol);
						cut.getListOfDimensions().add(0, nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (wi > wj) {
						i--;
					} else {
						if(wi < wj) {
							j--;
						} else {
							i--;
							j--;
						}
					}
				}
				i = 0;
				j = m;
				while (i <= k && j >= 0) { //segundo Atualizar
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(Math.max(wi,hj),wj + hi);
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setDim(nova);
					sol.setType("H");
					sol.setState(2);
					int size = cut.getListOfDimensions().size();
					for (int b=size-1; b>=0; b--) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha largura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
							allow = false;
							allow = false;
							listToPaint.add(sol);
							cut.getListOfDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
							break;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeiro da lista
						listToPaint.add(0, sol);
						cut.getListOfDimensions().add(0, nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (hi > wj) {
						i++;
					} else {
						if(hi < wj) {
							j--;
						} else {
							i++;
							j--;
						}
					}
				}
				i = k;
				j = 0;
				while (i >= 0 && j <= m) { //terceiro Atualizar
					ArrayList<Dimension> dimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDimensions().get(j).getWidth();
					Dimension nova = new Dimension();
					nova.setSize(Math.max(hi,wj),wi + hj);
					Solution sol = new Solution();
					Dimension l = firstSon.getListOfDimensions().get(i);
					sol.setLeftSon(l);
					Dimension r = secondSon.getListOfDimensions().get(j);
					sol.setRightSon(r);
					sol.setDim(nova);
					sol.setType("H");
					sol.setState(3);
					int size = cut.getListOfDimensions().size();
					for (int b=size-1; b>=0; b--) {
						Dimension aComparar = cut.getListOfDimensions().get(b);
						//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
						if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
							dimensionsToDelete.add(aComparar);
						}
						//se este novo par for fominado por um que j� existe na lista, parar o for e desistir deste novo par
						if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
							allow = false;
							break;
						}
						//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
						if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
							allow = false;
							listToPaint.add(sol);
							cut.getListOfDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
							break;
						}
					}
					for(int b=0; b<size; b++) {
						if(nova.getHeight() == cut.getListOfDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDimensions().get(b).getWidth()) {
							allow = false;
						}
					}
					if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeiro da lista
						listToPaint.add(0, sol);
						cut.getListOfDimensions().add(0, nova);
					}
					for(int z = 0; z<dimensionsToDelete.size(); z++) {
						for(int y=0; y<listToPaint.size(); y++) {
							if(listToPaint.get(y).getDim().getHeight() == dimensionsToDelete.get(z).getHeight() && listToPaint.get(y).getDim().getWidth() == dimensionsToDelete.get(z).getWidth()) {
								listToPaint.remove(listToPaint.get(y));
								break;
							}
						}
						cut.getListOfDimensions().remove(dimensionsToDelete.get(z));
					}
					if (wi > hj) {
						i--;
					} else {
						if(wi < hj) {
							j++;
						} else {
							i--;
							j++;
						}
					}					
				}
			}
		}
		
	}

	public double getFitness() {
		return fitness;
	}

	public void setFitness(double fitness) {
		this.fitness = fitness;
	}

	public void calculateFitness(String value) { //menor �rea
		setListOfSolutions();
		if (value == "�rea") {
			Dimension min = new Dimension();
			double minArea = 1000000;
			for (int i = 0; i<listOfSolutions.size(); i++) {
				Dimension dim = listOfSolutions.get(i);
				double h = dim.getHeight();
				double w = dim.getWidth();
				double area = h * w;
				if(area < minArea) {
					min = dim;
					minArea = area;
				}
			}
			double fit = (min.getHeight()*min.getWidth());
			setMinimumDimension(min);
			
			setFitness(fit);
		} else {
			Dimension min = new Dimension();
			double minPer = 1000000;
			for (int i = 0; i<listOfSolutions.size(); i++) {
				Dimension dim = listOfSolutions.get(i);
				double h = dim.getHeight();
				double w = dim.getWidth();
				double per = h + w;
				if(per < minPer) {
					min = dim;
					minPer = per;
				}
			}
			double fit = (min.getHeight() + min.getWidth());
			setMinimumDimension(min);
			setFitness(fit);
		}
	}

	public Dimension getMinimumDimension() {
		return minimumDimension;
	}

	public void setMinimumDimension(Dimension minimumDimension) {
		this.minimumDimension = minimumDimension;
	}

	public ArrayList<Solution> getListToPaint() {
		return listToPaint;
	}

	public void setListToPaint(ArrayList<Solution> listToPaint) {
		this.listToPaint = listToPaint;
	}


}
