import java.awt.Dimension;
import java.util.ArrayList;


public class GA {
	
	private ArrayList<Cromossoma> population;
	private ArrayList<Rectangle> listRectangles;
	private static final int numberOfRectangles = 10; //o teste de dimens�es controladas s� conta quando o n�mero de ret�ngulos � 10 
	private static final int numberOfCuts = numberOfRectangles - 1;
	private double mutationProb;
	private static final int numberOfChromossomes = 50;
	private ArrayList<Integer> listaIds; //lista para gerir os ret�ngulos que entram nos cromossomas
	private int mainCounter = 0;
	private ArrayList<Dimension> listToShow;
	private Gui gui;

//	private double 
	
	public GA(Gui gui) {
		this.gui = gui;
		listToShow = new ArrayList<>();
		mutationProb = 0.02; //decidir qual a probabilidade de muta��o da componente do cromossoma
		population = new ArrayList<>();
		listRectangles = new ArrayList<>();
		listaIds = new ArrayList<>();
		generateIds();
	}
	
	public ArrayList<Cromossoma> getGenoma() {
		return population;
	}
	
	public void fillListToShow() {
		for(int j=0; j<population.size(); j++) {
			boolean go = true;
			Dimension dim = population.get(j).getMinimumDimension();
			for(int i=0; i<listToShow.size(); i++) {
				if(dim.getHeight() == listToShow.get(i).getHeight() && dim.getWidth() == listToShow.get(i).getWidth()) {
					go = false;
				}
			}
			if(go) {
				listToShow.add(dim);
			}
		}
		for(int i=0; i<listToShow.size(); i++) {
			System.out.println("A solu��o " + (i+1) + " tem de altura " + listToShow.get(i).getHeight() + " e de largura " + listToShow.get(i).getWidth() + ".");
		}
	}

	public void setGenoma(ArrayList<Cromossoma> genoma) {
		this.population = genoma;
	}
	
	private void generateIds() {
		for (int i = 0; i < numberOfRectangles; i++) {
			listaIds.add(i);
		}	
	}
	
	public void generateBasicRectangles() { //Os rect�ngulos s�o colocados por ordem crescente pelos id's
		int numberOfPlacedRectangles = 0;
		int id = 0;
		Rectangle.createControlledDimensionsOfBasic();
		while (numberOfPlacedRectangles < numberOfRectangles) {
			Rectangle comp = new Rectangle();
//			comp.setDimensionsOfBasic();
			comp.setControlledDimensionsOfBasic(numberOfPlacedRectangles);
			comp.addBasicDimensionsToArray();
			comp.setId(id);
			listRectangles.add(comp);
			numberOfPlacedRectangles++;
			id++;
		}
		
	}
	
	public Cromossoma generateChromossome() {
		Cromossoma cromossoma = new Cromossoma();
		int numberOfPlacedRectangles = 0;
		int numberOfPlacedCuts = 0;
		
		while (numberOfPlacedRectangles < numberOfRectangles) {
			if (mainCounter == 0) {
				int randInit = (int)(Math.random()*2);
				if (randInit == 0) {
					Rectangle vertical = new Rectangle();
					vertical.setCut(true);
					vertical.setTipo("V");
					cromossoma.getCromossoma().add(vertical);
				}
				if (randInit == 1) {
					Rectangle horizontal = new Rectangle();
					horizontal.setCut(true);
					horizontal.setTipo("H");
					cromossoma.getCromossoma().add(horizontal);
				}
				mainCounter = mainCounter + 2;
				numberOfPlacedCuts++;
			} else {
				if (numberOfPlacedCuts<numberOfCuts) {
					int randCuts = (int)(Math.random()*2);
					if(randCuts == 0) {
						Rectangle vertical = new Rectangle();
						vertical.setCut(true);
						vertical.setTipo("V");
						cromossoma.getCromossoma().add(vertical);
						mainCounter++;
					}
					if(randCuts == 1) {
						Rectangle horizontal = new Rectangle();
						horizontal.setCut(true);
						horizontal.setTipo("H");
						cromossoma.getCromossoma().add(horizontal);
						mainCounter++;
					}
					numberOfPlacedCuts++;
				} else {
					int index = 0;
					int randRectangles = (int)(Math.random()*numberOfRectangles);
					boolean allow = false;
					while (!allow) { // guarda para garantir que o rect�ngulo gerado n�o vai ser igual a um que j� esteja na lista de ret�ngulos do cromossoma
						for (int i = 0; i < listaIds.size(); i++) {
							if (randRectangles == listaIds.get(i)) {
								index = i;
								allow = true;
							}
						} if (!allow) {
							randRectangles = (int)(Math.random()*numberOfRectangles);
						}
					}
					listaIds.remove(index);
					Rectangle comp = listRectangles.get(randRectangles);
					cromossoma.getCromossoma().add(comp);
					numberOfPlacedRectangles++;
					mainCounter--;
				}
			}
		}
		mainCounter = 0;
		generateIds();
		return cromossoma;
	}
	
	public void setNonDominatedSolutions() {
		String value = gui.getValue();
		for (int a = 0; a<population.size(); a++) {
			population.get(a).fillListOfAllDimensions();
			population.get(a).fillListOfNonDominatedSolutions();
			population.get(a).calculateFitness(value);
		}
		
	}
	
	public void evolvePopulation() { //falta eliminar solu��es duplicadas!!!!
		//Crossover
		ArrayList<Cromossoma> newGenome = new ArrayList<>();
		for (int i=0; i<(numberOfChromossomes/2); i++) {
			int cont = 0;
			int contador = 0;
			int rectanglesCopied = 0;
			int father = (int)(Math.random()*numberOfChromossomes);
			int mother = (int)(Math.random()*numberOfChromossomes);
			int crossPoint = (int)(Math.random()*(numberOfRectangles+numberOfCuts));
			Cromossoma fatherCrom = population.get(father);
			Cromossoma motherCrom = population.get(mother);
			Cromossoma filho = new Cromossoma();
			ArrayList<Rectangle> listAuxRect = new ArrayList<>();
			for (int j=0; j<listRectangles.size();j++) {
				listAuxRect.add(listRectangles.get(j));
			}
			if(crossPoint<numberOfCuts) { //se o �ndice do crossover for inferior ao n�mero de cortes
				while(cont<crossPoint) {
					filho.getCromossoma().add(fatherCrom.getCromossoma().get(cont));
					cont++;
				}
				while(cont<motherCrom.getCromossoma().size()) {
					filho.getCromossoma().add(motherCrom.getCromossoma().get(cont));
					cont++;
				}
			} else {
				while(cont<crossPoint) {
					filho.getCromossoma().add(fatherCrom.getCromossoma().get(cont));
					if(cont >= numberOfCuts) {
						Rectangle comp = fatherCrom.getCromossoma().get(cont);
						listAuxRect.remove(comp);
						rectanglesCopied++;
//						int id = comp.getId();
//						for (int h=numberOfCuts; h<fatherCrom.size(); h++) {
//							Component aux = (Component) fatherCrom.get(h);
//							int idAux = aux.getId();
//							if(idAux == id) {
//								listAuxRect.remove(aux);
//							}
//						}	
					}
					cont++;
					
				}
				while(contador < (numberOfRectangles-rectanglesCopied)) {
					filho.getCromossoma().add(listAuxRect.get(contador));
					contador++;
				}
			}
			//Muta��o
			boolean allow = false;
			double mutProb = Math.random();
			if(mutProb <= mutationProb) {
				allow = true;
				boolean last = false; // boolean para saber se o �ndice random vai ser o �ndice do �ltimo rect�ngulo do cromossoma
				int mut = (int)(Math.random()*(numberOfCuts+numberOfRectangles));
				Cromossoma novoFilho = new Cromossoma();
				int a = 0;
				if(mut == (filho.getCromossoma().size()-1)) { // para trocar o �ltimo rect�ngulo com o primeiro
					last = true;
				}
				while (a < mut && !last) {
					novoFilho.getCromossoma().add(filho.getCromossoma().get(a));
					a++;
				}
				if(mut<numberOfCuts) { //cortes
					if (filho.getCromossoma().get(mut).getTipo() == "V") {
						Rectangle horizontal = new Rectangle();
						horizontal.setCut(true);
						horizontal.setTipo("H");
						novoFilho.getCromossoma().add(horizontal);
					} else {
						Rectangle vertical = new Rectangle();
						vertical.setCut(true);
						vertical.setTipo("V");
						novoFilho.getCromossoma().add(vertical);
					}
					mut++;
					while (mut < filho.getCromossoma().size()) {
						novoFilho.getCromossoma().add(filho.getCromossoma().get(mut));
						mut++;
					}
				} else { //rect�ngulos
					if (last) {
						int b = 0;
						while (b<numberOfCuts) {
							novoFilho.getCromossoma().add(filho.getCromossoma().get(b));
							b++;
						}
						b++; 
						Rectangle firstOfRectangles = filho.getCromossoma().get(numberOfCuts);
						Rectangle lastOfRectangles = filho.getCromossoma().get(filho.getCromossoma().size()-1);
						novoFilho.getCromossoma().add(lastOfRectangles);
						while (b<(filho.getCromossoma().size()-1)) {
							novoFilho.getCromossoma().add(filho.getCromossoma().get(b));
							b++;
						}
						novoFilho.getCromossoma().add(firstOfRectangles);
					} else { //se mut n�o apontar para o �ltimo rect�ngulo do cromossoma
						Rectangle firstToSwap = filho.getCromossoma().get(mut);
						Rectangle lastToSwap = filho.getCromossoma().get(mut+1);
						novoFilho.getCromossoma().add(lastToSwap);
						novoFilho.getCromossoma().add(firstToSwap);
						a = a+2;
						while (a < filho.getCromossoma().size()) {
							novoFilho.getCromossoma().add(filho.getCromossoma().get(a));
							a++;
						}
					}
				}	
				newGenome.add(novoFilho);
			}
			if(!allow) {
				newGenome.add(filho);
			}
		}
		
		//aqui chama o m�todo do c�lculo do fitness de cada cromossoma
		setNonDominatedSolutions();
		// ordenar o genoma antigo por valor de fitness crescente para incluir os 25 melhores cromossomas (menor fitness = menor �rea)
		orderGenome();
		for(int i = 0; i<population.size();i++) {//incluir os 25 elementos com melhor fitness do genoma antigo para o novo genoma
			newGenome.add(population.get(i));
		}
		population = newGenome;
	}
	
	public void orderGenome() {
		ArrayList<Cromossoma> novaLista = new ArrayList<>();
		double minimum = 100000000;
		Cromossoma min = null;
		int c = 0;
		while(c<population.size()) {
			for (int i=0; i<population.size(); i++) {
				double area = population.get(i).getFitness();
				if(area < minimum) {
					min = population.get(i);
					minimum = area;
				}
			}
//			for (int e=0; e<listaComp.size(); e++) {
//				if (listaComp.get(e).getHeight() == maximum) {
//					max = listaComp.get(e);
//				}
//			}
			novaLista.add(min);
			population.remove(min);
			minimum = 100000000;
			min = null;
			c++;
		}
		population = novaLista;
	}

	public void generatePopulation() {
		for (int i = 0; i < numberOfChromossomes; i++) { //gera o genoma com os x cromossomas
			Cromossoma cromossoma = generateChromossome();
			population.add(cromossoma);
		}
	}

}
