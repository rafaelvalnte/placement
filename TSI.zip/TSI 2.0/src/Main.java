import java.awt.Dimension;
import java.text.DecimalFormat;

import javax.swing.JFrame;


public class Main {

	public static void main(String[] args) {
		
		Gui gui = new Gui();
		GA ga = new GA(gui);
		ga.generateBasicRectangles();
		ga.generatePopulation();
		int y = 100;  //n�mero de gera��es
		for (int i=0; i<y; i++) {
			ga.setNonDominatedSolutions();
			ga.evolvePopulation();
			System.out.println(i+1);
		}
		ga.setNonDominatedSolutions();
		ga.fillListToShow();
		gui.setCrom(ga.getGenoma().get(0)); //cromossoma com melhor fitness antes da evolu��o
//		gui.setListToPaint(ga.getGenoma().get(25).getListToPaint());
//		gui.computeSolutionToPaint();
//		gui.setTitle("Chip");
//		gui.setLocationRelativeTo(null);
//		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		gui.setVisible(true);
//		Cromossoma c = ga.getGenoma().get(0);
//		Dimension min = c.getMinimumDimension();
//		gui.setSize((int)min.getWidth(), (int)min.getHeight());
//		gui.setResizable(false);
		System.out.println("I reached the end!");
	}

}
