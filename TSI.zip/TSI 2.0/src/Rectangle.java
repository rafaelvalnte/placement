import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Random;


public class Rectangle {
	
	private int height;
	private int width;
	private String tipo;
	private int id;
	private ArrayList<Dimension> listaDimens�es;
	private Color color;
	private boolean isCut;
	private boolean isBasic;
	private static ArrayList<Dimension> listaDimens�esControladas;
	
	
	public Rectangle() {
		Random rand = new Random();
		float r = rand.nextFloat();
		float g = rand.nextFloat();
		float b = rand.nextFloat();
		setColor(new Color(r,g,b));
		listaDimens�es = new ArrayList<>();
	}
	
	public void setDimensionsOfBasic() {
		isBasic = true;
		setTipo("Basic");
		setWidth((int)(Math.random()*50)+1);
		setHeight((int)(Math.random()*50)+1);
	}
	
	public void setControlledDimensionsOfBasic(int ind) {
		isBasic = true;
		setTipo("Basic");		
		for (int i=0; i<listaDimens�esControladas.size(); i++) {
			if(i==ind) {
				setWidth((int) listaDimens�esControladas.get(i).getWidth());
				setHeight((int) listaDimens�esControladas.get(i).getHeight());
			}
		}
	}
	
	public static void createControlledDimensionsOfBasic() {
		listaDimens�esControladas = new ArrayList<>();
		Dimension a = new Dimension(10,13);
		listaDimens�esControladas.add(a);
		Dimension b = new Dimension(2,7);
		listaDimens�esControladas.add(b);
		Dimension c = new Dimension(22,4);
		listaDimens�esControladas.add(c);
		Dimension d = new Dimension(5,17);
		listaDimens�esControladas.add(d);
		Dimension e = new Dimension(20,30);
		listaDimens�esControladas.add(e);
		Dimension f = new Dimension(15,22);
		listaDimens�esControladas.add(f);
		Dimension g = new Dimension(13,2);
		listaDimens�esControladas.add(g);
		Dimension h = new Dimension(1,16);
		listaDimens�esControladas.add(h);
		Dimension i = new Dimension(8,9);
		listaDimens�esControladas.add(i);
		Dimension j = new Dimension(11,24);
		listaDimens�esControladas.add(j);
	}
	
	
	public void addBasicDimensionsToArray() {
		Dimension laying = new Dimension(height,width);
		Dimension standing = new Dimension(width,height);
		listaDimens�es.add(standing);
		listaDimens�es.add(laying);
	}
	
	public ArrayList<Dimension> getListOfDimensions() {
		return listaDimens�es;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public boolean isCut() {
		return isCut;
	}

	public void setCut(boolean isCut) {
		this.isCut = isCut;
	}

	public boolean isBasic() {
		return isBasic;
	}

	public void setBasic(boolean isBasic) {
		this.isBasic = isBasic;
	}
	
	public String toString() {
		if(isBasic) {
			int a = getId();
			return "'" + a + "'";
		} else {
			return "'" + tipo + "'";
		}
	}



}
