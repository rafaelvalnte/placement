package NewApproach;

import java.util.ArrayList;
import java.util.Random;

/**
 * The Class GA.
 */
public class GA {

	/** The population. */
	private ArrayList<Cromossoma> population;
	
	/** The list rectangles. */
	private ArrayList<Rectangle> listRectangles;
	
	/** The Constant numberOfRectangles. */
	private static final int numberOfRectangles = 300; // o teste de dimens�es controladas s� conta quando o n�mero de
														// ret�ngulos � 10, sen�o � necess�rio criar mais ret�ngulos com
														/** The Constant numberOfCuts. */
														// dimens�es controladas manualmente
	private static final int numberOfCuts = numberOfRectangles - 1;
	
	/** The Constant numberOfGenerations. */
	private static final int numberOfGenerations = 50000;
	
	/** The Constant mutationProb. */
	private static final double mutationProb = 0.02; // decidir qual a probabilidade de muta��o da componente do
														
														/** The Constant numberOfChromossomes. */
														// cromossoma
	private static final int numberOfChromossomes = 3000;
	
	/** The maximum double dimension. */
	private double maximumDoubleDimension;
	
	/** The minimum double dimension. */
	private double minimumDoubleDimension;
	
	/** The lista ids. */
	private ArrayList<Integer> listaIds; // lista para gerir os ret�ngulos que entram nos cromossomas
	
	/** The main counter. */
	private int mainCounter = 0;
	
	/** The list to show. */
	private ArrayList<DoubleDimension> listToShow;
	
	/** The gui. */
	private Gui gui;
	
	/** The best initial fitness. */
	private double bestInitialFitness;
	
	/** The best current fitness. */
	private double bestCurrentFitness;
	
	/** The no solution improvement max generations. */
	private int noSolutionImprovementMaxGenerations = 2500; //condi��o de paragem - n�mero de gera��es m�ximo em que n�o existe uma melhoria na solu��o
	
	/** The no solution improvement current generations. */
	private int noSolutionImprovementCurrentGenerations = 0;
	
	/** The initial area. */
	private double initialArea;
	
	/** The rnd numbers. */
	private Random rndNumbers;
	
	/** The seed. */
	private int seed; //se a seed for 0, usa a fun��o Math.random() em vez do Random(seed)
	
	/** The stop condition met. */
	private boolean stopConditionMet;
	

	/**
	 * Instantiates a new ga.
	 *
	 * @param gui the gui
	 * @param seed the seed
	 */
	public GA(Gui gui, int seed) {
		this.gui = gui;
		this.seed = seed;
		noSolutionImprovementCurrentGenerations = 0;
		stopConditionMet = false;
		rndNumbers = new Random(seed);
		listToShow = new ArrayList<>();
		population = new ArrayList<>();
		listRectangles = new ArrayList<>();
		listaIds = new ArrayList<>();
		maximumDoubleDimension = 0;
		minimumDoubleDimension = Double.MAX_VALUE;
		bestCurrentFitness = Double.MAX_VALUE;
		generateIds();
	}

	/**
	 * Gets the number of generations.
	 *
	 * @return the number of generations
	 */
	public int getNumberOfGenerations() {
		return numberOfGenerations;
	}

	/**
	 * Gets the mutation probability.
	 *
	 * @return the mutation probability
	 */
	public double getMutationProbability() {
		return mutationProb;
	}

	/**
	 * Gets the number of rectangles.
	 *
	 * @return the number of rectangles
	 */
	public int getNumberOfRectangles() {
		return numberOfRectangles;
	}

	/**
	 * Gets the number of chromossomes.
	 *
	 * @return the number of chromossomes
	 */
	public int getNumberOfChromossomes() {
		return numberOfChromossomes;
	}

	/**
	 * Gets the population.
	 *
	 * @return the population
	 */
	public ArrayList<Cromossoma> getPopulation() {
		return population;
	}

	/**
	 * Sets the best initial fitness.
	 */
	public void setBestInitialFitness() {
		bestInitialFitness = population.get(0).getFitness();
		for (int i = 1; i < population.size(); i++) {
			if (population.get(i).getFitness() < bestInitialFitness) {
				bestInitialFitness = population.get(i).getFitness();
			}
		}
	}

	/**
	 * Gets the best initial fitness.
	 *
	 * @return the best initial fitness
	 */
	public double getBestInitialFitness() {
		return bestInitialFitness;
	}

	/**
	 * Fill list to show.
	 */
	public void fillListToShow() {
		orderGenome();
		for (int j = 0; j < population.size(); j++) {
			boolean go = true;
			DoubleDimension dim = population.get(j).getMinimumDoubleDimension();
			for (int i = 0; i < listToShow.size(); i++) {
				if (dim.getHeight() == listToShow.get(i).getHeight()
						&& dim.getWidth() == listToShow.get(i).getWidth()) {
					go = false;
				}
			}
			if (go) {
				listToShow.add(dim);
			}
		}
		System.out.println("A solu��o tem de altura " + listToShow.get(0).getHeight() + " e de largura " + listToShow.get(0).getWidth() + ".");
	}

	/**
	 * Sets the population.
	 *
	 * @param genoma the new population
	 */
	public void setPopulation(ArrayList<Cromossoma> genoma) {
		this.population = genoma;
	}

	/**
	 * Generate ids.
	 */
	private void generateIds() {
		for (int i = 0; i < numberOfRectangles; i++) {
			listaIds.add(i);
		}
	}

	/**
	 * Sets the maximum double dimension.
	 */
	public void setMaximumDoubleDimension() {
		for (int i = 0; i < listRectangles.size(); i++) {
			if (listRectangles.get(i).getHeight() > listRectangles.get(i).getWidth()) {
				if (listRectangles.get(i).getHeight() > maximumDoubleDimension) {
					maximumDoubleDimension = listRectangles.get(i).getHeight();
				}
			} else {
				if (listRectangles.get(i).getWidth() > maximumDoubleDimension) {
					maximumDoubleDimension = listRectangles.get(i).getWidth();
				}
			}
		}
	}

	/**
	 * Sets the minimum double dimension.
	 */
	public void setMinimumDoubleDimension() {
		for (int i = 0; i < listRectangles.size(); i++) {
			if (listRectangles.get(i).getHeight() < listRectangles.get(i).getWidth()) {
				if (listRectangles.get(i).getHeight() < minimumDoubleDimension) {
					minimumDoubleDimension = listRectangles.get(i).getHeight();
				}
			} else {
				if (listRectangles.get(i).getWidth() < minimumDoubleDimension) {
					minimumDoubleDimension = listRectangles.get(i).getWidth();
				}
			}
		}
	}

	/**
	 * Gets the maximum double dimension.
	 *
	 * @return the maximum double dimension
	 */
	public double getMaximumDoubleDimension() {
		return maximumDoubleDimension;
	}

	/**
	 * Gets the minimum double dimension.
	 *
	 * @return the minimum double dimension
	 */
	public double getMinimumDoubleDimension() {
		return minimumDoubleDimension;
	}

	/**
	 * Generate basic rectangles.
	 *
	 * @param useListRectangles the use list rectangles
	 * @param listSameRectangles the list same rectangles
	 */
	public void generateBasicRectangles(boolean useListRectangles, ArrayList<Rectangle> listSameRectangles) { // Os
																												// rect�ngulos
																												// s�o
																												// colocados
																												// por
																												// ordem
																												// crescente
																												// pelos
																												// id's
		boolean hasControlledDoubleDimensions = gui.hasControlledDoubleDimensions();
		if (useListRectangles) {
			listRectangles = listSameRectangles;
		} else {
			int numberOfPlacedRectangles = 0;
			int id = 0;

			if (hasControlledDoubleDimensions) {
				Rectangle.createControlledDoubleDimensionsOfBasic();
				setInitialArea(Rectangle.calculateArea()); // calcula a �rea inicial sem espa�os entre os ret�ngulos
			}

			while (numberOfPlacedRectangles < numberOfRectangles) {
				Rectangle comp = new Rectangle();
				if (hasControlledDoubleDimensions) {
					comp.setControlledDoubleDimensionsOfBasic(numberOfPlacedRectangles); // as dimens�es s�o controladas
				} else {
					comp.setDoubleDimensionsOfBasic(); // as dimens�es s�o aleat�rias
				}
				comp.addBasicDoubleDimensionsToArray();
				comp.setId(id);
				listRectangles.add(comp);
				numberOfPlacedRectangles++;
				id++;
			}
		}

		if (!hasControlledDoubleDimensions) {
			double area = 0;
			for (int i = 0; i < listRectangles.size(); i++) {
				double a = listRectangles.get(i).getHeight() * listRectangles.get(i).getWidth();
				area += a;
			}
			setInitialArea(area);
		} else {
			setInitialArea(Rectangle.calculateArea()); // calcula a �rea inicial sem espa�os entre os ret�ngulos
		}

		setMaximumDoubleDimension();
		setMinimumDoubleDimension();
	}

	/**
	 * Generate chromossome.
	 *
	 * @return the cromossoma
	 */
	public Cromossoma generateChromossome() {
		Cromossoma cromossoma = new Cromossoma();
		int numberOfPlacedRectangles = 0;
		int numberOfPlacedCuts = 0;

		while (numberOfPlacedRectangles < numberOfRectangles) {
			if (mainCounter == 0) {
				int randInit;
				if(seed == 0) {
					randInit = (int) (Math.random() * 2);
				} else {
					randInit = rndNumbers.nextInt(2);
				}
				if (randInit == 0) {
					Rectangle vertical = new Rectangle();
					vertical.setCut(true);
					vertical.setTipo("V");
					cromossoma.getCromossoma().add(vertical);
				}
				if (randInit == 1) {
					Rectangle horizontal = new Rectangle();
					horizontal.setCut(true);
					horizontal.setTipo("H");
					cromossoma.getCromossoma().add(horizontal);
				}
				mainCounter = mainCounter + 2;
				numberOfPlacedCuts++;
			} else {
				if (numberOfPlacedCuts < numberOfCuts) {
					int randCuts;
					if(seed == 0) {
						randCuts = (int) (Math.random() * 2);
					} else {
						randCuts = rndNumbers.nextInt(2);
					}
					if (randCuts == 0) {
						Rectangle vertical = new Rectangle();
						vertical.setCut(true);
						vertical.setTipo("V");
						cromossoma.getCromossoma().add(vertical);
						mainCounter++;
					}
					if (randCuts == 1) {
						Rectangle horizontal = new Rectangle();
						horizontal.setCut(true);
						horizontal.setTipo("H");
						cromossoma.getCromossoma().add(horizontal);
						mainCounter++;
					}
					numberOfPlacedCuts++;
				} else {
					int index = 0;
					int randRectangles;
					if(seed == 0) {
						randRectangles = (int) (Math.random() * numberOfRectangles);
					} else {
						randRectangles = rndNumbers.nextInt(numberOfRectangles);
					}
					boolean allow = false;
					while (!allow) { // guarda para garantir que o rect�ngulo gerado n�o vai ser igual a um que j�
										// esteja na lista de ret�ngulos do cromossoma
						for (int i = 0; i < listaIds.size(); i++) {
							if (randRectangles == listaIds.get(i)) {
								index = i;
								allow = true;
								break;
							}
						}
						if (!allow) {
							if(seed == 0) {
								randRectangles = (int) (Math.random() * numberOfRectangles);
							} else {
								randRectangles = rndNumbers.nextInt(numberOfRectangles);
							}
						}
					}
					listaIds.remove(index);
					Rectangle comp = listRectangles.get(randRectangles);
					cromossoma.getCromossoma().add(comp);
					numberOfPlacedRectangles++;
					mainCounter--;
				}
			}
		}
		mainCounter = 0;
		generateIds();
		return cromossoma;
	}

	/**
	 * Sets the non dominated solutions.
	 */
	public void setNonDominatedSolutions() {
		String value = gui.getObjectiveFunctionType();
		for (int a = 0; a < population.size(); a++) {
			if (population.get(a).getListOfAllDoubleDimensions().isEmpty()) {
				population.get(a).fillListOfAllDoubleDimensions();
			}
			population.get(a).fillListOfNonDominatedSolutions(initialArea);
			population.get(a).calculateFitness(value);
		}

	}

	/**
	 * Evolve population.
	 */
	public void evolvePopulation() {

		// Crossover

		ArrayList<Cromossoma> newGenome = new ArrayList<>();
		int it = 0;
		int num = numberOfChromossomes;
		if (num % 2 == 0) {
			it = num / 2;
		} else {
			it = num / 2 + 1;
		}

		Cromossoma filho = null;

		for (int i = 0; i < it; i++) {

			if (gui.getCrossoverType() == Gui.getOPC()) {
				int cont = 0;
				int contador = 0;
				int rectanglesCopied = 0;
				int father;
				if(seed == 0) {
					father = (int) (Math.random() * numberOfChromossomes);
				} else {
					father = rndNumbers.nextInt(numberOfChromossomes);
				}
				int mother;
				if(seed == 0) {
					mother = (int) (Math.random() * numberOfChromossomes);
				} else {
					mother = rndNumbers.nextInt(numberOfChromossomes);
				}
				while (mother == father) { // ciclo para garantir que os cromossomas escolhidos nunca s�o iguais
					if(seed == 0) {
						mother = (int) (Math.random() * numberOfChromossomes);
					} else {
						mother = rndNumbers.nextInt(numberOfChromossomes);
					}
				}
				int crossPoint;
				if(seed == 0) {
					crossPoint = (int) (Math.random() * (numberOfRectangles + numberOfCuts));
				} else {
					crossPoint = rndNumbers.nextInt((numberOfRectangles + numberOfCuts));
				}
				Cromossoma fatherCrom = new Cromossoma();
				fatherCrom = population.get(father);
				Cromossoma motherCrom = new Cromossoma();
				motherCrom = population.get(mother);
				filho = new Cromossoma();
				ArrayList<Rectangle> listAuxRect = new ArrayList<>();
				for (int j = motherCrom.getCromossoma().size() / 2; j < motherCrom.getCromossoma().size(); j++) {
					listAuxRect.add(motherCrom.getCromossoma().get(j));
				}
				if (crossPoint < numberOfCuts) { // se o �ndice do crossover for inferior ao n�mero de cortes
					while (cont < crossPoint) {
						Rectangle comp = new Rectangle();
						if (fatherCrom.getCromossoma().get(cont).isBasic()) {
							comp = new Rectangle(fatherCrom.getCromossoma().get(cont).getHeight(),
									fatherCrom.getCromossoma().get(cont).getWidth(),
									fatherCrom.getCromossoma().get(cont).getTipo(),
									fatherCrom.getCromossoma().get(cont).getId(),
									fatherCrom.getCromossoma().get(cont).getListOfDoubleDimensions(),
									fatherCrom.getCromossoma().get(cont).isCut(),
									fatherCrom.getCromossoma().get(cont).isBasic(),
									fatherCrom.getCromossoma().get(cont).getCoordinate());
						} else {
							comp = new Rectangle(fatherCrom.getCromossoma().get(cont).getHeight(),
									fatherCrom.getCromossoma().get(cont).getWidth(),
									fatherCrom.getCromossoma().get(cont).getTipo(),
									fatherCrom.getCromossoma().get(cont).getId(), new ArrayList<DoubleDimension>(),
									fatherCrom.getCromossoma().get(cont).isCut(),
									fatherCrom.getCromossoma().get(cont).isBasic(),
									fatherCrom.getCromossoma().get(cont).getCoordinate());
						}
						filho.getCromossoma().add(comp);
						cont++;
					}
					while (cont < motherCrom.getCromossoma().size()) {
						Rectangle comp = new Rectangle();
						if (motherCrom.getCromossoma().get(cont).isBasic()) {
							comp = new Rectangle(motherCrom.getCromossoma().get(cont).getHeight(),
									motherCrom.getCromossoma().get(cont).getWidth(),
									motherCrom.getCromossoma().get(cont).getTipo(),
									motherCrom.getCromossoma().get(cont).getId(),
									motherCrom.getCromossoma().get(cont).getListOfDoubleDimensions(),
									motherCrom.getCromossoma().get(cont).isCut(),
									motherCrom.getCromossoma().get(cont).isBasic(),
									motherCrom.getCromossoma().get(cont).getCoordinate());
						} else {
							comp = new Rectangle(motherCrom.getCromossoma().get(cont).getHeight(),
									motherCrom.getCromossoma().get(cont).getWidth(),
									motherCrom.getCromossoma().get(cont).getTipo(),
									motherCrom.getCromossoma().get(cont).getId(), new ArrayList<DoubleDimension>(),
									motherCrom.getCromossoma().get(cont).isCut(),
									motherCrom.getCromossoma().get(cont).isBasic(),
									motherCrom.getCromossoma().get(cont).getCoordinate());
						}
						filho.getCromossoma().add(comp);
						cont++;
					}
				} else {
					while (cont < crossPoint) {
						Rectangle comp = new Rectangle();
						if (fatherCrom.getCromossoma().get(cont).isBasic()) {
							comp = new Rectangle(fatherCrom.getCromossoma().get(cont).getHeight(),
									fatherCrom.getCromossoma().get(cont).getWidth(),
									fatherCrom.getCromossoma().get(cont).getTipo(),
									fatherCrom.getCromossoma().get(cont).getId(),
									fatherCrom.getCromossoma().get(cont).getListOfDoubleDimensions(),
									fatherCrom.getCromossoma().get(cont).isCut(),
									fatherCrom.getCromossoma().get(cont).isBasic(),
									fatherCrom.getCromossoma().get(cont).getCoordinate());
						} else {
							comp = new Rectangle(fatherCrom.getCromossoma().get(cont).getHeight(),
									fatherCrom.getCromossoma().get(cont).getWidth(),
									fatherCrom.getCromossoma().get(cont).getTipo(),
									fatherCrom.getCromossoma().get(cont).getId(), new ArrayList<DoubleDimension>(),
									fatherCrom.getCromossoma().get(cont).isCut(),
									fatherCrom.getCromossoma().get(cont).isBasic(),
									fatherCrom.getCromossoma().get(cont).getCoordinate());
						}
						filho.getCromossoma().add(comp);
						if (cont >= numberOfCuts) {
							Rectangle comp2 = new Rectangle();
							comp2 = fatherCrom.getCromossoma().get(cont);
							for (int j = 0; j < listAuxRect.size(); j++) {
								if (listAuxRect.get(j).getId() == comp2.getId()) {
									listAuxRect.remove(j);
									break;
								}
							}
							rectanglesCopied++;
						}
						cont++;

					}
					while (contador < (numberOfRectangles - rectanglesCopied)) {
						filho.getCromossoma().add(listAuxRect.get(contador));
						contador++;
					}
				}
			}
			if (gui.getCrossoverType() == Gui.getRRC()) {

				ArrayList<Rectangle> listAuxRect = new ArrayList<>();
				for (int z = 0; z < listRectangles.size(); z++) {
					listAuxRect.add(listRectangles.get(z));
				}
				int father;
				if(seed == 0) {
					father = (int) (Math.random() * numberOfChromossomes);
				} else {
					father = rndNumbers.nextInt(numberOfChromossomes);
				}
				int mother;
				if(seed == 0) {
					mother = (int) (Math.random() * numberOfChromossomes);
				} else {
					mother = rndNumbers.nextInt(numberOfChromossomes);
				}
				while (mother == father) { // ciclo para garantir que os cromossomas escolhidos nunca s�o iguais
					if(seed == 0) {
						mother = (int) (Math.random() * numberOfChromossomes);
					} else {
						mother = rndNumbers.nextInt(numberOfChromossomes);
					}
				}
				Cromossoma fatherCrom = new Cromossoma();
				fatherCrom = population.get(father);
				Cromossoma motherCrom = new Cromossoma();
				motherCrom = population.get(mother);
				filho = new Cromossoma();
				for (int j = 0; j < fatherCrom.getCromossoma().size(); j++) {
					if (j < numberOfCuts) { // se for corte
						if (fatherCrom.getCromossoma().get(j).getTipo() == motherCrom.getCromossoma().get(j)
								.getTipo()) {
							Rectangle comp = new Rectangle(fatherCrom.getCromossoma().get(j).getHeight(),
									fatherCrom.getCromossoma().get(j).getWidth(),
									fatherCrom.getCromossoma().get(j).getTipo(),
									fatherCrom.getCromossoma().get(j).getId(), new ArrayList<DoubleDimension>(),
									fatherCrom.getCromossoma().get(j).isCut(),
									fatherCrom.getCromossoma().get(j).isBasic(),
									fatherCrom.getCromossoma().get(j).getCoordinate());
							filho.getCromossoma().add(comp);
						} else { // sen�o, o corte � gerado aleatoriamente
							int randInit;
							if(seed == 0) {
								randInit = (int) (Math.random() * 2);
							} else {
								randInit = rndNumbers.nextInt(2);
							}
							if (randInit == 0) {
								Rectangle vertical = new Rectangle();
								vertical.setCut(true);
								vertical.setTipo("V");
								filho.getCromossoma().add(vertical);
							}
							if (randInit == 1) {
								Rectangle horizontal = new Rectangle();
								horizontal.setCut(true);
								horizontal.setTipo("H");
								filho.getCromossoma().add(horizontal);
							}
						}
					} else { // se for b�sico
						if (fatherCrom.getCromossoma().get(j).getId() == motherCrom.getCromossoma().get(j).getId()) {
							int commonId = fatherCrom.getCromossoma().get(j).getId();
							boolean putBasic = true;
							for (int b = numberOfCuts; b < filho.getCromossoma().size(); b++) {
								if (filho.getCromossoma().get(b).getId() == commonId) {
									putBasic = false;
									break;
								}
							}
							if (putBasic) {
								Rectangle comp = new Rectangle(fatherCrom.getCromossoma().get(j).getHeight(),
										fatherCrom.getCromossoma().get(j).getWidth(),
										fatherCrom.getCromossoma().get(j).getTipo(),
										fatherCrom.getCromossoma().get(j).getId(),
										fatherCrom.getCromossoma().get(j).getListOfDoubleDimensions(),
										fatherCrom.getCromossoma().get(j).isCut(),
										fatherCrom.getCromossoma().get(j).isBasic(),
										fatherCrom.getCromossoma().get(j).getCoordinate());
								filho.getCromossoma().add(comp);
								for (int y = 0; y < listAuxRect.size(); y++) {
									if (listAuxRect.get(y).getId() == commonId) {
										listAuxRect.remove(y);
										break;
									}
								}
							} else {
								int randBasic;
								if(seed == 0) {
									randBasic = (int) (Math.random() * listAuxRect.size());
								} else {
									randBasic = rndNumbers.nextInt(listAuxRect.size());
								}								
								filho.getCromossoma().add(listAuxRect.get(randBasic));
								listAuxRect.remove(randBasic);
							}
						} else {
							int randBasic;
							if(seed == 0) {
								randBasic = (int) (Math.random() * listAuxRect.size());
							} else {
								randBasic = rndNumbers.nextInt(listAuxRect.size());
							}	
							filho.getCromossoma().add(listAuxRect.get(randBasic));
							listAuxRect.remove(randBasic);
						}
					}
				}
			}

			// Muta��o
			boolean allow = false;
			double mutProb;
			if(seed == 0) {
				mutProb = Math.random();
			} else {
				mutProb = rndNumbers.nextDouble();
			}
			if (mutProb <= mutationProb) {
				allow = true;
				boolean last = false; // boolean para saber se o �ndice random vai ser o �ndice do �ltimo rect�ngulo
										// do cromossoma
				int mut;
				if(seed == 0) {
					mut = (int) (Math.random() * (numberOfCuts + numberOfRectangles));
				} else {
					mut = rndNumbers.nextInt((numberOfCuts + numberOfRectangles));
				}
				Cromossoma novoFilho = new Cromossoma();
				int a = 0;
				if (mut == (filho.getCromossoma().size() - 1)) { // para trocar o �ltimo rect�ngulo com o primeiro
					last = true;
				}
				while (a < mut && !last) {
					novoFilho.getCromossoma().add(filho.getCromossoma().get(a));
					a++;
				}
				if (mut < numberOfCuts) { // cortes
					if (filho.getCromossoma().get(mut).getTipo() == "V") {
						Rectangle horizontal = new Rectangle();
						horizontal.setCut(true);
						horizontal.setTipo("H");
						novoFilho.getCromossoma().add(horizontal);
					} else {
						Rectangle vertical = new Rectangle();
						vertical.setCut(true);
						vertical.setTipo("V");
						novoFilho.getCromossoma().add(vertical);
					}
					mut++;
					while (mut < filho.getCromossoma().size()) {
						novoFilho.getCromossoma().add(filho.getCromossoma().get(mut));
						mut++;
					}
				} else { // rect�ngulos
					if (last) {
						int b = 0;
						while (b < numberOfCuts) {
							novoFilho.getCromossoma().add(filho.getCromossoma().get(b));
							b++;
						}
						b++;
						Rectangle firstOfRectangles = new Rectangle();
						firstOfRectangles = filho.getCromossoma().get(numberOfCuts);
						Rectangle lastOfRectangles = new Rectangle();
						lastOfRectangles = filho.getCromossoma().get(filho.getCromossoma().size() - 1);
						novoFilho.getCromossoma().add(lastOfRectangles);
						while (b < (filho.getCromossoma().size() - 1)) {
							novoFilho.getCromossoma().add(filho.getCromossoma().get(b));
							b++;
						}
						novoFilho.getCromossoma().add(firstOfRectangles);
					} else { // se mut n�o apontar para o �ltimo rect�ngulo do cromossoma
						Rectangle firstToSwap = new Rectangle();
						firstToSwap = filho.getCromossoma().get(mut);
						Rectangle lastToSwap = new Rectangle();
						lastToSwap = filho.getCromossoma().get(mut + 1);
						novoFilho.getCromossoma().add(lastToSwap);
						novoFilho.getCromossoma().add(firstToSwap);
						a = a + 2;
						while (a < filho.getCromossoma().size()) {
							novoFilho.getCromossoma().add(filho.getCromossoma().get(a));
							a++;
						}
					}
				}
				newGenome.add(novoFilho);
			}
			if (!allow) {
				newGenome.add(filho);
			}
		}

		// ordenar o genoma antigo por valor de fitness crescente para incluir os 25
		// melhores cromossomas (menor fitness = menor �rea)
		orderGenome();
		if(population.get(0).getFitness() != 0) {
			if(population.get(0).getFitness() < bestCurrentFitness) {
				setBestCurrentFitness(population.get(0).getFitness());
				noSolutionImprovementCurrentGenerations = 0;
			} else {
				noSolutionImprovementCurrentGenerations++;
			}
		}
		if(noSolutionImprovementCurrentGenerations == noSolutionImprovementMaxGenerations || bestCurrentFitness == initialArea) {
			stopConditionMet = true;
		}
		for (int i = 0; i < population.size(); i++) {// incluir os 25 elementos com melhor fitness do genoma antigo para
														// o novo genoma
			newGenome.add(population.get(i));
		}
		population = newGenome;
	}

	/**
	 * Order genome.
	 */
	public void orderGenome() {
		ArrayList<Cromossoma> novaLista = new ArrayList<>();
		Cromossoma min = null;
		double minimum = Double.MAX_VALUE;
		int c = 1;
		while (c < population.size()) {
			for (int i = 0; i < population.size(); i++) {
				double area = population.get(i).getFitness();
				if (area < minimum) {
					min = population.get(i);
					minimum = area;
				}
			}
			novaLista.add(min);
			population.remove(min);
			minimum = Double.MAX_VALUE;
			min = null;
			c++;
		}
		population = novaLista;
	}

	/**
	 * Generate population.
	 */
	public void generatePopulation() {
		for (int i = 0; i < numberOfChromossomes; i++) { // gera o genoma com os x cromossomas
			Cromossoma cromossoma = generateChromossome();
			population.add(cromossoma);
		}
	}

	/**
	 * Gets the initial area.
	 *
	 * @return the initial area
	 */
	public double getInitialArea() {
		return initialArea;
	}

	/**
	 * Sets the initial area.
	 *
	 * @param initialArea the new initial area
	 */
	public void setInitialArea(double initialArea) {
		this.initialArea = initialArea;
	}

	/**
	 * Gets the list of rectangles.
	 *
	 * @return the list of rectangles
	 */
	public ArrayList<Rectangle> getListOfRectangles() {
		return listRectangles;
	}

	/**
	 * Gets the no solution improvement max generations.
	 *
	 * @return the no solution improvement max generations
	 */
	public int getNoSolutionImprovementMaxGenerations() {
		return noSolutionImprovementMaxGenerations;
	}

	/**
	 * Sets the no solution improvement max generations.
	 *
	 * @param noSolutionImprovementMaxGenerations the new no solution improvement max generations
	 */
	public void setNoSolutionImprovementMaxGenerations(int noSolutionImprovementMaxGenerations) {
		this.noSolutionImprovementMaxGenerations = noSolutionImprovementMaxGenerations;
	}

	/**
	 * Gets the best current fitness.
	 *
	 * @return the best current fitness
	 */
	public double getBestCurrentFitness() {
		return bestCurrentFitness;
	}

	/**
	 * Sets the best current fitness.
	 *
	 * @param bestCurrentFitness the new best current fitness
	 */
	public void setBestCurrentFitness(double bestCurrentFitness) {
		this.bestCurrentFitness = bestCurrentFitness;
	}

	/**
	 * Gets the no solution improvement current generations.
	 *
	 * @return the no solution improvement current generations
	 */
	public int getNoSolutionImprovementCurrentGenerations() {
		return noSolutionImprovementCurrentGenerations;
	}

	/**
	 * Sets the no solution improvement current generations.
	 *
	 * @param noSolutionImprovementCurrentGenerations the new no solution improvement current generations
	 */
	public void setNoSolutionImprovementCurrentGenerations(int noSolutionImprovementCurrentGenerations) {
		this.noSolutionImprovementCurrentGenerations = noSolutionImprovementCurrentGenerations;
	}

	/**
	 * Checks if is stop condition met.
	 *
	 * @return true, if is stop condition met
	 */
	public boolean isStopConditionMet() {
		return stopConditionMet;
	}

	/**
	 * Sets the stop condition met.
	 *
	 * @param stopConditionMet the new stop condition met
	 */
	public void setStopConditionMet(boolean stopConditionMet) {
		this.stopConditionMet = stopConditionMet;
	}

}
