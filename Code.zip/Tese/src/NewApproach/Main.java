package NewApproach;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import ComparisonMethods.BottomUpVLSI;

/**
 * The Class Main.
 */
public class Main {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
		
		//in�cio da constru��o do Excel
		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Resultados");
        
        int rowNum = 0;
        Object[] datatype = {"#Run", "Initial Area","Stopping generation",/*"#Basic Rectangles", "#Chromosomes", "#Generations", "Mutation Probability",*/ "Best Initial Chromosome Fitness", "Compaction only fitness", 
        		"Time elapsed for Compaction only (ms)", "New approach fitness", "Time elapsed for new approach (ms)",
        		/*"BLF fitness", "Time elapsed for BLF (ms)", "FFDH fitness", "Time elapsed for FFDH (ms)", */
        		"BottomUpVLSI fitness", "Time elalpsed for BottomUpVLSI (ms)"};
        Row row = sheet.createRow(rowNum++);
        int colNum = 0;
    
        //escrever o header
        for (Object field : datatype) {
            Cell cell = row.createCell(colNum++);
            if (field instanceof String) {
                cell.setCellValue((String) field);
            } else if (field instanceof Integer) {
                cell.setCellValue((Integer) field);
            }
        }
        
        //ajustar o tamanho da colunas do header
        for(int i=0; i < colNum; i++) {
        	sheet.autoSizeColumn(i);
        }
        //fim da constru��o do Excel
        
        int seed = 10;
        
        Gui gui = new Gui("","","");
		GA ga = new GA(gui,seed);
		
		String type = gui.getTypeOfDoubleDimensions();
		String objFunction = gui.getObjectiveFunctionType();
		String cross = gui.getCrossoverType();
		
		//c�digo para usar sempre a mesma lista de ret�ngulos b�sicos em todas as runs - in�cio
		gui = new Gui(objFunction,type,cross);
		ga = new GA(gui,seed);
		ga.generateBasicRectangles(false, null);
		ArrayList<Rectangle> listSameRectangles = ga.getListOfRectangles();
		//fim
        
		System.out.println("Program starts!");		
		int runs = 12; //n�mero de runs do programa
		int c = 0;
		while(c<runs) {
			System.out.println("Run #" + (c+1) + " starts.");
			gui = new Gui(objFunction,type,cross);
			ga = new GA(gui,(seed * (c+1)));
			ga.generateBasicRectangles(true, listSameRectangles); //se a lista de ret�ngulos for sempre igual, manter o true no primeiro par�metro, sen�o colocar a false
			ga.generatePopulation();
			
			//come�a apenas alg. compacta��o 
			long startN = (System.currentTimeMillis());
			int a = (int) (Math.random()*ga.getNumberOfChromossomes());
			Cromossoma noGenetic = ga.getPopulation().get(a);
			noGenetic.fillListOfNonDominatedSolutions(ga.getInitialArea()); //alg. de compacta��o
			noGenetic.calculateFitness(gui.getObjectiveFunctionType()); // calcula o fitness segundo a escolha do crit�rio atrav�s do input do utilizador
			long finishN = (System.currentTimeMillis());
			//acaba apenas alg. compacta��o
			
			//come�a new approach
			long start = (System.currentTimeMillis());
			boolean first = true;
			int stoppingGeneration = 0;
			for (int i=0; i<ga.getNumberOfGenerations(); i++) {
				if(!ga.isStopConditionMet()) {	
					ga.evolvePopulation();
					ga.setNonDominatedSolutions();
					if(first) {
						ga.setBestInitialFitness();
						first = false;
					}
				} else {
					stoppingGeneration = i;
					break;
				}
				stoppingGeneration = i;
			}
			ga.fillListToShow();
			ga.getPopulation().get(0).orderListToPaint(); //ordena a lista de ret�ngulo a pintar
			gui.setCrom(ga.getPopulation().get(0)); //cromossoma com melhor fitness
			gui.computeSolutionToPaint(); //pinta a solu��o final
			long finish = (System.currentTimeMillis());
			//acaba new approach
			
			ArrayList<Rectangle> listOfBasics = ga.getListOfRectangles();
			
			/*//come�a BLF
			long startBLF = System.currentTimeMillis();			
			BLF blf = new BLF(listOfBasics,gui.getCrom().getMinimumDimension().getWidth());
			blf.setBLFfitness(gui.getObjectiveFunctionType());
			long finishBLF = System.currentTimeMillis();
			//acaba BLF*/
			
			/*/come�a FFDH
			long startFFDH = System.currentTimeMillis();
			FFDH ffdh = new FFDH(gui.getCrom().getMinimumDoubleDimension().getWidth(),listOfBasics);
			ffdh.setFFDHfitness(gui.getObjectiveFunctionType());
			long finishFFDH = System.currentTimeMillis();			
			//acaba FFDH*/
			
			//come�a BottomUpVLSI
			long startBuVLSI = System.currentTimeMillis();
			BottomUpVLSI buVLSI = new BottomUpVLSI(listOfBasics);
			buVLSI.calculateFitness(gui.getObjectiveFunctionType());
			long finishBuVLSI = System.currentTimeMillis();
			//acaba BottomUpVLSI
			
			Object[] data = {(double)(c+1), ga.getInitialArea(),stoppingGeneration,/*ga.getNumberOfRectangles(), ga.getNumberOfChromossomes(), ga.getNumberOfGenerations(), ga.getMutationProbability(),*/ 
					ga.getBestInitialFitness(),noGenetic.getFitness(),(double)(finishN - startN), gui.getCrom().getFitness(), 
					(double)(finish - start), /*String.valueOf(blf.getBLFfitness()).split("\\.")[0] + (blf.hasUnplacedItems() ? "*" : ""), 
					(double)(finishBLF - startBLF),	ffdh.getFFDHfitness(), (double)(finishFFDH - startFFDH),*/buVLSI.getFitness(),
					(double) (finishBuVLSI - startBuVLSI)};
			
			//escrever os dados para uma linha do Excel
	        row = sheet.createRow(rowNum);
	        colNum = 0;
			for (Object field : data) {
	            Cell cell = row.createCell(colNum++);
	            if (field instanceof String) {
	                cell.setCellValue((String) field);
	            } else if (field instanceof Double) {
	                cell.setCellValue((Double) field);
	            } else if (field instanceof Integer) {
	                cell.setCellValue((Integer) field);
	            }
	        }
			rowNum++;
			c++;
		}
		
		//in�cio da escrita do Excel no armazenamento local
		String seeD = ((seed == 0) ? "NoSeed" : "Seed");
		
		String FILE_NAME = "C:/Users/Rafael/Desktop/Tese/Testes/Execucao_"
				+ type + "_" + objFunction + "_" + cross + "_" + seeD + "_"
				+ ga.getNumberOfGenerations() + "_geracoes_"
				+ ga.getNumberOfChromossomes() + "_cromossomas_"
				+ ga.getNumberOfRectangles() + "_retangulos_"
				+ LocalDateTime.now().getYear() + "_" + LocalDateTime.now().getMonthValue()
				+ "_" + LocalDateTime.now().getDayOfMonth() + "_" + LocalDateTime.now().getHour()
				+ "_" + String.format("%2s", LocalDateTime.now().getMinute()).replace(' ', '0') 
				+ "_" + LocalDateTime.now().getSecond()+ ".xlsx";
		
	    try {
	        FileOutputStream outputStream = new FileOutputStream(FILE_NAME);
	        workbook.write(outputStream);
	        workbook.close();
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }    
	    //fim da escrita do Excel no armazenamento local
	        
	        System.out.println("Program ends!");
	}

}
