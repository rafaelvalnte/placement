package NewApproach;

/**
 * The Class DoubleDimension.
 */
public class DoubleDimension { /** The height. */
 //precis�o para 4 casas decimais
    double width, height;

    /**
     * Instantiates a new double dimension.
     */
    public DoubleDimension() {
    	
    }
    
    /**
     * Instantiates a new double dimension.
     *
     * @param width the width
     * @param height the height
     */
    public DoubleDimension(double width, double height) {
        super();
        this.width = Math.round(width*10000.0)/10000.0;
        this.height = Math.round(height*10000.0)/10000.0;
    }

    /**
     * Gets the width.
     *
     * @return the width
     */
    public double getWidth() {
        return width;
    }

    /**
     * Sets the width.
     *
     * @param width the new width
     */
    public void setWidth(double width) {
        this.width = Math.round(width*10000.0)/10000.0;;
    }

    /**
     * Gets the height.
     *
     * @return the height
     */
    public double getHeight() {
        return height;
    }

    /**
     * Sets the height.
     *
     * @param height the new height
     */
    public void setHeight(double height) {
        this.height = Math.round(height*10000.0)/10000.0;
    }
    
    /**
     * Sets the size.
     *
     * @param width the width
     * @param height the height
     */
    public void setSize(double width, double height) {
    	this.width = Math.round(width*10000.0)/10000.0;
        this.height = Math.round(height*10000.0)/10000.0;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "DoubleDimension [width=" + width + ", height=" + height + "]";
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        long temp;
        temp = Double.doubleToLongBits(height);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(width);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DoubleDimension other = (DoubleDimension) obj;
        if (Double.doubleToLongBits(height) != Double.doubleToLongBits(other.height))
            return false;
        if (Double.doubleToLongBits(width) != Double.doubleToLongBits(other.width))
            return false;
        return true;
    }
}