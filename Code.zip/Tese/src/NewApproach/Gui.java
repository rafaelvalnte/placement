package NewApproach;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * The Class Gui.
 */
public class Gui extends JFrame{
	
	/** The Constant OPT_AREA. */
	private static final String OPT_AREA = "�rea";
	
	/** The Constant OPT_SEMI_PERIMETER. */
	private static final String OPT_SEMI_PERIMETER = "Semiper�metro";
	
	/** The Constant OPTIONS_OBJECTIVE_FUNCTION. */
	private static final String[] OPTIONS_OBJECTIVE_FUNCTION = { OPT_AREA, OPT_SEMI_PERIMETER };
	
	/** The Constant OPT_CONTROLLED. */
	private static final String OPT_CONTROLLED = "Dimens�es controladas";
	
	/** The Constant OPT_RANDOM. */
	private static final String OPT_RANDOM = "Dimens�es aleat�rias";
	
	/** The Constant OPTIONS_DoubleDimensions. */
	private static final String[] OPTIONS_DoubleDimensions = { OPT_CONTROLLED, OPT_RANDOM  };
	
	/** The Constant OPT_OPC. */
	private static final String OPT_OPC = "One-point";
	
	/** The Constant OPT_RRC. */
	private static final String OPT_RRC = "Random Respectful";
	
	/** The Constant OPTIONS_CROSSOVER. */
	private static final String[] OPTIONS_CROSSOVER = { OPT_RRC, OPT_OPC  };
	
	/** The Constant paintMultiplier. */
	private static final int paintMultiplier = 500;
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The crom. */
	private Cromossoma crom;
	
	/** The list to find basic. */
	private ArrayList<Solution> listToFindBasic;
	
	/** The objective function. */
	private String objectiveFunction;
	
	/** The type of double dimensions. */
	private String typeOfDoubleDimensions;
	
	/** The crossover. */
	private String crossover;
	
	/** The is controlled double dimensions. */
	public boolean isControlledDoubleDimensions;

	
	/**
	 * Instantiates a new gui.
	 *
	 * @param objectiveFunctionInput the objective function input
	 * @param typeOfDoubleDimensionsInput the type of double dimensions input
	 * @param cross the cross
	 */
	public Gui(String objectiveFunctionInput, String typeOfDoubleDimensionsInput, String cross) {
		if(objectiveFunctionInput == "") {
			objectiveFunction = requestSelection("Fun��o fitness", OPTIONS_OBJECTIVE_FUNCTION);
		} else {
			objectiveFunction = objectiveFunctionInput;
		}
		if(typeOfDoubleDimensionsInput == "") {
			typeOfDoubleDimensions = requestSelection("Tipo de dimens�es", OPTIONS_DoubleDimensions);
		} else {
			typeOfDoubleDimensions = typeOfDoubleDimensionsInput;
		}
		if(cross == "") {
			crossover = requestSelection("Tipo de crossover", OPTIONS_CROSSOVER);
		} else {
			crossover = cross;
		}
		try {
			if(typeOfDoubleDimensions.equals(OPT_CONTROLLED)) {
				isControlledDoubleDimensions = true;
			} else {
				isControlledDoubleDimensions = false;
			}
		} catch (Exception a) {
			System.out.println("N�o foram escolhidas as op��es necess�rias. Por favor, execute novamente o programa.");
			System.exit(ABORT);
		}
	}

	/**
	 * Gets the objective function type.
	 *
	 * @return the objective function type
	 */
	public String getObjectiveFunctionType() {
		return objectiveFunction;
	}
	
	/**
	 * Sets the objective function type.
	 *
	 * @param objFunction the new objective function type
	 */
	public void setObjectiveFunctionType(String objFunction) {
		objectiveFunction = objFunction;
	}
	
	/**
	 * Gets the type of double dimensions.
	 *
	 * @return the type of double dimensions
	 */
	public String getTypeOfDoubleDimensions() {
		return typeOfDoubleDimensions;
	}
	
	/**
	 * Sets the type of double dimensions.
	 *
	 * @param type the new type of double dimensions
	 */
	public void setTypeOfDoubleDimensions(String type) {
		typeOfDoubleDimensions = type;
	}
	
	/**
	 * Gets the crossover type.
	 *
	 * @return the crossover type
	 */
	public String getCrossoverType() {
		return crossover;
	}
	
	/**
	 * Gets the opc.
	 *
	 * @return the opc
	 */
	public static String getOPC() {
		return OPT_OPC;
	}
	
	/**
	 * Gets the rrc.
	 *
	 * @return the rrc
	 */
	public static String getRRC() {
		return OPT_RRC;
	}
	
	/**
	 * Sets the crossover type.
	 *
	 * @param cross the new crossover type
	 */
	public void setCrossoverType(String cross) {
		crossover = cross;
	}
	
	/**
	 * Checks for controlled double dimensions.
	 *
	 * @return true, if successful
	 */
	public boolean hasControlledDoubleDimensions() {
		return isControlledDoubleDimensions;
	}

	/**
	 * Gets the crom.
	 *
	 * @return the crom
	 */
	public Cromossoma getCrom() {
		return crom;
	}

	/**
	 * Request selection.
	 *
	 * @param name the name
	 * @param options the options
	 * @return the string
	 */
	public static String requestSelection(String name, String[] options) {
		String option = ((String) JOptionPane.showInputDialog(null,
				"Escolha uma op��o", name, JOptionPane.QUESTION_MESSAGE,
				null, options, options[0]));
		return option;
	}
	
	/**
	 * Sets the crom.
	 *
	 * @param crom the new crom
	 */
	public void setCrom(Cromossoma crom) {
		this.crom = crom;
	}
	
	/**
	 * Gets the list to paint.
	 *
	 * @return the list to paint
	 */
	public ArrayList<Solution> getListToPaint() {
		return listToFindBasic;
	}

	/**
	 * Sets the list to paint.
	 *
	 * @param a the new list to paint
	 */
	public void setListToPaint(ArrayList<Solution> a) {
		listToFindBasic = a;
	}

	/**
	 * Compute solution to paint.
	 */
	public void computeSolutionToPaint() {
		NewPanel panel = new NewPanel();	
		JFrame frame = new JFrame("Solu��o final");
		frame.setSize((int)(crom.getMinimumDoubleDimension().getWidth()*paintMultiplier*2),(int)(crom.getMinimumDoubleDimension().getHeight()*paintMultiplier*4));
		frame.setLocation(100, 100);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		frame.setVisible(true);	
	}
	
	/**
	 * Gets the paint multiplier.
	 *
	 * @return the paint multiplier
	 */
	public static int getPaintMultiplier() {
		return paintMultiplier;
	}

	/**
	 * The Class NewPanel.
	 */
	class NewPanel extends JPanel {
		
		/** The Constant serialVersionUID. */
		private static final long serialVersionUID = 1L;

		/* (non-Javadoc)
		 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
		 */
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;	
			
			ArrayList<Solution> listToPaint = crom.getListToPaint();
			int it = 0;
			if(listToPaint.size() % 2 == 0) {
				it = (listToPaint.size()/2)-1;
			} else {
				it = listToPaint.size()/2;
			}
			
			Rectangle2D total = new Rectangle2D.Double(listToPaint.get(0).getPoint().getX()*paintMultiplier,
					listToPaint.get(0).getPoint().getY()*paintMultiplier, 
					listToPaint.get(0).getDim().getWidth()*paintMultiplier,
					listToPaint.get(0).getDim().getHeight()*paintMultiplier);
			
			g2.setColor(Color.BLACK); 
			g2.draw(total);
			
			boolean allow = false;
			for(int i = it; i < listToPaint.size(); i++) {
				
				Random rand = new Random();
				
//				Definir a cor do ret�ngulo
				float r = rand.nextFloat();
				float G = rand.nextFloat();
				float b = rand.nextFloat();
				
//				Definir a escala de cinzento do ret�ngulo - basta somar o valor de todas as componentes RGB e dividir por 3
//				A escala de cinzento � definida por todas as componentes RGB terem o mesmo valor
				float c = (r + G + b)/3;
				
				Rectangle2D rectFirst = new Rectangle2D.Double(listToPaint.get(i).getPoint().getX()*paintMultiplier,
						listToPaint.get(i).getPoint().getY()*paintMultiplier, 
						listToPaint.get(i).getLeftSon().getWidth()*paintMultiplier,
						listToPaint.get(i).getLeftSon().getHeight()*paintMultiplier);
				
				
				Rectangle2D rectSecond;
				
				if(listToPaint.get(i).getType() == "V") {
					rectSecond = new Rectangle2D.Double(listToPaint.get(i).getPoint().getX()*paintMultiplier + listToPaint.get(i).getLeftSon().getWidth()*paintMultiplier,
							listToPaint.get(i).getPoint().getY()*paintMultiplier, 
							listToPaint.get(i).getRightSon().getWidth()*paintMultiplier,
							listToPaint.get(i).getRightSon().getHeight()*paintMultiplier);
				} else {
					rectSecond = new Rectangle2D.Double(listToPaint.get(i).getPoint().getX()*paintMultiplier,
							listToPaint.get(i).getPoint().getY()*paintMultiplier + listToPaint.get(i).getLeftSon().getHeight()*paintMultiplier,
							listToPaint.get(i).getRightSon().getWidth()*paintMultiplier,
							listToPaint.get(i).getRightSon().getHeight()*paintMultiplier);
				}
				
				
				if(listToPaint.size() % 2 == 0 && !allow) { //se tiver um n�mero de cortes par, n�o queremos pintar o primeiro ret�ngulo do primeiro n�vel de b�sicos pois este ainda � um corte
					allow = true;
				} else {
//					g2.setColor(new Color(r,G,b)); //cores
					g2.setColor(new Color(c,c,c)); //grayscale
					g2.fill(rectFirst);
				}
								
				r = rand.nextFloat();
				G = rand.nextFloat();
				b = rand.nextFloat();
				c = (r + G + b)/3;
				
//				g2.setColor(new Color(r,G,b)); //cores
				g2.setColor(new Color(c,c,c)); //grayscale
				g2.fill(rectSecond);			
			}
		}
	}
}
