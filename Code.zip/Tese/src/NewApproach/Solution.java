package NewApproach;

import java.awt.Point;
import java.awt.geom.Point2D;

/**
 * The Class Solution.
 */
public class Solution {
	
	/** The dim. */
	private DoubleDimension dim;
	
	/** The left dim. */
	private DoubleDimension leftDim;
	
	/** The right dim. */
	private DoubleDimension rightDim;
	
	/** The where to start painting. */
	private Point2D whereToStartPainting;
	
	/** The type. */
	private String type; //saber se � corte vertical ou horizontal
	
	/** The state. */
	private int state = 0; //este atributo serve para saber em que fase do algoritmo de compacta��o se criou a solu��o n�o dominada: Juntar em Ordem(valor 0), 1 Atualizar(valor 1), 2 Atualizar (valor 2)ou 3 Atualizar(valor 3)
	
	/**
	 * Instantiates a new solution.
	 */
	public Solution() {
		whereToStartPainting = new Point();
	}

	/**
	 * Gets the dim.
	 *
	 * @return the dim
	 */
	public DoubleDimension getDim() {
		return dim;
	}

	/**
	 * Sets the dim.
	 *
	 * @param dim the new dim
	 */
	public void setDim(DoubleDimension dim) {
		this.dim = dim;
	}

	/**
	 * Gets the left son.
	 *
	 * @return the left son
	 */
	public DoubleDimension getLeftSon() {
		return leftDim;
	}

	/**
	 * Sets the left son.
	 *
	 * @param leftDim the new left son
	 */
	public void setLeftSon(DoubleDimension leftDim) {
		this.leftDim = leftDim;
	}

	/**
	 * Gets the right son.
	 *
	 * @return the right son
	 */
	public DoubleDimension getRightSon() {
		return rightDim;
	}

	/**
	 * Sets the right son.
	 *
	 * @param rightDim the new right son
	 */
	public void setRightSon(DoubleDimension rightDim) {
		this.rightDim = rightDim;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public int getState() {
		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(int state) {
		this.state = state;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * Gets the point.
	 *
	 * @return the point
	 */
	public Point2D getPoint() {
		return whereToStartPainting;
	}
	
	/**
	 * Sets the point.
	 *
	 * @param point2d the new point
	 */
	public void setPoint(Point2D point2d) {
		whereToStartPainting = point2d;
	}

}
