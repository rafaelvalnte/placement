package NewApproach;
import java.awt.geom.Point2D;
import java.util.ArrayList;


/**
 * The Class Cromossoma.
 */
public class Cromossoma {
	
	/** The cromossoma. */
	private ArrayList<Rectangle> cromossoma; 
	
	/** The list of all double dimensions. */
	private ArrayList<ArrayList<DoubleDimension>> listOfAllDoubleDimensions; //lista d[] do anexo
	
	/** The list of solutions. */
	private ArrayList<DoubleDimension> listOfSolutions; //lista c[] do anexo
	
	/** The list to paint. */
	private ArrayList<Solution> listToPaint;
	
	/** The fitness. */
	private double fitness;
	
	/** The minimum double dimension. */
	private DoubleDimension minimumDoubleDimension;
	
	/**
	 * Instantiates a new cromossoma.
	 */
	public Cromossoma() {
		listToPaint = new ArrayList<>();
		cromossoma = new ArrayList<>();
		listOfAllDoubleDimensions = new ArrayList<>();
		listOfSolutions = new ArrayList<>();
	}
	
	/**
	 * Fill list of all double dimensions.
	 */
	public void fillListOfAllDoubleDimensions() { //colocar em cada �ndice de d[i], a lista com os 2 pares de dimens�es poss�veis para cada rect�ngulo 
		for (int a=(cromossoma.size()/2); a<cromossoma.size(); a++) {
			listOfAllDoubleDimensions.add(cromossoma.get(a).getListOfDoubleDimensions());
		}
	}

	/**
	 * Gets the cromossoma.
	 *
	 * @return the cromossoma
	 */
	public ArrayList<Rectangle> getCromossoma() {
		return cromossoma;
	}

	/**
	 * Sets the cromossoma.
	 *
	 * @param cromossoma the new cromossoma
	 */
	public void setCromossoma(ArrayList<Rectangle> cromossoma) {
		this.cromossoma = cromossoma;
	}

	/**
	 * Gets the list of all double dimensions.
	 *
	 * @return the list of all double dimensions
	 */
	public ArrayList<ArrayList<DoubleDimension>> getListOfAllDoubleDimensions() {
		return listOfAllDoubleDimensions;
	}

	/**
	 * Sets the list of all double dimensions.
	 *
	 * @param listOfAllDoubleDimensions the new list of all double dimensions
	 */
	public void setListOfAllDoubleDimensions(ArrayList<ArrayList<DoubleDimension>> listOfAllDoubleDimensions) {
		this.listOfAllDoubleDimensions = listOfAllDoubleDimensions;
	}

	/**
	 * Gets the list of solutions.
	 *
	 * @return the list of solutions
	 */
	public ArrayList<DoubleDimension> getListOfSolutions() {
		return listOfSolutions;
	}

	/**
	 * Sets the list of solutions.
	 */
	public void setListOfSolutions() {
		listOfSolutions = cromossoma.get(0).getListOfDoubleDimensions();
	}

	 /**
 	 * Fill list of non dominated solutions.
 	 *
 	 * @param initialArea the initial area
 	 */
 	// algoritmo de compacta��o
	public void fillListOfNonDominatedSolutions(double initialArea) {
		for (int a=((cromossoma.size()/2)-1); a>=0; a--) { 
			/* O cromossoma tem a estrutura de cortes e b�sicos --> (e.g. "V,V,H,2,3,1,0")
			 * Portanto, vamos iterar sobre os cortes
			 */
			Rectangle cut = new Rectangle();
			cut = cromossoma.get(a);
			if(cut.getTipo() == "V") { //corte vertical
				//como em Java o primeiro elemento de um array tem o index 0, i e j s�o inicializados com esse valor
				int i = 0;
				int j = 0;
				Rectangle firstSon = new Rectangle();
				firstSon = cromossoma.get((a*2)+1);
				Rectangle secondSon = new Rectangle();
			    secondSon = cromossoma.get((a*2)+2);
				// k e m s�o o �ltimo index de um array
				int k = firstSon.getListOfDoubleDimensions().size()-1;
				int m = secondSon.getListOfDoubleDimensions().size()-1;
				while(i <= k && j <= m) { //Juntar em ordem
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>(); //os elementos que dominados n�o podem ser imediatamente removidos, sen�o existir� um erro IndexOutOfBounds
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(wi+wj,Math.max(hi, hj));
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(wi,hi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(wj,hj);
						sol.setRightSon(r);
						sol.setType("V");
						sol.setDim(nova);
						sol.setState(0);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=0; b<size; b++) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar = cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
								allow = false;
								cut.getListOfDoubleDimensions().add(b, nova);
								listToPaint.add(sol);
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
							listToPaint.add(sol);
							cut.getListOfDoubleDimensions().add(nova);
						}
					if (hi > hj) {
						i++;
					} else {
						if(hi < hj) {
							j++;
						} else {
							i++;
							j++;
						}
					}
				}
				i = k;
				j = m;
				while (i >= 0 && j >= 0) { //primeiro Atualizar
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(hi + hj, Math.max(wi,wj));
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(hi,wi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(hj,wj);
						sol.setRightSon(r);
						sol.setType("V");
						sol.setDim(nova);
						sol.setState(1);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=0; b<size; b++) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar = cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
								allow = false;
								cut.getListOfDoubleDimensions().add(b, nova);
								listToPaint.add(sol);
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
							listToPaint.add(sol);
							cut.getListOfDoubleDimensions().add(nova);
						}
					if (wi > wj) {
						i--;
					} else {
						if(wi < wj) {
							j--;
						} else {
							i--;
							j--;
						}
					}
				}
				i = 0;
				j = m;
				while (i <= k && j >= 0) { //segundo Atualizar
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(hj + wi, Math.max(hi,wj));
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(wi,hi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(hj,wj);
						sol.setRightSon(r);
						sol.setType("V");
						sol.setDim(nova);
						sol.setState(2);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=0; b<size; b++) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar = cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
								allow = false;
								listToPaint.add(sol);
								cut.getListOfDoubleDimensions().add(b, nova);
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
							listToPaint.add(sol);
							cut.getListOfDoubleDimensions().add(nova);
						}
					if (hi > wj) {
						i++;
					} else {
						if(hi < wj) {
							j--;
						} else {
							i++;
							j--;
						}
					}
				}
				i = k;
				j = 0;
				while (i >= 0 && j <= m) { //terceiro Atualizar
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(hi+ wj, Math.max(wi,hj));
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(hi,wi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(wj,hj);
						sol.setRightSon(r);
						sol.setType("V");
						sol.setDim(nova);
						sol.setState(3);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=0; b<size; b++) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar =	cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() <= nova.getWidth() && aComparar.getHeight() > nova.getHeight()) {
								allow = false;
								listToPaint.add(sol);
								cut.getListOfDoubleDimensions().add(b, nova);
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como �ltimo da lista
							listToPaint.add(sol);
							cut.getListOfDoubleDimensions().add(nova);
						}
					if (wi > hj) {
						i--;
					} else {
						if(wi < hj) {
							j++;
						} else {
							i--;
							j++;
						}
					}					
				}
				
			} else { //corte horizontal
				int i = 0;
				int j = 0;
				Rectangle firstSon = new Rectangle();
				firstSon = cromossoma.get((a*2)+1);
				Rectangle secondSon = new Rectangle();
				secondSon =	cromossoma.get((a*2)+2);
				// k e m s�o o �ltimo index de um array
				int k = firstSon.getListOfDoubleDimensions().size()-1;
				int m = secondSon.getListOfDoubleDimensions().size()-1;
				while(i <= k && j <= m) { //Juntar em ordem
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(Math.max(wi, wj),hi+hj);
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(wi,hi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(wj,hj);
						sol.setRightSon(r);
						sol.setType("H");
						sol.setDim(nova);
						sol.setState(0);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=size-1; b>=0; b--) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar = cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha largura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
								allow = false;
								listToPaint.add(sol);
								cut.getListOfDoubleDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeiro da lista
							listToPaint.add(0, sol);
							cut.getListOfDoubleDimensions().add(0, nova);
						}
					if (hi > hj) {
						i++;
					} else {
						if(hi < hj) {
							j++;
						} else {
							i++;
							j++;
						}
					}
				}
				i = k;
				j = m;
				while (i >= 0 && j >= 0) { //primeiro Atualizar
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(Math.max(hi,hj),wi + wj);
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(hi,wi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(hj,wj);
						sol.setRightSon(r);
						sol.setType("H");
						sol.setDim(nova);
						sol.setState(1);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=size-1; b>=0; b--) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar = cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha largura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
								allow = false;
								listToPaint.add(sol);
								cut.getListOfDoubleDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeir da lista
							listToPaint.add(0, sol);
							cut.getListOfDoubleDimensions().add(0, nova);
						}
					if (wi > wj) {
						i--;
					} else {
						if(wi < wj) {
							j--;
						} else {
							i--;
							j--;
						}
					}
				}
				i = 0;
				j = m;
				while (i <= k && j >= 0) { //segundo Atualizar
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(Math.max(wi,hj),wj + hi);
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(wi,hi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(hj,wj);
						sol.setRightSon(r);
						sol.setDim(nova);
						sol.setType("H");
						sol.setState(2);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=size-1; b>=0; b--) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar = cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha largura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
								allow = false;
								listToPaint.add(sol);
								cut.getListOfDoubleDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeiro da lista
							listToPaint.add(0, sol);
							cut.getListOfDoubleDimensions().add(0, nova);
						}
					if (hi > wj) {
						i++;
					} else {
						if(hi < wj) {
							j--;
						} else {
							i++;
							j--;
						}
					}
				}
				i = k;
				j = 0;
				while (i >= 0 && j <= m) { //terceiro Atualizar
					ArrayList<DoubleDimension> DoubleDimensionsToDelete = new ArrayList<>();
					boolean allow = true;
					double hi = firstSon.getListOfDoubleDimensions().get(i).getHeight();
					double hj = secondSon.getListOfDoubleDimensions().get(j).getHeight();
					double wi = firstSon.getListOfDoubleDimensions().get(i).getWidth();
					double wj = secondSon.getListOfDoubleDimensions().get(j).getWidth();
					DoubleDimension nova = new DoubleDimension();
					nova.setSize(Math.max(hi,wj),wi + hj);
						Solution sol = new Solution();
						DoubleDimension l = new DoubleDimension(hi,wi);
						sol.setLeftSon(l);
						DoubleDimension r = new DoubleDimension(wj,hj);
						sol.setRightSon(r);
						sol.setDim(nova);
						sol.setType("H");
						sol.setState(3);
						int size = cut.getListOfDoubleDimensions().size();
						for (int b=size-1; b>=0; b--) {
							DoubleDimension aComparar = new DoubleDimension();
							aComparar = cut.getListOfDoubleDimensions().get(b);
							//se encontrar um novo par que este domine, remover imediatamente esse velho par da lista e continuar a procura nos restante
							if(aComparar.getHeight() > nova.getHeight() && aComparar.getWidth() >= nova.getWidth() || aComparar.getHeight() >= nova.getHeight() && aComparar.getWidth() > nova.getWidth()) {
								DoubleDimensionsToDelete.add(aComparar);
							}
							//se este novo par for dominado por um que j� existe na lista, parar o for e desistir deste novo par
							if (aComparar.getHeight() <= nova.getHeight() && aComparar.getWidth() <= nova.getWidth()) {
								allow = false;
								break;
							}
							//se encontrar um que seja n�o dominado (w',h') mas que tenha altura menor que este, juntar imediatamente este (w,h) como anterior a (w',h')
							if(aComparar.getWidth() > nova.getWidth() && aComparar.getHeight() <= nova.getHeight()) {
								allow = false;
								listToPaint.add(sol);
								cut.getListOfDoubleDimensions().add((b+1), nova); //b+1 para juntar anteriormente pois a itera��o � de size para 0
								break;
							}
						}
						for(int b=0; b<size; b++) {
							if(nova.getHeight() == cut.getListOfDoubleDimensions().get(b).getHeight() && nova.getWidth() == cut.getListOfDoubleDimensions().get(b).getWidth()) {
								allow = false;
								break;
							}
						}
						if (allow) { // se chegar ao fim da lista, este novo (w,h) insere-se como primeiro da lista
							listToPaint.add(0, sol);
							cut.getListOfDoubleDimensions().add(0, nova);
						}
					if (wi > hj) {
						i--;
					} else {
						if(wi < hj) {
							j++;
						} else {
							i--;
							j++;
						}
					}					
				}
			}
		}	
	}

	/**
	 * Gets the fitness.
	 *
	 * @return the fitness
	 */
	public double getFitness() {
		return fitness;
	}

	/**
	 * Sets the fitness.
	 *
	 * @param fitness the new fitness
	 */
	public void setFitness(double fitness) {
		this.fitness = fitness;
	}

	/**
	 * Calculate fitness.
	 *
	 * @param value the value
	 */
	public void calculateFitness(String value) { 
		setListOfSolutions();
		if (value == "�rea") {
			DoubleDimension min = new DoubleDimension();
			double minArea = Double.MAX_VALUE;
			for (int i = 0; i<listOfSolutions.size(); i++) {
				DoubleDimension dim = listOfSolutions.get(i);
				double h = dim.getHeight();
				double w = dim.getWidth();
				double area = h * w;
				if(area < minArea) {
					min = dim;
					minArea = area;
				}
			}
			double fit = (min.getHeight()*min.getWidth());
			setMinimumDoubleDimension(min);
			setFitness(fit);
		} else {
			if(value == "Semiper�metro"){
				DoubleDimension min = new DoubleDimension();
				double minPer = Double.MAX_VALUE;
				for (int i = 0; i<listOfSolutions.size(); i++) {
					DoubleDimension dim = listOfSolutions.get(i);
					double h = dim.getHeight();
					double w = dim.getWidth();
					double per = Math.pow(h, 2) + Math.pow(w, 2);
					if(per < minPer) {
						min = dim;
						minPer = per;
					}
				}
				double fit = Math.pow(min.getHeight(),2) + Math.pow(min.getWidth(),2);
				setMinimumDoubleDimension(min);
				setFitness(fit);
			}
		}
	}
	
	/**
	 * Clear cut dimensions list.
	 */
	public void clearCutDimensionsList() {
		ArrayList<DoubleDimension> newListOfDimensions = new ArrayList<>();
		for (int a=((cromossoma.size()/2)-1); a>=0; a--) {
			cromossoma.get(a).setListOfDoubleDimensions(newListOfDimensions);
		}
	}

	/**
	 * Gets the minimum double dimension.
	 *
	 * @return the minimum double dimension
	 */
	public DoubleDimension getMinimumDoubleDimension() {
		return minimumDoubleDimension;
	}

	/**
	 * Sets the minimum double dimension.
	 *
	 * @param minimumDoubleDimension the new minimum double dimension
	 */
	public void setMinimumDoubleDimension(DoubleDimension minimumDoubleDimension) {
		this.minimumDoubleDimension = minimumDoubleDimension;
	}

	/**
	 * Gets the list to paint.
	 *
	 * @return the list to paint
	 */
	public ArrayList<Solution> getListToPaint() {
		return listToPaint;
	}

	/**
	 * Sets the list to paint.
	 *
	 * @param listToPaint the new list to paint
	 */
	public void setListToPaint(ArrayList<Solution> listToPaint) {
		this.listToPaint = listToPaint;
	}

	/**
	 * Order list to paint.
	 */
	public void orderListToPaint() {
		//remover as solu��es dominadas
		int indexToRemove = 0;
		int newIt = listToPaint.size();
		boolean removes = false;
		while(newIt > 0) {
			for(int i = 0; i < listToPaint.size(); i++) {
				if((listToPaint.get(i).getDim().getHeight()*listToPaint.get(i).getDim().getWidth()) > 
				minimumDoubleDimension.getHeight()*minimumDoubleDimension.getWidth()) {
					indexToRemove = i;
					removes = true;
					break;
				}
			}
			if(removes) {
				listToPaint.remove(indexToRemove);
				removes = false;
				indexToRemove = 0;
			}			
			newIt--;
		}
		
		int it = cromossoma.size();
		Solution[] newOrderedListToPaint = new Solution[it];
		boolean pastRoot = false;
		while (it > 0) {
			for(int i = 0; i < listToPaint.size(); i++) {
				if(pastRoot) {
					for(int j = 0; j < newOrderedListToPaint.length; j++) {
						if(newOrderedListToPaint[j] != null) {
							if(listToPaint.get(i).getDim().getWidth() == newOrderedListToPaint[j].getLeftSon().getWidth() &&
									listToPaint.get(i).getDim().getHeight() == newOrderedListToPaint[j].getLeftSon().getHeight()) {
								Point2D.Double point = new Point2D.Double(newOrderedListToPaint[j].getPoint().getX(),
																		  newOrderedListToPaint[j].getPoint().getY());
								Solution a = new Solution();
								a.setType(listToPaint.get(i).getType());
								a.setState(listToPaint.get(i).getState());
								a.setPoint(point);
								a.setDim(listToPaint.get(i).getDim());
								a.setLeftSon(listToPaint.get(i).getLeftSon());
								a.setRightSon(listToPaint.get(i).getRightSon());
								if(newOrderedListToPaint[2*j+1] == null) {
									newOrderedListToPaint[2*j+1] = a;
								}
							}
							if(listToPaint.get(i).getDim().getWidth() == newOrderedListToPaint[j].getLeftSon().getHeight() &&
									listToPaint.get(i).getDim().getHeight() == newOrderedListToPaint[j].getLeftSon().getWidth()) {
								Point2D.Double point = new Point2D.Double(newOrderedListToPaint[j].getPoint().getX(),
																		  newOrderedListToPaint[j].getPoint().getY());
								Solution a = new Solution();
								if(listToPaint.get(i).getType() == "V") {
									a.setType("H");
								} else {
									a.setType("V");
								}
								a.setState(listToPaint.get(i).getState());
								a.setPoint(point);
								a.setDim(new DoubleDimension(listToPaint.get(i).getDim().getHeight(),listToPaint.get(i).getDim().getWidth()));
								a.setLeftSon(new DoubleDimension(listToPaint.get(i).getLeftSon().getHeight(),listToPaint.get(i).getLeftSon().getWidth()));
								a.setRightSon(new DoubleDimension(listToPaint.get(i).getRightSon().getHeight(),listToPaint.get(i).getRightSon().getWidth()));
								if(newOrderedListToPaint[2*j+1] == null) {
									newOrderedListToPaint[2*j+1] = a;
									
								}
							}
							if(listToPaint.get(i).getDim().getWidth() == newOrderedListToPaint[j].getRightSon().getWidth() &&
									listToPaint.get(i).getDim().getHeight() == newOrderedListToPaint[j].getRightSon().getHeight()) {
								Point2D.Double point = new Point2D.Double(newOrderedListToPaint[j].getPoint().getX(),
																		  newOrderedListToPaint[j].getPoint().getY());
								if(newOrderedListToPaint[j].getType() == "V") {
									point.setLocation(newOrderedListToPaint[j].getPoint().getX() + newOrderedListToPaint[j].getLeftSon().getWidth(),
											newOrderedListToPaint[j].getPoint().getY());
								} else {
									point.setLocation(newOrderedListToPaint[j].getPoint().getX(),
											newOrderedListToPaint[j].getPoint().getY()  + newOrderedListToPaint[j].getLeftSon().getHeight());
								}
								Solution a = new Solution();
								a.setType(listToPaint.get(i).getType());
								a.setState(listToPaint.get(i).getState());
								a.setPoint(point);
								a.setDim(listToPaint.get(i).getDim());
								a.setLeftSon(listToPaint.get(i).getLeftSon());
								a.setRightSon(listToPaint.get(i).getRightSon());
								if(newOrderedListToPaint[2*j+2] == null) {
									newOrderedListToPaint[2*j+2] = a;
								}
							}
							if(listToPaint.get(i).getDim().getWidth() == newOrderedListToPaint[j].getRightSon().getHeight() &&
									listToPaint.get(i).getDim().getHeight() == newOrderedListToPaint[j].getRightSon().getWidth()) {
								Point2D.Double point = new Point2D.Double(newOrderedListToPaint[j].getPoint().getX(),newOrderedListToPaint[j].getPoint().getY());
								if(newOrderedListToPaint[j].getType() == "V") {
									point.setLocation(newOrderedListToPaint[j].getPoint().getX() + newOrderedListToPaint[j].getLeftSon().getWidth(),
											newOrderedListToPaint[j].getPoint().getY());
								} else {
									point.setLocation(newOrderedListToPaint[j].getPoint().getX(),
											newOrderedListToPaint[j].getPoint().getY()  + newOrderedListToPaint[j].getLeftSon().getHeight());
								}
								Solution a = new Solution();
								if(listToPaint.get(i).getType() == "V") {
									a.setType("H");
								} else {
									a.setType("V");
								}
								a.setState(listToPaint.get(i).getState());
								a.setPoint(point);
								a.setDim(new DoubleDimension(listToPaint.get(i).getDim().getHeight(),listToPaint.get(i).getDim().getWidth()));
								a.setLeftSon(new DoubleDimension(listToPaint.get(i).getLeftSon().getHeight(),listToPaint.get(i).getLeftSon().getWidth()));
								a.setRightSon(new DoubleDimension(listToPaint.get(i).getRightSon().getHeight(),listToPaint.get(i).getRightSon().getWidth()));
								if(newOrderedListToPaint[2*j+2] == null) {
									newOrderedListToPaint[2*j+2] = a;
								}
							}
						}
					}	
				}				
				if(listToPaint.get(i).getDim() == minimumDoubleDimension && !pastRoot) {
					listToPaint.get(i).setPoint(new Point2D.Double(0.0,0.0));
					pastRoot = true;
					newOrderedListToPaint[0] = listToPaint.get(i);
				}
			}
			it--;
		}
		
		listToPaint.clear();
		for (int i = 0; i < newOrderedListToPaint.length; i++) {
			if(newOrderedListToPaint[i] != null) {
				listToPaint.add(newOrderedListToPaint[i]);
			}
		}
		
	}

}
