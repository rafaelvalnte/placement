package NewApproach;

import java.awt.Point;
import java.util.ArrayList;

/**
 * The Class Rectangle.
 */
public class Rectangle {
	
	/** The height. */
	private double height;
	
	/** The width. */
	private double width;
	
	/** The tipo. */
	private String tipo;
	
	/** The id. */
	private int id;
	
	/** The dimension list. */
	private ArrayList<DoubleDimension> dimensionList;
	
	/** The is cut. */
	private boolean isCut;
	
	/** The is basic. */
	private boolean isBasic;
	
	/** The controled dimension list. */
	private static ArrayList<DoubleDimension> controledDimensionList;
	
	/** The bottom left coordinate. */
	private Point bottomLeftCoordinate;
	
	/**
	 * Instantiates a new rectangle.
	 */
	public Rectangle() {
		dimensionList = new ArrayList<>();
		bottomLeftCoordinate = new Point(0,0);
	}
	
	/**
	 * Instantiates a new rectangle.
	 *
	 * @param height the height
	 * @param width the width
	 * @param tipo the tipo
	 * @param id the id
	 * @param dimensions the dimensions
	 * @param isCut the is cut
	 * @param isBasic the is basic
	 * @param BLC the blc
	 */
	public Rectangle(double height, double width, String tipo, int id, ArrayList<DoubleDimension> dimensions, 
			boolean isCut, boolean isBasic, Point BLC) {
		this.height = height;
		this.width = width;
		this.tipo = tipo;
		this.id = id;
		this.dimensionList = dimensions;
		this.isCut = isCut;
		this.isBasic = isBasic;
		this.bottomLeftCoordinate = BLC;
	}
	
	/**
	 * Instantiates a new rectangle.
	 *
	 * @param width the width
	 * @param height the height
	 */
	public Rectangle(int width, int height) {
		this.width = width;
		this.height = height;
	}

	/**
	 * Sets the double dimensions of basic.
	 */
	public void setDoubleDimensionsOfBasic() {
		isBasic = true;
		setTipo("Basic");
		setWidth((int)(Math.random()*50)+1);
		setHeight((int)(Math.random()*50)+1);
	}
	
	/**
	 * Sets the controlled double dimensions of basic.
	 *
	 * @param ind the new controlled double dimensions of basic
	 */
	public void setControlledDoubleDimensionsOfBasic(int ind) {
		isBasic = true;
		setTipo("Basic");		
		for (int i=0; i<controledDimensionList.size(); i++) {
			if(i==ind) {
				setWidth(controledDimensionList.get(i).getWidth());
				setHeight(controledDimensionList.get(i).getHeight());
				break;
			}
		}
	}
	
	/**
	 * Creates the controlled double dimensions of basic.
	 */
	public static void createControlledDoubleDimensionsOfBasic() {
		controledDimensionList = new ArrayList<>();
		
		//MCNC benchmarks
		
		// APTE - Optimal area (sum of all module areas) = 46.5616 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(3.146,1.826);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(3.146,1.826);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(3.146,1.826);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(3.146,1.826);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(3.186,1.832);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(3.186,1.832);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(3.186,1.832);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(3.186,1.832);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.826, 0.286);
		controledDimensionList.add(i);
		
		*/
		
		// XEROX - Optimal area (sum of all module areas) = 19.3503 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(1.295,0.616);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(1.295,0.49);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(1.295,2.534);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(1.295,2.569);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.756,0.84);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(1.162,1.939);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(1.218,1.652);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.882,1.316);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(1.295,2.114);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(1.295,1.939);
		controledDimensionList.add(j);
		
		*/
		
		//HP - Optimal area (sum of all module areas) = 8.8306 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(1.036,0.462);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.378,0.7);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.98,0.21);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.98,0.21);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.98,0.21);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(3.304,0.546);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(3.304,0.546);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(2.016,0.252);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(3.08,0.462);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(2.016,0.252);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(3.08,0.462);
		controledDimensionList.add(k);
		
		*/
		
		//AMI33 - Optimal area (sum of all module areas) = 1.1564 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(0.336,0.133);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.378,0.119);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.161,0.14);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.119,0.049);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.175,0.119);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(0.14,0.406);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.14,0.497);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.196,0.119);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.294,0.119);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.161,0.119);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(0.119,0.266);
		controledDimensionList.add(k);
		DoubleDimension l = new DoubleDimension(0.119,0.336);
		controledDimensionList.add(l);
		DoubleDimension m = new DoubleDimension(0.119,0.126);
		controledDimensionList.add(m);
		DoubleDimension n = new DoubleDimension(0.371,0.182);
		controledDimensionList.add(n);
		DoubleDimension o = new DoubleDimension(0.182,0.203);
		controledDimensionList.add(o);
		DoubleDimension p = new DoubleDimension(0.182,0.203);
		controledDimensionList.add(p);
		DoubleDimension q = new DoubleDimension(0.084,0.119);
		controledDimensionList.add(q);
		DoubleDimension r = new DoubleDimension(0.133,0.294);
		controledDimensionList.add(r);
		DoubleDimension s = new DoubleDimension(0.182,0.35);
		controledDimensionList.add(s);
		DoubleDimension t = new DoubleDimension(0.315,0.14);
		controledDimensionList.add(t);
		DoubleDimension u = new DoubleDimension(0.133,0.315);
		controledDimensionList.add(u);
		DoubleDimension v = new DoubleDimension(0.56,0.133);
		controledDimensionList.add(v);
		DoubleDimension w = new DoubleDimension(0.133,0.14);
		controledDimensionList.add(w);
		DoubleDimension x = new DoubleDimension(0.175,0.133);
		controledDimensionList.add(x);
		DoubleDimension y = new DoubleDimension(0.133,0.231);
		controledDimensionList.add(y);
		DoubleDimension z = new DoubleDimension(0.133,0.315);
		controledDimensionList.add(z);
		DoubleDimension a1 = new DoubleDimension(0.182,0.098);
		controledDimensionList.add(a1);
		DoubleDimension b1 = new DoubleDimension(0.21,0.21);
		controledDimensionList.add(b1);
		DoubleDimension c1 = new DoubleDimension(0.126,0.378);
		controledDimensionList.add(c1);	
		DoubleDimension d1 = new DoubleDimension(0.182,0.119);
		controledDimensionList.add(d1);
		DoubleDimension e1 = new DoubleDimension(0.119,0.119);
		controledDimensionList.add(e1);
		DoubleDimension f1 = new DoubleDimension(0.357,0.119);
		controledDimensionList.add(f1);
		DoubleDimension g1 = new DoubleDimension(0.119,0.084);
		controledDimensionList.add(g1);
		
		*/
		
		//AMI49 - Optimal area (sum of all module areas) = 35.4454 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(1.708,3.234);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.672,1.554);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(2.184,1.008);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(3.08,1.61);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.532,1.386);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(1.862,0.882);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.35,0.868);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.644,1.246);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.98,0.462);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.294,0.616);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(0.826,0.378);
		controledDimensionList.add(k);
		DoubleDimension l = new DoubleDimension(0.798,0.406);
		controledDimensionList.add(l);
		DoubleDimension m = new DoubleDimension(0.266,0.672);
		controledDimensionList.add(m);
		DoubleDimension n = new DoubleDimension(0.406,0.924);
		controledDimensionList.add(n);
		DoubleDimension o = new DoubleDimension(0.406,0.84);
		controledDimensionList.add(o);
		DoubleDimension p = new DoubleDimension(0.322,0.798);
		controledDimensionList.add(p);
		DoubleDimension q = new DoubleDimension(0.392,0.756);
		controledDimensionList.add(q);
		DoubleDimension r = new DoubleDimension(1.078,0.392);
		controledDimensionList.add(r);
		DoubleDimension s = new DoubleDimension(0.392,0.826);
		controledDimensionList.add(s);
		DoubleDimension t = new DoubleDimension(0.798,0.252);
		controledDimensionList.add(t);
		DoubleDimension u = new DoubleDimension(0.392,0.826);
		controledDimensionList.add(u);
		DoubleDimension v = new DoubleDimension(0.952,0.364);
		controledDimensionList.add(v);
		DoubleDimension w = new DoubleDimension(1.134,0.49);
		controledDimensionList.add(w);
		DoubleDimension x = new DoubleDimension(0.798,0.266);
		controledDimensionList.add(x);
		DoubleDimension y = new DoubleDimension(0.784,0.322);
		controledDimensionList.add(y);
		DoubleDimension z = new DoubleDimension(0.35,0.728);
		controledDimensionList.add(z);
		DoubleDimension a1 = new DoubleDimension(0.364,0.84);
		controledDimensionList.add(a1);
		DoubleDimension b1 = new DoubleDimension(0.518,1.064);
		controledDimensionList.add(b1);
		DoubleDimension c1 = new DoubleDimension(0.49,0.994);
		controledDimensionList.add(c1);
		DoubleDimension d1 = new DoubleDimension(1.302,0.728);
		controledDimensionList.add(d1);	
		DoubleDimension e1 = new DoubleDimension(0.392,1.05);
		controledDimensionList.add(e1);
		DoubleDimension f1 = new DoubleDimension(0.784,0.378);
		controledDimensionList.add(f1);
		DoubleDimension g1 = new DoubleDimension(1.89,0.952);
		controledDimensionList.add(g1);
		DoubleDimension h1 = new DoubleDimension(0.56,1.148);
		controledDimensionList.add(h1);
		DoubleDimension i1 = new DoubleDimension(0.854,0.392);
		controledDimensionList.add(i1);
		DoubleDimension j1 = new DoubleDimension(0.994,0.448);
		controledDimensionList.add(j1);
		DoubleDimension k1 = new DoubleDimension(1.218,0.56);
		controledDimensionList.add(k1);
		DoubleDimension l1 = new DoubleDimension(0.448,0.966);
		controledDimensionList.add(l1);
		DoubleDimension m1 = new DoubleDimension(0.364,0.784);
		controledDimensionList.add(m1);
		DoubleDimension n1 = new DoubleDimension(0.392,0.868);
		controledDimensionList.add(n1);
		DoubleDimension o1 = new DoubleDimension(0.364,0.854);
		controledDimensionList.add(o1);
		DoubleDimension p1 = new DoubleDimension(0.168,0.378);
		controledDimensionList.add(p1);
		DoubleDimension q1 = new DoubleDimension(0.91,0.532);
		controledDimensionList.add(q1);
		DoubleDimension r1 = new DoubleDimension(0.63,1.302);
		controledDimensionList.add(r1);
		DoubleDimension s1 = new DoubleDimension(0.672,1.162);
		controledDimensionList.add(s1);
		DoubleDimension t1 = new DoubleDimension(1.204,0.504);
		controledDimensionList.add(t1);
		DoubleDimension u1 = new DoubleDimension(0.434,0.812);
		controledDimensionList.add(u1);
		DoubleDimension v1 = new DoubleDimension(1.302,0.728);
		controledDimensionList.add(v1);
		DoubleDimension w1 = new DoubleDimension(0.392,0.742);
		controledDimensionList.add(w1);
		
		*/
		
		//GSRC bechmarks
		
		//10blocks - Optimal area (sum of all module areas) = 0.221679 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(0.199,0.082);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.229,0.105);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.061,0.117);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.114,0.167);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.091,0.208);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(0.208,0.129);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.123,0.108);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.235,0.179);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.152,0.193);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.126,0.196);
		controledDimensionList.add(j);
		
		*/
		
		//30blocks - Optimal area (sum of all module areas) = 0.208591 mm2
		/*
		 
		 DoubleDimension a = new DoubleDimension(0.117,0.106);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.044,0.045);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.057,0.098);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.134,0.078);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.079,0.088);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(0.103,0.037);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.062,0.078);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.108,0.079);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.127,0.064);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.112,0.108);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(0.089,0.035);
		controledDimensionList.add(k);
		DoubleDimension l = new DoubleDimension(0.074,0.052);
		controledDimensionList.add(l);
		DoubleDimension m = new DoubleDimension(0.084,0.095);
		controledDimensionList.add(m);
		DoubleDimension n = new DoubleDimension(0.062,0.064);
		controledDimensionList.add(n);
		DoubleDimension o = new DoubleDimension(0.084,0.113);
		controledDimensionList.add(o);
		DoubleDimension p = new DoubleDimension(0.039,0.112);
		controledDimensionList.add(p);
		DoubleDimension q = new DoubleDimension(0.069,0.134);
		controledDimensionList.add(q);
		DoubleDimension r = new DoubleDimension(0.071,0.132);
		controledDimensionList.add(r);
		DoubleDimension s = new DoubleDimension(0.042,0.106);
		controledDimensionList.add(s);
		DoubleDimension t = new DoubleDimension(0.103,0.120);
		controledDimensionList.add(t);
		DoubleDimension u = new DoubleDimension(0.134,0.127);
		controledDimensionList.add(u);
		DoubleDimension v = new DoubleDimension(0.098,0.045);
		controledDimensionList.add(v);
		DoubleDimension w = new DoubleDimension(0.089,0.081);
		controledDimensionList.add(w);
		DoubleDimension x = new DoubleDimension(0.050,0.130);
		controledDimensionList.add(x);
		DoubleDimension y = new DoubleDimension(0.049,0.108);
		controledDimensionList.add(y);
		DoubleDimension z = new DoubleDimension(0.118,0.035);
		controledDimensionList.add(z);
		DoubleDimension a1 = new DoubleDimension(0.067,0.130);
		controledDimensionList.add(a1);
		DoubleDimension b1 = new DoubleDimension(0.037,0.033);
		controledDimensionList.add(b1);
		DoubleDimension c1 = new DoubleDimension(0.071,0.125);
		controledDimensionList.add(c1);	
		DoubleDimension d1 = new DoubleDimension(0.045,0.050);
		controledDimensionList.add(d1);
		 
		*/
		
		//50blocks - Optimal area (sum of all module areas) = 0.198579 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(0.096,0.094);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.026,0.078);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.026,0.076);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.096,0.025);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.075,0.092);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(0.064,0.058);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.036,0.031);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.045,0.091);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.038,0.080);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.043,0.064);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(0.026,0.051);
		controledDimensionList.add(k);
		DoubleDimension l = new DoubleDimension(0.043,0.080);
		controledDimensionList.add(l);
		DoubleDimension m = new DoubleDimension(0.039,0.058);
		controledDimensionList.add(m);
		DoubleDimension n = new DoubleDimension(0.092,0.050);
		controledDimensionList.add(n);
		DoubleDimension o = new DoubleDimension(0.027,0.028);
		controledDimensionList.add(o);
		DoubleDimension p = new DoubleDimension(0.096,0.072);
		controledDimensionList.add(p);
		DoubleDimension q = new DoubleDimension(0.042,0.043);
		controledDimensionList.add(q);
		DoubleDimension r = new DoubleDimension(0.061,0.094);
		controledDimensionList.add(r);
		DoubleDimension s = new DoubleDimension(0.070,0.072);
		controledDimensionList.add(s);
		DoubleDimension t = new DoubleDimension(0.030,0.086);
		controledDimensionList.add(t);
		DoubleDimension u = new DoubleDimension(0.087,0.049);
		controledDimensionList.add(u);
		DoubleDimension v = new DoubleDimension(0.094,0.076);
		controledDimensionList.add(v);
		DoubleDimension w = new DoubleDimension(0.074,0.080);
		controledDimensionList.add(w);
		DoubleDimension x = new DoubleDimension(0.064,0.080);
		controledDimensionList.add(x);
		DoubleDimension y = new DoubleDimension(0.066,0.027);
		controledDimensionList.add(y);
		DoubleDimension z = new DoubleDimension(0.082,0.086);
		controledDimensionList.add(z);
		DoubleDimension a1 = new DoubleDimension(0.036,0.049);
		controledDimensionList.add(a1);
		DoubleDimension b1 = new DoubleDimension(0.093,0.075);
		controledDimensionList.add(b1);
		DoubleDimension c1 = new DoubleDimension(0.087,0.044);
		controledDimensionList.add(c1);
		DoubleDimension d1 = new DoubleDimension(0.042,0.088);
		controledDimensionList.add(d1);	
		DoubleDimension e1 = new DoubleDimension(0.093,0.056);
		controledDimensionList.add(e1);
		DoubleDimension f1 = new DoubleDimension(0.042,0.081);
		controledDimensionList.add(f1);
		DoubleDimension g1 = new DoubleDimension(0.044,0.038);
		controledDimensionList.add(g1);
		DoubleDimension h1 = new DoubleDimension(0.063,0.076);
		controledDimensionList.add(h1);
		DoubleDimension i1 = new DoubleDimension(0.067,0.032);
		controledDimensionList.add(i1);
		DoubleDimension j1 = new DoubleDimension(0.094,0.088);
		controledDimensionList.add(j1);
		DoubleDimension k1 = new DoubleDimension(0.063,0.082);
		controledDimensionList.add(k1);
		DoubleDimension l1 = new DoubleDimension(0.073,0.043);
		controledDimensionList.add(l1);
		DoubleDimension m1 = new DoubleDimension(0.074,0.087);
		controledDimensionList.add(m1);
		DoubleDimension n1 = new DoubleDimension(0.092,0.062);
		controledDimensionList.add(n1);
		DoubleDimension o1 = new DoubleDimension(0.026,0.036);
		controledDimensionList.add(o1);
		DoubleDimension p1 = new DoubleDimension(0.026,0.068);
		controledDimensionList.add(p1);
		DoubleDimension q1 = new DoubleDimension(0.066,0.085);
		controledDimensionList.add(q1);
		DoubleDimension r1 = new DoubleDimension(0.085,0.042);
		controledDimensionList.add(r1);
		DoubleDimension s1 = new DoubleDimension(0.085,0.074);
		controledDimensionList.add(s1);
		DoubleDimension t1 = new DoubleDimension(0.030,0.028);
		controledDimensionList.add(t1);
		DoubleDimension u1 = new DoubleDimension(0.056,0.030);
		controledDimensionList.add(u1);
		DoubleDimension v1 = new DoubleDimension(0.081,0.051);
		controledDimensionList.add(v1);
		DoubleDimension w1 = new DoubleDimension(0.082,0.063);
		controledDimensionList.add(w1);
		DoubleDimension x1 = new DoubleDimension(0.042,0.086);
		controledDimensionList.add(x1);
		 
		*/
		
		//100blocks - Optimal area (sum of all module areas) = 0.179303 mm2
		/*
		 
		DoubleDimension a = new DoubleDimension(0.043,0.033);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.065,0.037);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.053,0.034);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.037,0.067);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.029,0.019);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(0.039,0.049);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.040,0.018);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.022,0.040);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.050,0.062);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.016,0.041);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(0.018,0.052);
		controledDimensionList.add(k);
		DoubleDimension l = new DoubleDimension(0.039,0.059);
		controledDimensionList.add(l);
		DoubleDimension m = new DoubleDimension(0.061,0.028);
		controledDimensionList.add(m);
		DoubleDimension n = new DoubleDimension(0.048,0.057);
		controledDimensionList.add(n);
		DoubleDimension o = new DoubleDimension(0.063,0.043);
		controledDimensionList.add(o);
		DoubleDimension p = new DoubleDimension(0.059,0.052);
		controledDimensionList.add(p);
		DoubleDimension q = new DoubleDimension(0.036,0.057);
		controledDimensionList.add(q);
		DoubleDimension r = new DoubleDimension(0.044,0.066);
		controledDimensionList.add(r);
		DoubleDimension s = new DoubleDimension(0.048,0.051);
		controledDimensionList.add(s);
		DoubleDimension t = new DoubleDimension(0.031,0.050);
		controledDimensionList.add(t);
		DoubleDimension u = new DoubleDimension(0.037,0.019);
		controledDimensionList.add(u);
		DoubleDimension v = new DoubleDimension(0.064,0.050);
		controledDimensionList.add(v);
		DoubleDimension w = new DoubleDimension(0.049,0.034);
		controledDimensionList.add(w);
		DoubleDimension x = new DoubleDimension(0.020,0.049);
		controledDimensionList.add(x);
		DoubleDimension y = new DoubleDimension(0.045,0.028);
		controledDimensionList.add(y);
		DoubleDimension z = new DoubleDimension(0.054,0.039);
		controledDimensionList.add(z);
		DoubleDimension a1 = new DoubleDimension(0.055,0.040);
		controledDimensionList.add(a1);
		DoubleDimension b1 = new DoubleDimension(0.025,0.065);
		controledDimensionList.add(b1);
		DoubleDimension c1 = new DoubleDimension(0.039,0.046);
		controledDimensionList.add(c1);
		DoubleDimension d1 = new DoubleDimension(0.024,0.062);
		controledDimensionList.add(d1);	
		DoubleDimension e1 = new DoubleDimension(0.024,0.026);
		controledDimensionList.add(e1);
		DoubleDimension f1 = new DoubleDimension(0.026,0.034);
		controledDimensionList.add(f1);
		DoubleDimension g1 = new DoubleDimension(0.043,0.053);
		controledDimensionList.add(g1);
		DoubleDimension h1 = new DoubleDimension(0.022,0.035);
		controledDimensionList.add(h1);
		DoubleDimension i1 = new DoubleDimension(0.027,0.054);
		controledDimensionList.add(i1);
		DoubleDimension j1 = new DoubleDimension(0.031,0.038);
		controledDimensionList.add(j1);
		DoubleDimension k1 = new DoubleDimension(0.039,0.067);
		controledDimensionList.add(k1);
		DoubleDimension l1 = new DoubleDimension(0.020,0.060);
		controledDimensionList.add(l1);
		DoubleDimension m1 = new DoubleDimension(0.023,0.057);
		controledDimensionList.add(m1);
		DoubleDimension n1 = new DoubleDimension(0.052,0.055);
		controledDimensionList.add(n1);
		DoubleDimension o1 = new DoubleDimension(0.026,0.029);
		controledDimensionList.add(o1);
		DoubleDimension p1 = new DoubleDimension(0.027,0.055);
		controledDimensionList.add(p1);
		DoubleDimension q1 = new DoubleDimension(0.062,0.053);
		controledDimensionList.add(q1);
		DoubleDimension r1 = new DoubleDimension(0.061,0.046);
		controledDimensionList.add(r1);
		DoubleDimension s1 = new DoubleDimension(0.065,0.047);
		controledDimensionList.add(s1);
		DoubleDimension t1 = new DoubleDimension(0.023,0.044);
		controledDimensionList.add(t1);
		DoubleDimension u1 = new DoubleDimension(0.039,0.022);
		controledDimensionList.add(u1);
		DoubleDimension v1 = new DoubleDimension(0.065,0.033);
		controledDimensionList.add(v1);
		DoubleDimension w1 = new DoubleDimension(0.057,0.027);
		controledDimensionList.add(w1);
		DoubleDimension x1 = new DoubleDimension(0.047,0.065);
		controledDimensionList.add(x1);
		DoubleDimension y1 = new DoubleDimension(0.067,0.032);
		controledDimensionList.add(y1);
		DoubleDimension z1 = new DoubleDimension(0.038,0.057);
		controledDimensionList.add(z1);
		DoubleDimension a2 = new DoubleDimension(0.054,0.045);
		controledDimensionList.add(a2);
		DoubleDimension b2 = new DoubleDimension(0.043,0.021);
		controledDimensionList.add(b2);
		DoubleDimension c2 = new DoubleDimension(0.018,0.061);
		controledDimensionList.add(c2);
		DoubleDimension d2 = new DoubleDimension(0.034,0.056);
		controledDimensionList.add(d2);
		DoubleDimension e2 = new DoubleDimension(0.017,0.063);
		controledDimensionList.add(e2);
		DoubleDimension f2 = new DoubleDimension(0.018,0.047);
		controledDimensionList.add(f2);
		DoubleDimension g2 = new DoubleDimension(0.046,0.034);
		controledDimensionList.add(g2);
		DoubleDimension h2 = new DoubleDimension(0.050,0.037);
		controledDimensionList.add(h2);
		DoubleDimension i2 = new DoubleDimension(0.040,0.023);
		controledDimensionList.add(i2);
		DoubleDimension j2 = new DoubleDimension(0.033,0.023);
		controledDimensionList.add(j2);
		DoubleDimension k2 = new DoubleDimension(0.060,0.019);
		controledDimensionList.add(k2);
		DoubleDimension l2 = new DoubleDimension(0.036,0.045);
		controledDimensionList.add(l2);
		DoubleDimension m2 = new DoubleDimension(0.050,0.047);
		controledDimensionList.add(m2);
		DoubleDimension n2 = new DoubleDimension(0.057,0.056);
		controledDimensionList.add(n2);
		DoubleDimension o2 = new DoubleDimension(0.067,0.061);
		controledDimensionList.add(o2);
		DoubleDimension p2 = new DoubleDimension(0.044,0.040);
		controledDimensionList.add(p2);
		DoubleDimension q2 = new DoubleDimension(0.052,0.063);
		controledDimensionList.add(q2);
		DoubleDimension r2 = new DoubleDimension(0.054,0.027);
		controledDimensionList.add(r2);
		DoubleDimension s2 = new DoubleDimension(0.042,0.042);
		controledDimensionList.add(s2);
		DoubleDimension t2 = new DoubleDimension(0.064,0.022);
		controledDimensionList.add(t2);
		DoubleDimension u2 = new DoubleDimension(0.061,0.061);
		controledDimensionList.add(u2);
		DoubleDimension v2 = new DoubleDimension(0.061,0.067);
		controledDimensionList.add(v2);
		DoubleDimension w2 = new DoubleDimension(0.038,0.042);
		controledDimensionList.add(w2);
		DoubleDimension x2 = new DoubleDimension(0.019,0.028);
		controledDimensionList.add(x2);
		DoubleDimension y2 = new DoubleDimension(0.022,0.033);
		controledDimensionList.add(y2);
		DoubleDimension z2 = new DoubleDimension(0.066,0.057);
		controledDimensionList.add(z2);
		DoubleDimension a3 = new DoubleDimension(0.036,0.032);
		controledDimensionList.add(a3);
		DoubleDimension b3 = new DoubleDimension(0.060,0.041);
		controledDimensionList.add(b3);	
		DoubleDimension c3 = new DoubleDimension(0.016,0.058);
		controledDimensionList.add(c3);
		DoubleDimension d3 = new DoubleDimension(0.040,0.050);
		controledDimensionList.add(d3);
		DoubleDimension e3 = new DoubleDimension(0.047,0.057);
		controledDimensionList.add(e3);
		DoubleDimension f3 = new DoubleDimension(0.022,0.016);
		controledDimensionList.add(f3);
		DoubleDimension g3 = new DoubleDimension(0.067,0.022);
		controledDimensionList.add(g3);
		DoubleDimension h3 = new DoubleDimension(0.020,0.025);
		controledDimensionList.add(h3);
		DoubleDimension i3 = new DoubleDimension(0.056,0.037);
		controledDimensionList.add(i3);
		DoubleDimension j3 = new DoubleDimension(0.039,0.044);
		controledDimensionList.add(j3);
		DoubleDimension k3 = new DoubleDimension(0.037,0.024);
		controledDimensionList.add(k3);
		DoubleDimension l3 = new DoubleDimension(0.038,0.027);
		controledDimensionList.add(l3);
		DoubleDimension m3 = new DoubleDimension(0.039,0.033);
		controledDimensionList.add(m3);
		DoubleDimension n3 = new DoubleDimension(0.056,0.033);
		controledDimensionList.add(n3);
		DoubleDimension o3 = new DoubleDimension(0.026,0.016);
		controledDimensionList.add(o3);
		DoubleDimension p3 = new DoubleDimension(0.065,0.035);
		controledDimensionList.add(p3);
		DoubleDimension q3 = new DoubleDimension(0.041,0.059);
		controledDimensionList.add(q3);
		DoubleDimension r3 = new DoubleDimension(0.051,0.019);
		controledDimensionList.add(r3);
		DoubleDimension s3 = new DoubleDimension(0.040,0.066);
		controledDimensionList.add(s3);
		DoubleDimension t3 = new DoubleDimension(0.017,0.067);
		controledDimensionList.add(t3);
		DoubleDimension u3 = new DoubleDimension(0.022,0.062);
		controledDimensionList.add(u3);
		DoubleDimension v3 = new DoubleDimension(0.046,0.066);
		controledDimensionList.add(v3);
		 
		*/

		//200blocks - Optimal area (sum of all module areas) = 0.175396 mm2
		/*
		
		DoubleDimension a = new DoubleDimension(0.036,0.016);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.019,0.039);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.041,0.035);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.018,0.047);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.026,0.032);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(0.035,0.031);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.029,0.013);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.028,0.021);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.032,0.015);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.046,0.034);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(0.045,0.032);
		controledDimensionList.add(k);
		DoubleDimension l = new DoubleDimension(0.014,0.036);
		controledDimensionList.add(l);
		DoubleDimension m = new DoubleDimension(0.036,0.042);
		controledDimensionList.add(m);
		DoubleDimension n = new DoubleDimension(0.048,0.045);
		controledDimensionList.add(n);
		DoubleDimension o = new DoubleDimension(0.015,0.025);
		controledDimensionList.add(o);
		DoubleDimension p = new DoubleDimension(0.045,0.046);
		controledDimensionList.add(p);
		DoubleDimension q = new DoubleDimension(0.018,0.022);
		controledDimensionList.add(q);
		DoubleDimension r = new DoubleDimension(0.033,0.026);
		controledDimensionList.add(r);
		DoubleDimension s = new DoubleDimension(0.034,0.019);
		controledDimensionList.add(s);
		DoubleDimension t = new DoubleDimension(0.030,0.012);
		controledDimensionList.add(t);
		DoubleDimension u = new DoubleDimension(0.028,0.033);
		controledDimensionList.add(u);
		DoubleDimension v = new DoubleDimension(0.044,0.039);
		controledDimensionList.add(v);
		DoubleDimension w = new DoubleDimension(0.026,0.039);
		controledDimensionList.add(w);
		DoubleDimension x = new DoubleDimension(0.040,0.025);
		controledDimensionList.add(x);
		DoubleDimension y = new DoubleDimension(0.025,0.015);
		controledDimensionList.add(y);
		DoubleDimension z = new DoubleDimension(0.036,0.036);
		controledDimensionList.add(z);
		DoubleDimension a1 = new DoubleDimension(0.043,0.025);
		controledDimensionList.add(a1);
		DoubleDimension b1 = new DoubleDimension(0.034,0.015);
		controledDimensionList.add(b1);
		DoubleDimension c1 = new DoubleDimension(0.046,0.038);
		controledDimensionList.add(c1);
		DoubleDimension d1 = new DoubleDimension(0.012,0.037);
		controledDimensionList.add(d1);	
		DoubleDimension e1 = new DoubleDimension(0.017,0.027);
		controledDimensionList.add(e1);
		DoubleDimension f1 = new DoubleDimension(0.037,0.016);
		controledDimensionList.add(f1);
		DoubleDimension g1 = new DoubleDimension(0.023,0.032);
		controledDimensionList.add(g1);
		DoubleDimension h1 = new DoubleDimension(0.018,0.036);
		controledDimensionList.add(h1);
		DoubleDimension i1 = new DoubleDimension(0.019,0.038);
		controledDimensionList.add(i1);
		DoubleDimension j1 = new DoubleDimension(0.015,0.033);
		controledDimensionList.add(j1);
		DoubleDimension k1 = new DoubleDimension(0.028,0.012);
		controledDimensionList.add(k1);
		DoubleDimension l1 = new DoubleDimension(0.016,0.031);
		controledDimensionList.add(l1);
		DoubleDimension m1 = new DoubleDimension(0.033,0.026);
		controledDimensionList.add(m1);
		DoubleDimension n1 = new DoubleDimension(0.030,0.042);
		controledDimensionList.add(n1);
		DoubleDimension o1 = new DoubleDimension(0.028,0.041);
		controledDimensionList.add(o1);
		DoubleDimension p1 = new DoubleDimension(0.016,0.016);
		controledDimensionList.add(p1);
		DoubleDimension q1 = new DoubleDimension(0.019,0.044);
		controledDimensionList.add(q1);
		DoubleDimension r1 = new DoubleDimension(0.040,0.034);
		controledDimensionList.add(r1);
		DoubleDimension s1 = new DoubleDimension(0.027,0.016);
		controledDimensionList.add(s1);
		DoubleDimension t1 = new DoubleDimension(0.014,0.037);
		controledDimensionList.add(t1);
		DoubleDimension u1 = new DoubleDimension(0.048,0.015);
		controledDimensionList.add(u1);
		DoubleDimension v1 = new DoubleDimension(0.023,0.014);
		controledDimensionList.add(v1);
		DoubleDimension w1 = new DoubleDimension(0.024,0.026);
		controledDimensionList.add(w1);
		DoubleDimension x1 = new DoubleDimension(0.040,0.031);
		controledDimensionList.add(x1);
		DoubleDimension y1 = new DoubleDimension(0.033,0.042);
		controledDimensionList.add(y1);
		DoubleDimension z1 = new DoubleDimension(0.027,0.048);
		controledDimensionList.add(z1);
		DoubleDimension a2 = new DoubleDimension(0.027,0.037);
		controledDimensionList.add(a2);
		DoubleDimension b2 = new DoubleDimension(0.017,0.018);
		controledDimensionList.add(b2);
		DoubleDimension c2 = new DoubleDimension(0.043,0.016);
		controledDimensionList.add(c2);
		DoubleDimension d2 = new DoubleDimension(0.013,0.046);
		controledDimensionList.add(d2);
		DoubleDimension e2 = new DoubleDimension(0.022,0.025);
		controledDimensionList.add(e2);
		DoubleDimension f2 = new DoubleDimension(0.019,0.048);
		controledDimensionList.add(f2);
		DoubleDimension g2 = new DoubleDimension(0.019,0.041);
		controledDimensionList.add(g2);
		DoubleDimension h2 = new DoubleDimension(0.046,0.036);
		controledDimensionList.add(h2);
		DoubleDimension i2 = new DoubleDimension(0.030,0.035);
		controledDimensionList.add(i2);
		DoubleDimension j2 = new DoubleDimension(0.033,0.034);
		controledDimensionList.add(j2);
		DoubleDimension k2 = new DoubleDimension(0.037,0.045);
		controledDimensionList.add(k2);
		DoubleDimension l2 = new DoubleDimension(0.015,0.035);
		controledDimensionList.add(l2);
		DoubleDimension m2 = new DoubleDimension(0.047,0.048);
		controledDimensionList.add(m2);
		DoubleDimension n2 = new DoubleDimension(0.030,0.033);
		controledDimensionList.add(n2);
		DoubleDimension o2 = new DoubleDimension(0.031,0.031);
		controledDimensionList.add(o2);
		DoubleDimension p2 = new DoubleDimension(0.044,0.037);
		controledDimensionList.add(p2);
		DoubleDimension q2 = new DoubleDimension(0.035,0.024);
		controledDimensionList.add(q2);
		DoubleDimension r2 = new DoubleDimension(0.019,0.038);
		controledDimensionList.add(r2);
		DoubleDimension s2 = new DoubleDimension(0.036,0.014);
		controledDimensionList.add(s2);
		DoubleDimension t2 = new DoubleDimension(0.042,0.034);
		controledDimensionList.add(t2);
		DoubleDimension u2 = new DoubleDimension(0.034,0.033);
		controledDimensionList.add(u2);
		DoubleDimension v2 = new DoubleDimension(0.018,0.038);
		controledDimensionList.add(v2);
		DoubleDimension w2 = new DoubleDimension(0.029,0.018);
		controledDimensionList.add(w2);
		DoubleDimension x2 = new DoubleDimension(0.023,0.027);
		controledDimensionList.add(x2);
		DoubleDimension y2 = new DoubleDimension(0.014,0.012);
		controledDimensionList.add(y2);
		DoubleDimension z2 = new DoubleDimension(0.024,0.016);
		controledDimensionList.add(z2);
		DoubleDimension a3 = new DoubleDimension(0.026,0.043);
		controledDimensionList.add(a3);
		DoubleDimension b3 = new DoubleDimension(0.019,0.037);
		controledDimensionList.add(b3);	
		DoubleDimension c3 = new DoubleDimension(0.014,0.015);
		controledDimensionList.add(c3);
		DoubleDimension d3 = new DoubleDimension(0.032,0.020);
		controledDimensionList.add(d3);
		DoubleDimension e3 = new DoubleDimension(0.032,0.033);
		controledDimensionList.add(e3);
		DoubleDimension f3 = new DoubleDimension(0.019,0.037);
		controledDimensionList.add(f3);
		DoubleDimension g3 = new DoubleDimension(0.043,0.037);
		controledDimensionList.add(g3);
		DoubleDimension h3 = new DoubleDimension(0.048,0.037);
		controledDimensionList.add(h3);
		DoubleDimension i3 = new DoubleDimension(0.024,0.024);
		controledDimensionList.add(i3);
		DoubleDimension j3 = new DoubleDimension(0.045,0.019);
		controledDimensionList.add(j3);
		DoubleDimension k3 = new DoubleDimension(0.028,0.043);
		controledDimensionList.add(k3);
		DoubleDimension l3 = new DoubleDimension(0.012,0.035);
		controledDimensionList.add(l3);
		DoubleDimension m3 = new DoubleDimension(0.045,0.024);
		controledDimensionList.add(m3);
		DoubleDimension n3 = new DoubleDimension(0.044,0.028);
		controledDimensionList.add(n3);
		DoubleDimension o3 = new DoubleDimension(0.042,0.024);
		controledDimensionList.add(o3);
		DoubleDimension p3 = new DoubleDimension(0.043,0.021);
		controledDimensionList.add(p3);
		DoubleDimension q3 = new DoubleDimension(0.015,0.016);
		controledDimensionList.add(q3);
		DoubleDimension r3 = new DoubleDimension(0.036,0.025);
		controledDimensionList.add(r3);
		DoubleDimension s3 = new DoubleDimension(0.025,0.045);
		controledDimensionList.add(s3);
		DoubleDimension t3 = new DoubleDimension(0.025,0.028);
		controledDimensionList.add(t3);
		DoubleDimension u3 = new DoubleDimension(0.016,0.026);
		controledDimensionList.add(u3);
		DoubleDimension v3 = new DoubleDimension(0.037,0.020);
		controledDimensionList.add(v3);
		DoubleDimension w3 = new DoubleDimension(0.027,0.025);
		controledDimensionList.add(w3);
		DoubleDimension x3 = new DoubleDimension(0.040,0.048);
		controledDimensionList.add(x3);
		DoubleDimension y3 = new DoubleDimension(0.025,0.038);
		controledDimensionList.add(y3);
		DoubleDimension z3 = new DoubleDimension(0.032,0.032);
		controledDimensionList.add(z3);
		DoubleDimension a4 = new DoubleDimension(0.036,0.025);
		controledDimensionList.add(a4);
		DoubleDimension b4 = new DoubleDimension(0.042,0.031);
		controledDimensionList.add(b4);
		DoubleDimension c4 = new DoubleDimension(0.034,0.039);
		controledDimensionList.add(c4);
		DoubleDimension d4 = new DoubleDimension(0.045,0.016);
		controledDimensionList.add(d4);
		DoubleDimension e4 = new DoubleDimension(0.033,0.012);
		controledDimensionList.add(e4);
		DoubleDimension f4 = new DoubleDimension(0.012,0.022);
		controledDimensionList.add(f4);
		DoubleDimension g4 = new DoubleDimension(0.044,0.023);
		controledDimensionList.add(g4);
		DoubleDimension h4 = new DoubleDimension(0.018,0.013);
		controledDimensionList.add(h4);
		DoubleDimension i4 = new DoubleDimension(0.018,0.046);
		controledDimensionList.add(i4);
		DoubleDimension j4 = new DoubleDimension(0.043,0.028);
		controledDimensionList.add(j4);
		DoubleDimension k4 = new DoubleDimension(0.039,0.019);
		controledDimensionList.add(k4);
		DoubleDimension l4 = new DoubleDimension(0.037,0.030);
		controledDimensionList.add(l4);
		DoubleDimension m4 = new DoubleDimension(0.037,0.042);
		controledDimensionList.add(m4);
		DoubleDimension n4 = new DoubleDimension(0.024,0.037);
		controledDimensionList.add(n4);
		DoubleDimension o4 = new DoubleDimension(0.039,0.035);
		controledDimensionList.add(o4);
		DoubleDimension p4 = new DoubleDimension(0.024,0.036);
		controledDimensionList.add(p4);
		DoubleDimension q4 = new DoubleDimension(0.015,0.045);
		controledDimensionList.add(q4);
		DoubleDimension r4 = new DoubleDimension(0.032,0.045);
		controledDimensionList.add(r4);
		DoubleDimension s4 = new DoubleDimension(0.043,0.030);
		controledDimensionList.add(s4);
		DoubleDimension t4 = new DoubleDimension(0.013,0.035);
		controledDimensionList.add(t4);
		DoubleDimension u4 = new DoubleDimension(0.013,0.039);
		controledDimensionList.add(u4);
		DoubleDimension v4 = new DoubleDimension(0.018,0.028);
		controledDimensionList.add(v4);
		DoubleDimension w4 = new DoubleDimension(0.038,0.028);
		controledDimensionList.add(w4);
		DoubleDimension x4 = new DoubleDimension(0.024,0.022);
		controledDimensionList.add(x4);
		DoubleDimension y4 = new DoubleDimension(0.036,0.025);
		controledDimensionList.add(y4);
		DoubleDimension z4 = new DoubleDimension(0.044,0.046);
		controledDimensionList.add(z4);	
		DoubleDimension a5 = new DoubleDimension(0.044,0.045);
		controledDimensionList.add(a5);
		DoubleDimension b5 = new DoubleDimension(0.036,0.020);
		controledDimensionList.add(b5);
		DoubleDimension c5 = new DoubleDimension(0.038,0.016);
		controledDimensionList.add(c5);
		DoubleDimension d5 = new DoubleDimension(0.014,0.012);
		controledDimensionList.add(d5);
		DoubleDimension e5 = new DoubleDimension(0.029,0.016);
		controledDimensionList.add(e5);
		DoubleDimension f5 = new DoubleDimension(0.015,0.037);
		controledDimensionList.add(f5);
		DoubleDimension g5 = new DoubleDimension(0.024,0.019);
		controledDimensionList.add(g5);
		DoubleDimension h5 = new DoubleDimension(0.022,0.018);
		controledDimensionList.add(h5);
		DoubleDimension i5 = new DoubleDimension(0.030,0.022);
		controledDimensionList.add(i5);
		DoubleDimension j5 = new DoubleDimension(0.033,0.031);
		controledDimensionList.add(j5);
		DoubleDimension k5 = new DoubleDimension(0.012,0.016);
		controledDimensionList.add(k5);
		DoubleDimension l5 = new DoubleDimension(0.025,0.034);
		controledDimensionList.add(l5);
		DoubleDimension m5 = new DoubleDimension(0.027,0.046);
		controledDimensionList.add(m5);
		DoubleDimension n5 = new DoubleDimension(0.046,0.044);
		controledDimensionList.add(n5);
		DoubleDimension o5 = new DoubleDimension(0.025,0.029);
		controledDimensionList.add(o5);
		DoubleDimension p5 = new DoubleDimension(0.045,0.034);
		controledDimensionList.add(p5);
		DoubleDimension q5 = new DoubleDimension(0.033,0.034);
		controledDimensionList.add(q5);
		DoubleDimension r5 = new DoubleDimension(0.012,0.031);
		controledDimensionList.add(r5);
		DoubleDimension s5 = new DoubleDimension(0.017,0.025);
		controledDimensionList.add(s5);
		DoubleDimension t5 = new DoubleDimension(0.022,0.022);
		controledDimensionList.add(t5);
		DoubleDimension u5 = new DoubleDimension(0.013,0.030);
		controledDimensionList.add(u5);
		DoubleDimension v5 = new DoubleDimension(0.016,0.027);
		controledDimensionList.add(v5);
		DoubleDimension w5 = new DoubleDimension(0.033,0.033);
		controledDimensionList.add(w5);
		DoubleDimension x5 = new DoubleDimension(0.040,0.012);
		controledDimensionList.add(x5);
		DoubleDimension y5 = new DoubleDimension(0.042,0.044);
		controledDimensionList.add(y5);
		DoubleDimension z5 = new DoubleDimension(0.012,0.013);
		controledDimensionList.add(z5);
		DoubleDimension a6 = new DoubleDimension(0.019,0.042);
		controledDimensionList.add(a6);
		DoubleDimension b6 = new DoubleDimension(0.042,0.012);
		controledDimensionList.add(b6);
		DoubleDimension c6 = new DoubleDimension(0.028,0.017);
		controledDimensionList.add(c6);
		DoubleDimension d6 = new DoubleDimension(0.024,0.036);
		controledDimensionList.add(d6);
		DoubleDimension e6 = new DoubleDimension(0.012,0.036);
		controledDimensionList.add(e6);
		DoubleDimension f6 = new DoubleDimension(0.019,0.031);
		controledDimensionList.add(f6);
		DoubleDimension g6 = new DoubleDimension(0.030,0.012);
		controledDimensionList.add(g6);
		DoubleDimension h6 = new DoubleDimension(0.046,0.047);
		controledDimensionList.add(h6);
		DoubleDimension i6 = new DoubleDimension(0.032,0.027);
		controledDimensionList.add(i6);
		DoubleDimension j6 = new DoubleDimension(0.041,0.033);
		controledDimensionList.add(j6);
		DoubleDimension k6 = new DoubleDimension(0.036,0.012);
		controledDimensionList.add(k6);
		DoubleDimension l6 = new DoubleDimension(0.047,0.014);
		controledDimensionList.add(l6);
		DoubleDimension m6 = new DoubleDimension(0.037,0.025);
		controledDimensionList.add(m6);
		DoubleDimension n6 = new DoubleDimension(0.046,0.028);
		controledDimensionList.add(n6);
		DoubleDimension o6 = new DoubleDimension(0.022,0.045);
		controledDimensionList.add(o6);
		DoubleDimension p6 = new DoubleDimension(0.035,0.034);
		controledDimensionList.add(p6);
		DoubleDimension q6 = new DoubleDimension(0.031,0.025);
		controledDimensionList.add(q6);
		DoubleDimension r6 = new DoubleDimension(0.042,0.022);
		controledDimensionList.add(r6);
		DoubleDimension s6 = new DoubleDimension(0.025,0.020);
		controledDimensionList.add(s6);
		DoubleDimension t6 = new DoubleDimension(0.034,0.012);
		controledDimensionList.add(t6);
		DoubleDimension u6 = new DoubleDimension(0.020,0.016);
		controledDimensionList.add(u6);
		DoubleDimension v6 = new DoubleDimension(0.021,0.031);
		controledDimensionList.add(v6);
		DoubleDimension w6 = new DoubleDimension(0.020,0.016);
		controledDimensionList.add(w6);
		DoubleDimension x6 = new DoubleDimension(0.045,0.041);
		controledDimensionList.add(x6);	
		DoubleDimension y6 = new DoubleDimension(0.019,0.021);
		controledDimensionList.add(y6);
		DoubleDimension z6 = new DoubleDimension(0.015,0.042);
		controledDimensionList.add(z6);
		DoubleDimension a7 = new DoubleDimension(0.033,0.012);
		controledDimensionList.add(a7);
		DoubleDimension b7 = new DoubleDimension(0.037,0.016);
		controledDimensionList.add(b7);
		DoubleDimension c7 = new DoubleDimension(0.013,0.044);
		controledDimensionList.add(c7);
		DoubleDimension d7 = new DoubleDimension(0.013,0.048);
		controledDimensionList.add(d7);
		DoubleDimension e7 = new DoubleDimension(0.022,0.024);
		controledDimensionList.add(e7);
		DoubleDimension f7 = new DoubleDimension(0.024,0.040);
		controledDimensionList.add(f7);
		DoubleDimension g7 = new DoubleDimension(0.031,0.020);
		controledDimensionList.add(g7);
		DoubleDimension h7 = new DoubleDimension(0.037,0.034);
		controledDimensionList.add(h7);
		DoubleDimension i7 = new DoubleDimension(0.042,0.037);
		controledDimensionList.add(i7);
		DoubleDimension j7 = new DoubleDimension(0.022,0.028);
		controledDimensionList.add(j7);
		DoubleDimension k7 = new DoubleDimension(0.042,0.043);
		controledDimensionList.add(k7);
		DoubleDimension l7 = new DoubleDimension(0.042,0.043);
		controledDimensionList.add(l7);
		DoubleDimension m7 = new DoubleDimension(0.025,0.036);
		controledDimensionList.add(m7);
		DoubleDimension n7 = new DoubleDimension(0.020,0.019);
		controledDimensionList.add(n7);
		DoubleDimension o7 = new DoubleDimension(0.039,0.016);
		controledDimensionList.add(o7);
		DoubleDimension p7 = new DoubleDimension(0.047,0.035);
		controledDimensionList.add(p7);
		DoubleDimension q7 = new DoubleDimension(0.022,0.040);
		controledDimensionList.add(q7);
		DoubleDimension r7 = new DoubleDimension(0.034,0.040);
		controledDimensionList.add(r7);
		
		*/
		
		//300blocks - Optimal area (sum of all module areas) = 0.27317 mm2
		
		
		DoubleDimension a = new DoubleDimension(0.027,0.015);
		controledDimensionList.add(a);
		DoubleDimension b = new DoubleDimension(0.027,0.016);
		controledDimensionList.add(b);
		DoubleDimension c = new DoubleDimension(0.022,0.026);
		controledDimensionList.add(c);
		DoubleDimension d = new DoubleDimension(0.021,0.045);
		controledDimensionList.add(d);
		DoubleDimension e = new DoubleDimension(0.040,0.045);
		controledDimensionList.add(e);
		DoubleDimension f = new DoubleDimension(0.016,0.026);
		controledDimensionList.add(f);
		DoubleDimension g = new DoubleDimension(0.038,0.027);
		controledDimensionList.add(g);
		DoubleDimension h = new DoubleDimension(0.035,0.029);
		controledDimensionList.add(h);
		DoubleDimension i = new DoubleDimension(0.021,0.036);
		controledDimensionList.add(i);
		DoubleDimension j = new DoubleDimension(0.044,0.025);
		controledDimensionList.add(j);
		DoubleDimension k = new DoubleDimension(0.015,0.031);
		controledDimensionList.add(k);
		DoubleDimension l = new DoubleDimension(0.041,0.024);
		controledDimensionList.add(l);
		DoubleDimension m = new DoubleDimension(0.017,0.019);
		controledDimensionList.add(m);
		DoubleDimension n = new DoubleDimension(0.033,0.048);
		controledDimensionList.add(n);
		DoubleDimension o = new DoubleDimension(0.044,0.021);
		controledDimensionList.add(o);
		DoubleDimension p = new DoubleDimension(0.034,0.015);
		controledDimensionList.add(p);
		DoubleDimension q = new DoubleDimension(0.045,0.042);
		controledDimensionList.add(q);
		DoubleDimension r = new DoubleDimension(0.041,0.037);
		controledDimensionList.add(r);
		DoubleDimension s = new DoubleDimension(0.043,0.044);
		controledDimensionList.add(s);
		DoubleDimension t = new DoubleDimension(0.036,0.023);
		controledDimensionList.add(t);
		DoubleDimension u = new DoubleDimension(0.013,0.017);
		controledDimensionList.add(u);
		DoubleDimension v = new DoubleDimension(0.028,0.044);
		controledDimensionList.add(v);
		DoubleDimension w = new DoubleDimension(0.035,0.029);
		controledDimensionList.add(w);
		DoubleDimension x = new DoubleDimension(0.040,0.017);
		controledDimensionList.add(x);
		DoubleDimension y = new DoubleDimension(0.018,0.024);
		controledDimensionList.add(y);
		DoubleDimension z = new DoubleDimension(0.029,0.043);
		controledDimensionList.add(z);
		DoubleDimension a1 = new DoubleDimension(0.027,0.018);
		controledDimensionList.add(a1);
		DoubleDimension b1 = new DoubleDimension(0.038,0.040);
		controledDimensionList.add(b1);
		DoubleDimension c1 = new DoubleDimension(0.024,0.012);
		controledDimensionList.add(c1);
		DoubleDimension d1 = new DoubleDimension(0.029,0.030);
		controledDimensionList.add(d1);	
		DoubleDimension e1 = new DoubleDimension(0.020,0.028);
		controledDimensionList.add(e1);
		DoubleDimension f1 = new DoubleDimension(0.032,0.036);
		controledDimensionList.add(f1);
		DoubleDimension g1 = new DoubleDimension(0.019,0.022);
		controledDimensionList.add(g1);
		DoubleDimension h1 = new DoubleDimension(0.045,0.046);
		controledDimensionList.add(h1);
		DoubleDimension i1 = new DoubleDimension(0.029,0.012);
		controledDimensionList.add(i1);
		DoubleDimension j1 = new DoubleDimension(0.012,0.026);
		controledDimensionList.add(j1);
		DoubleDimension k1 = new DoubleDimension(0.027,0.030);
		controledDimensionList.add(k1);
		DoubleDimension l1 = new DoubleDimension(0.012,0.029);
		controledDimensionList.add(l1);
		DoubleDimension m1 = new DoubleDimension(0.021,0.019);
		controledDimensionList.add(m1);
		DoubleDimension n1 = new DoubleDimension(0.012,0.013);
		controledDimensionList.add(n1);
		DoubleDimension o1 = new DoubleDimension(0.019,0.047);
		controledDimensionList.add(o1);
		DoubleDimension p1 = new DoubleDimension(0.036,0.019);
		controledDimensionList.add(p1);
		DoubleDimension q1 = new DoubleDimension(0.046,0.025);
		controledDimensionList.add(q1);
		DoubleDimension r1 = new DoubleDimension(0.039,0.021);
		controledDimensionList.add(r1);
		DoubleDimension s1 = new DoubleDimension(0.027,0.024);
		controledDimensionList.add(s1);
		DoubleDimension t1 = new DoubleDimension(0.024,0.025);
		controledDimensionList.add(t1);
		DoubleDimension u1 = new DoubleDimension(0.019,0.013);
		controledDimensionList.add(u1);
		DoubleDimension v1 = new DoubleDimension(0.042,0.040);
		controledDimensionList.add(v1);
		DoubleDimension w1 = new DoubleDimension(0.028,0.034);
		controledDimensionList.add(w1);
		DoubleDimension x1 = new DoubleDimension(0.024,0.048);
		controledDimensionList.add(x1);
		DoubleDimension y1 = new DoubleDimension(0.019,0.014);
		controledDimensionList.add(y1);
		DoubleDimension z1 = new DoubleDimension(0.014,0.016);
		controledDimensionList.add(z1);
		DoubleDimension a2 = new DoubleDimension(0.037,0.018);
		controledDimensionList.add(a2);
		DoubleDimension b2 = new DoubleDimension(0.036,0.012);
		controledDimensionList.add(b2);
		DoubleDimension c2 = new DoubleDimension(0.030,0.034);
		controledDimensionList.add(c2);
		DoubleDimension d2 = new DoubleDimension(0.026,0.031);
		controledDimensionList.add(d2);
		DoubleDimension e2 = new DoubleDimension(0.046,0.031);
		controledDimensionList.add(e2);
		DoubleDimension f2 = new DoubleDimension(0.047,0.048);
		controledDimensionList.add(f2);
		DoubleDimension g2 = new DoubleDimension(0.025,0.025);
		controledDimensionList.add(g2);
		DoubleDimension h2 = new DoubleDimension(0.047,0.038);
		controledDimensionList.add(h2);
		DoubleDimension i2 = new DoubleDimension(0.039,0.016);
		controledDimensionList.add(i2);
		DoubleDimension j2 = new DoubleDimension(0.031,0.045);
		controledDimensionList.add(j2);
		DoubleDimension k2 = new DoubleDimension(0.046,0.036);
		controledDimensionList.add(k2);
		DoubleDimension l2 = new DoubleDimension(0.036,0.046);
		controledDimensionList.add(l2);
		DoubleDimension m2 = new DoubleDimension(0.033,0.015);
		controledDimensionList.add(m2);
		DoubleDimension n2 = new DoubleDimension(0.013,0.023);
		controledDimensionList.add(n2);
		DoubleDimension o2 = new DoubleDimension(0.042,0.045);
		controledDimensionList.add(o2);
		DoubleDimension p2 = new DoubleDimension(0.014,0.033);
		controledDimensionList.add(p2);
		DoubleDimension q2 = new DoubleDimension(0.028,0.045);
		controledDimensionList.add(q2);
		DoubleDimension r2 = new DoubleDimension(0.036,0.027);
		controledDimensionList.add(r2);
		DoubleDimension s2 = new DoubleDimension(0.016,0.045);
		controledDimensionList.add(s2);
		DoubleDimension t2 = new DoubleDimension(0.034,0.032);
		controledDimensionList.add(t2);
		DoubleDimension u2 = new DoubleDimension(0.032,0.015);
		controledDimensionList.add(u2);
		DoubleDimension v2 = new DoubleDimension(0.012,0.046);
		controledDimensionList.add(v2);
		DoubleDimension w2 = new DoubleDimension(0.043,0.034);
		controledDimensionList.add(w2);
		DoubleDimension x2 = new DoubleDimension(0.020,0.037);
		controledDimensionList.add(x2);
		DoubleDimension y2 = new DoubleDimension(0.039,0.036);
		controledDimensionList.add(y2);
		DoubleDimension z2 = new DoubleDimension(0.040,0.018);
		controledDimensionList.add(z2);
		DoubleDimension a3 = new DoubleDimension(0.042,0.016);
		controledDimensionList.add(a3);
		DoubleDimension b3 = new DoubleDimension(0.040,0.025);
		controledDimensionList.add(b3);	
		DoubleDimension c3 = new DoubleDimension(0.036,0.015);
		controledDimensionList.add(c3);
		DoubleDimension d3 = new DoubleDimension(0.015,0.032);
		controledDimensionList.add(d3);
		DoubleDimension e3 = new DoubleDimension(0.039,0.024);
		controledDimensionList.add(e3);
		DoubleDimension f3 = new DoubleDimension(0.037,0.041);
		controledDimensionList.add(f3);
		DoubleDimension g3 = new DoubleDimension(0.034,0.038);
		controledDimensionList.add(g3);
		DoubleDimension h3 = new DoubleDimension(0.034,0.043);
		controledDimensionList.add(h3);
		DoubleDimension i3 = new DoubleDimension(0.039,0.044);
		controledDimensionList.add(i3);
		DoubleDimension j3 = new DoubleDimension(0.045,0.048);
		controledDimensionList.add(j3);
		DoubleDimension k3 = new DoubleDimension(0.029,0.044);
		controledDimensionList.add(k3);
		DoubleDimension l3 = new DoubleDimension(0.020,0.042);
		controledDimensionList.add(l3);
		DoubleDimension m3 = new DoubleDimension(0.046,0.024);
		controledDimensionList.add(m3);
		DoubleDimension n3 = new DoubleDimension(0.043,0.021);
		controledDimensionList.add(n3);
		DoubleDimension o3 = new DoubleDimension(0.045,0.047);
		controledDimensionList.add(o3);
		DoubleDimension p3 = new DoubleDimension(0.020,0.024);
		controledDimensionList.add(p3);
		DoubleDimension q3 = new DoubleDimension(0.031,0.019);
		controledDimensionList.add(q3);
		DoubleDimension r3 = new DoubleDimension(0.044,0.037);
		controledDimensionList.add(r3);
		DoubleDimension s3 = new DoubleDimension(0.046,0.033);
		controledDimensionList.add(s3);
		DoubleDimension t3 = new DoubleDimension(0.040,0.015);
		controledDimensionList.add(t3);
		DoubleDimension u3 = new DoubleDimension(0.013,0.035);
		controledDimensionList.add(u3);
		DoubleDimension v3 = new DoubleDimension(0.040,0.017);
		controledDimensionList.add(v3);
		DoubleDimension w3 = new DoubleDimension(0.044,0.045);
		controledDimensionList.add(w3);
		DoubleDimension x3 = new DoubleDimension(0.030,0.036);
		controledDimensionList.add(x3);
		DoubleDimension y3 = new DoubleDimension(0.040,0.036);
		controledDimensionList.add(y3);
		DoubleDimension z3 = new DoubleDimension(0.034,0.034);
		controledDimensionList.add(z3);
		DoubleDimension a4 = new DoubleDimension(0.042,0.014);
		controledDimensionList.add(a4);
		DoubleDimension b4 = new DoubleDimension(0.035,0.033);
		controledDimensionList.add(b4);
		DoubleDimension c4 = new DoubleDimension(0.012,0.033);
		controledDimensionList.add(c4);
		DoubleDimension d4 = new DoubleDimension(0.032,0.015);
		controledDimensionList.add(d4);
		DoubleDimension e4 = new DoubleDimension(0.037,0.038);
		controledDimensionList.add(e4);
		DoubleDimension f4 = new DoubleDimension(0.042,0.046);
		controledDimensionList.add(f4);
		DoubleDimension g4 = new DoubleDimension(0.039,0.042);
		controledDimensionList.add(g4);
		DoubleDimension h4 = new DoubleDimension(0.013,0.021);
		controledDimensionList.add(h4);
		DoubleDimension i4 = new DoubleDimension(0.030,0.025);
		controledDimensionList.add(i4);
		DoubleDimension j4 = new DoubleDimension(0.036,0.024);
		controledDimensionList.add(j4);
		DoubleDimension k4 = new DoubleDimension(0.034,0.044);
		controledDimensionList.add(k4);
		DoubleDimension l4 = new DoubleDimension(0.034,0.022);
		controledDimensionList.add(l4);
		DoubleDimension m4 = new DoubleDimension(0.028,0.019);
		controledDimensionList.add(m4);
		DoubleDimension n4 = new DoubleDimension(0.039,0.021);
		controledDimensionList.add(n4);
		DoubleDimension o4 = new DoubleDimension(0.044,0.038);
		controledDimensionList.add(o4);
		DoubleDimension p4 = new DoubleDimension(0.028,0.045);
		controledDimensionList.add(p4);
		DoubleDimension q4 = new DoubleDimension(0.036,0.036);
		controledDimensionList.add(q4);
		DoubleDimension r4 = new DoubleDimension(0.034,0.038);
		controledDimensionList.add(r4);
		DoubleDimension s4 = new DoubleDimension(0.043,0.020);
		controledDimensionList.add(s4);
		DoubleDimension t4 = new DoubleDimension(0.023,0.036);
		controledDimensionList.add(t4);
		DoubleDimension u4 = new DoubleDimension(0.031,0.035);
		controledDimensionList.add(u4);
		DoubleDimension v4 = new DoubleDimension(0.046,0.042);
		controledDimensionList.add(v4);
		DoubleDimension w4 = new DoubleDimension(0.022,0.012);
		controledDimensionList.add(w4);
		DoubleDimension x4 = new DoubleDimension(0.025,0.043);
		controledDimensionList.add(x4);
		DoubleDimension y4 = new DoubleDimension(0.044,0.028);
		controledDimensionList.add(y4);
		DoubleDimension z4 = new DoubleDimension(0.034,0.022);
		controledDimensionList.add(z4);	
		DoubleDimension a5 = new DoubleDimension(0.030,0.026);
		controledDimensionList.add(a5);
		DoubleDimension b5 = new DoubleDimension(0.048,0.045);
		controledDimensionList.add(b5);
		DoubleDimension c5 = new DoubleDimension(0.018,0.039);
		controledDimensionList.add(c5);
		DoubleDimension d5 = new DoubleDimension(0.015,0.043);
		controledDimensionList.add(d5);
		DoubleDimension e5 = new DoubleDimension(0.034,0.047);
		controledDimensionList.add(e5);
		DoubleDimension f5 = new DoubleDimension(0.045,0.015);
		controledDimensionList.add(f5);
		DoubleDimension g5 = new DoubleDimension(0.037,0.012);
		controledDimensionList.add(g5);
		DoubleDimension h5 = new DoubleDimension(0.021,0.028);
		controledDimensionList.add(h5);
		DoubleDimension i5 = new DoubleDimension(0.042,0.028);
		controledDimensionList.add(i5);
		DoubleDimension j5 = new DoubleDimension(0.036,0.037);
		controledDimensionList.add(j5);
		DoubleDimension k5 = new DoubleDimension(0.012,0.043);
		controledDimensionList.add(k5);
		DoubleDimension l5 = new DoubleDimension(0.019,0.045);
		controledDimensionList.add(l5);
		DoubleDimension m5 = new DoubleDimension(0.027,0.037);
		controledDimensionList.add(m5);
		DoubleDimension n5 = new DoubleDimension(0.024,0.025);
		controledDimensionList.add(n5);
		DoubleDimension o5 = new DoubleDimension(0.015,0.040);
		controledDimensionList.add(o5);
		DoubleDimension p5 = new DoubleDimension(0.013,0.045);
		controledDimensionList.add(p5);
		DoubleDimension q5 = new DoubleDimension(0.048,0.033);
		controledDimensionList.add(q5);
		DoubleDimension r5 = new DoubleDimension(0.030,0.042);
		controledDimensionList.add(r5);
		DoubleDimension s5 = new DoubleDimension(0.018,0.020);
		controledDimensionList.add(s5);
		DoubleDimension t5 = new DoubleDimension(0.047,0.022);
		controledDimensionList.add(t5);
		DoubleDimension u5 = new DoubleDimension(0.023,0.031);
		controledDimensionList.add(u5);
		DoubleDimension v5 = new DoubleDimension(0.018,0.042);
		controledDimensionList.add(v5);
		DoubleDimension w5 = new DoubleDimension(0.016,0.019);
		controledDimensionList.add(w5);
		DoubleDimension x5 = new DoubleDimension(0.041,0.030);
		controledDimensionList.add(x5);
		DoubleDimension y5 = new DoubleDimension(0.022,0.017);
		controledDimensionList.add(y5);
		DoubleDimension z5 = new DoubleDimension(0.025,0.014);
		controledDimensionList.add(z5);
		DoubleDimension a6 = new DoubleDimension(0.028,0.016);
		controledDimensionList.add(a6);
		DoubleDimension b6 = new DoubleDimension(0.020,0.025);
		controledDimensionList.add(b6);
		DoubleDimension c6 = new DoubleDimension(0.023,0.013);
		controledDimensionList.add(c6);
		DoubleDimension d6 = new DoubleDimension(0.044,0.032);
		controledDimensionList.add(d6);
		DoubleDimension e6 = new DoubleDimension(0.027,0.016);
		controledDimensionList.add(e6);
		DoubleDimension f6 = new DoubleDimension(0.046,0.047);
		controledDimensionList.add(f6);
		DoubleDimension g6 = new DoubleDimension(0.031,0.018);
		controledDimensionList.add(g6);
		DoubleDimension h6 = new DoubleDimension(0.033,0.022);
		controledDimensionList.add(h6);
		DoubleDimension i6 = new DoubleDimension(0.036,0.041);
		controledDimensionList.add(i6);
		DoubleDimension j6 = new DoubleDimension(0.021,0.017);
		controledDimensionList.add(j6);
		DoubleDimension k6 = new DoubleDimension(0.034,0.036);
		controledDimensionList.add(k6);
		DoubleDimension l6 = new DoubleDimension(0.036,0.037);
		controledDimensionList.add(l6);
		DoubleDimension m6 = new DoubleDimension(0.024,0.041);
		controledDimensionList.add(m6);
		DoubleDimension n6 = new DoubleDimension(0.024,0.039);
		controledDimensionList.add(n6);
		DoubleDimension o6 = new DoubleDimension(0.029,0.045);
		controledDimensionList.add(o6);
		DoubleDimension p6 = new DoubleDimension(0.022,0.040);
		controledDimensionList.add(p6);
		DoubleDimension q6 = new DoubleDimension(0.027,0.013);
		controledDimensionList.add(q6);
		DoubleDimension r6 = new DoubleDimension(0.025,0.032);
		controledDimensionList.add(r6);
		DoubleDimension s6 = new DoubleDimension(0.043,0.016);
		controledDimensionList.add(s6);
		DoubleDimension t6 = new DoubleDimension(0.015,0.016);
		controledDimensionList.add(t6);
		DoubleDimension u6 = new DoubleDimension(0.033,0.038);
		controledDimensionList.add(u6);
		DoubleDimension v6 = new DoubleDimension(0.041,0.037);
		controledDimensionList.add(v6);
		DoubleDimension w6 = new DoubleDimension(0.017,0.019);
		controledDimensionList.add(w6);
		DoubleDimension x6 = new DoubleDimension(0.046,0.034);
		controledDimensionList.add(x6);	
		DoubleDimension y6 = new DoubleDimension(0.019,0.040);
		controledDimensionList.add(y6);
		DoubleDimension z6 = new DoubleDimension(0.030,0.028);
		controledDimensionList.add(z6);
		DoubleDimension a7 = new DoubleDimension(0.045,0.024);
		controledDimensionList.add(a7);
		DoubleDimension b7 = new DoubleDimension(0.033,0.039);
		controledDimensionList.add(b7);
		DoubleDimension c7 = new DoubleDimension(0.046,0.025);
		controledDimensionList.add(c7);
		DoubleDimension d7 = new DoubleDimension(0.027,0.034);
		controledDimensionList.add(d7);
		DoubleDimension e7 = new DoubleDimension(0.031,0.033);
		controledDimensionList.add(e7);
		DoubleDimension f7 = new DoubleDimension(0.036,0.038);
		controledDimensionList.add(f7);
		DoubleDimension g7 = new DoubleDimension(0.037,0.040);
		controledDimensionList.add(g7);
		DoubleDimension h7 = new DoubleDimension(0.044,0.012);
		controledDimensionList.add(h7);
		DoubleDimension i7 = new DoubleDimension(0.037,0.027);
		controledDimensionList.add(i7);
		DoubleDimension j7 = new DoubleDimension(0.016,0.034);
		controledDimensionList.add(j7);
		DoubleDimension k7 = new DoubleDimension(0.029,0.048);
		controledDimensionList.add(k7);
		DoubleDimension l7 = new DoubleDimension(0.033,0.017);
		controledDimensionList.add(l7);
		DoubleDimension m7 = new DoubleDimension(0.028,0.013);
		controledDimensionList.add(m7);
		DoubleDimension n7 = new DoubleDimension(0.033,0.013);
		controledDimensionList.add(n7);
		DoubleDimension o7 = new DoubleDimension(0.041,0.041);
		controledDimensionList.add(o7);
		DoubleDimension p7 = new DoubleDimension(0.037,0.028);
		controledDimensionList.add(p7);
		DoubleDimension q7 = new DoubleDimension(0.048,0.019);
		controledDimensionList.add(q7);
		DoubleDimension r7 = new DoubleDimension(0.031,0.036);
		controledDimensionList.add(r7);
		DoubleDimension s7 = new DoubleDimension(0.043,0.037);
		controledDimensionList.add(s7);
		DoubleDimension t7 = new DoubleDimension(0.026,0.029);
		controledDimensionList.add(t7);
		DoubleDimension u7 = new DoubleDimension(0.034,0.039);
		controledDimensionList.add(u7);
		DoubleDimension v7 = new DoubleDimension(0.015,0.028);
		controledDimensionList.add(v7);
		DoubleDimension w7 = new DoubleDimension(0.041,0.033);
		controledDimensionList.add(w7);
		DoubleDimension x7 = new DoubleDimension(0.021,0.015);
		controledDimensionList.add(x7);
		DoubleDimension y7 = new DoubleDimension(0.042,0.035);
		controledDimensionList.add(y7);
		DoubleDimension z7 = new DoubleDimension(0.033,0.028);
		controledDimensionList.add(z7);
		DoubleDimension a8 = new DoubleDimension(0.027,0.020);
		controledDimensionList.add(a8);
		DoubleDimension b8 = new DoubleDimension(0.045,0.036);
		controledDimensionList.add(b8);
		DoubleDimension c8 = new DoubleDimension(0.013,0.024);
		controledDimensionList.add(c8);
		DoubleDimension d8 = new DoubleDimension(0.016,0.012);
		controledDimensionList.add(d8);
		DoubleDimension e8 = new DoubleDimension(0.021,0.042);
		controledDimensionList.add(e8);
		DoubleDimension f8 = new DoubleDimension(0.032,0.014);
		controledDimensionList.add(f8);
		DoubleDimension g8 = new DoubleDimension(0.017,0.027);
		controledDimensionList.add(g8);
		DoubleDimension h8 = new DoubleDimension(0.029,0.021);
		controledDimensionList.add(h8);
		DoubleDimension i8 = new DoubleDimension(0.042,0.019);
		controledDimensionList.add(i8);
		DoubleDimension j8 = new DoubleDimension(0.020,0.048);
		controledDimensionList.add(j8);
		DoubleDimension k8 = new DoubleDimension(0.043,0.015);
		controledDimensionList.add(k8);
		DoubleDimension l8 = new DoubleDimension(0.028,0.018);
		controledDimensionList.add(l8);
		DoubleDimension m8 = new DoubleDimension(0.030,0.037);
		controledDimensionList.add(m8);
		DoubleDimension n8 = new DoubleDimension(0.013,0.045);
		controledDimensionList.add(n8);
		DoubleDimension o8 = new DoubleDimension(0.034,0.025);
		controledDimensionList.add(o8);
		DoubleDimension p8 = new DoubleDimension(0.022,0.019);
		controledDimensionList.add(p8);
		DoubleDimension q8 = new DoubleDimension(0.045,0.021);
		controledDimensionList.add(q8);
		DoubleDimension r8 = new DoubleDimension(0.047,0.038);
		controledDimensionList.add(r8);
		DoubleDimension s8 = new DoubleDimension(0.039,0.016);
		controledDimensionList.add(s8);
		DoubleDimension t8 = new DoubleDimension(0.013,0.032);
		controledDimensionList.add(t8);
		DoubleDimension u8 = new DoubleDimension(0.021,0.020);
		controledDimensionList.add(u8);
		DoubleDimension v8 = new DoubleDimension(0.024,0.048);
		controledDimensionList.add(v8);	
		DoubleDimension w8 = new DoubleDimension(0.030,0.033);
		controledDimensionList.add(w8);
		DoubleDimension x8 = new DoubleDimension(0.016,0.030);
		controledDimensionList.add(x8);
		DoubleDimension y8 = new DoubleDimension(0.042,0.023);
		controledDimensionList.add(y8);
		DoubleDimension z8 = new DoubleDimension(0.016,0.013);
		controledDimensionList.add(z8);
		DoubleDimension a9 = new DoubleDimension(0.033,0.018);
		controledDimensionList.add(a9);
		DoubleDimension b9 = new DoubleDimension(0.022,0.046);
		controledDimensionList.add(b9);
		DoubleDimension g9 = new DoubleDimension(0.027,0.039);
		controledDimensionList.add(g9);
		DoubleDimension h9 = new DoubleDimension(0.021,0.040);
		controledDimensionList.add(h9);
		DoubleDimension i9 = new DoubleDimension(0.027,0.039);
		controledDimensionList.add(i9);
		DoubleDimension j9 = new DoubleDimension(0.040,0.022);
		controledDimensionList.add(j9);
		DoubleDimension k9 = new DoubleDimension(0.023,0.019);
		controledDimensionList.add(k9);
		DoubleDimension l9 = new DoubleDimension(0.013,0.024);
		controledDimensionList.add(l9);
		DoubleDimension m9 = new DoubleDimension(0.022,0.040);
		controledDimensionList.add(m9);
		DoubleDimension n9 = new DoubleDimension(0.037,0.034);
		controledDimensionList.add(n9);
		DoubleDimension o9 = new DoubleDimension(0.037,0.013);
		controledDimensionList.add(o9);
		DoubleDimension q9 = new DoubleDimension(0.036,0.024);
		controledDimensionList.add(q9);
		DoubleDimension r9 = new DoubleDimension(0.023,0.044);
		controledDimensionList.add(r9);
		DoubleDimension s9 = new DoubleDimension(0.036,0.039);
		controledDimensionList.add(s9);
		DoubleDimension t9 = new DoubleDimension(0.043,0.031);
		controledDimensionList.add(t9);
		DoubleDimension u9 = new DoubleDimension(0.035,0.027);
		controledDimensionList.add(u9);
		DoubleDimension v9 = new DoubleDimension(0.031,0.034);
		controledDimensionList.add(v9);
		DoubleDimension w9 = new DoubleDimension(0.043,0.034);
		controledDimensionList.add(w9);
		DoubleDimension x9 = new DoubleDimension(0.019,0.028);
		controledDimensionList.add(x9);
		DoubleDimension y9 = new DoubleDimension(0.015,0.013);
		controledDimensionList.add(y9);
		DoubleDimension z9 = new DoubleDimension(0.024,0.013);
		controledDimensionList.add(z9);
		DoubleDimension a10 = new DoubleDimension(0.047,0.039);
		controledDimensionList.add(a10);
		DoubleDimension b10 = new DoubleDimension(0.021,0.013);
		controledDimensionList.add(b10);
		DoubleDimension c10 = new DoubleDimension(0.017,0.033);
		controledDimensionList.add(c10);
		DoubleDimension d10 = new DoubleDimension(0.044,0.034);
		controledDimensionList.add(d10);
		DoubleDimension e10 = new DoubleDimension(0.026,0.012);
		controledDimensionList.add(e10);
		DoubleDimension f10 = new DoubleDimension(0.019,0.012);
		controledDimensionList.add(f10);
		DoubleDimension g10 = new DoubleDimension(0.012,0.045);
		controledDimensionList.add(g10);
		DoubleDimension h10 = new DoubleDimension(0.027,0.048);
		controledDimensionList.add(h10);
		DoubleDimension i10 = new DoubleDimension(0.047,0.046);
		controledDimensionList.add(i10);
		DoubleDimension j10 = new DoubleDimension(0.045,0.023);
		controledDimensionList.add(j10);
		DoubleDimension k10 = new DoubleDimension(0.045,0.015);
		controledDimensionList.add(k10);
		DoubleDimension l10 = new DoubleDimension(0.045,0.048);
		controledDimensionList.add(l10);
		DoubleDimension m10 = new DoubleDimension(0.034,0.039);
		controledDimensionList.add(m10);
		DoubleDimension n10 = new DoubleDimension(0.022,0.025);
		controledDimensionList.add(n10);
		DoubleDimension o10 = new DoubleDimension(0.037,0.018);
		controledDimensionList.add(o10);
		DoubleDimension p10 = new DoubleDimension(0.023,0.015);
		controledDimensionList.add(p10);
		DoubleDimension q10 = new DoubleDimension(0.042,0.024);
		controledDimensionList.add(q10);
		DoubleDimension r10 = new DoubleDimension(0.024,0.035);
		controledDimensionList.add(r10);
		DoubleDimension s10 = new DoubleDimension(0.021,0.030);
		controledDimensionList.add(s10);
		DoubleDimension t10 = new DoubleDimension(0.033,0.021);
		controledDimensionList.add(t10);
		DoubleDimension u10 = new DoubleDimension(0.022,0.028);
		controledDimensionList.add(u10);	
		DoubleDimension v10 = new DoubleDimension(0.031,0.014);
		controledDimensionList.add(v10);
		DoubleDimension w10 = new DoubleDimension(0.012,0.047);
		controledDimensionList.add(w10);
		DoubleDimension x10 = new DoubleDimension(0.013,0.042);
		controledDimensionList.add(x10);
		DoubleDimension y10 = new DoubleDimension(0.039,0.043);
		controledDimensionList.add(y10);
		DoubleDimension z10 = new DoubleDimension(0.031,0.022);
		controledDimensionList.add(z10);
		DoubleDimension a11 = new DoubleDimension(0.030,0.018);
		controledDimensionList.add(a11);
		DoubleDimension b11 = new DoubleDimension(0.044,0.030);
		controledDimensionList.add(b11);
		DoubleDimension c11 = new DoubleDimension(0.013,0.015);
		controledDimensionList.add(c11);
		DoubleDimension d11 = new DoubleDimension(0.030,0.021);
		controledDimensionList.add(d11);
		DoubleDimension e11 = new DoubleDimension(0.013,0.033);
		controledDimensionList.add(e11);
		DoubleDimension f11 = new DoubleDimension(0.036,0.041);
		controledDimensionList.add(f11);
		DoubleDimension g11 = new DoubleDimension(0.042,0.021);
		controledDimensionList.add(g11);
		DoubleDimension h11 = new DoubleDimension(0.028,0.036);
		controledDimensionList.add(h11);
		DoubleDimension i11 = new DoubleDimension(0.033,0.037);
		controledDimensionList.add(i11);
		DoubleDimension j11 = new DoubleDimension(0.016,0.027);
		controledDimensionList.add(j11);
		DoubleDimension k11 = new DoubleDimension(0.028,0.043);
		controledDimensionList.add(k11);
		DoubleDimension l11 = new DoubleDimension(0.024,0.039);
		controledDimensionList.add(l11);
		DoubleDimension m11 = new DoubleDimension(0.043,0.019);
		controledDimensionList.add(m11);
		DoubleDimension n11 = new DoubleDimension(0.017,0.026);
		controledDimensionList.add(n11);
		DoubleDimension o11 = new DoubleDimension(0.043,0.013);
		controledDimensionList.add(o11);
		DoubleDimension c9 = new DoubleDimension(0.016,0.027);
		controledDimensionList.add(c9);
		DoubleDimension d9 = new DoubleDimension(0.038,0.031);
		controledDimensionList.add(d9);
		DoubleDimension e9 = new DoubleDimension(0.033,0.040);
		controledDimensionList.add(e9);
		DoubleDimension f9 = new DoubleDimension(0.013,0.013);
		controledDimensionList.add(f9);
		
		
		
	}
	
	
	/**
	 * Adds the basic double dimensions to array.
	 */
	public void addBasicDoubleDimensionsToArray() {
		DoubleDimension laying = new DoubleDimension();
		laying.setSize(height, width);
		DoubleDimension standing = new DoubleDimension();
		standing.setSize(width,height);
		dimensionList.add(standing);
		dimensionList.add(laying);
	}
	
	/**
	 * Gets the list of double dimensions.
	 *
	 * @return the list of double dimensions
	 */
	public ArrayList<DoubleDimension> getListOfDoubleDimensions() {
		return dimensionList;
	}
	
	/**
	 * Sets the list of double dimensions.
	 *
	 * @param newListOfDimensions the new list of double dimensions
	 */
	public void setListOfDoubleDimensions(ArrayList<DoubleDimension> newListOfDimensions) {
		dimensionList = newListOfDimensions;
	}

	/**
	 * Gets the height.
	 *
	 * @return the height
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * Sets the height.
	 *
	 * @param height the new height
	 */
	public void setHeight(double height) {
		this.height = height;
	}

	/**
	 * Gets the width.
	 *
	 * @return the width
	 */
	public double getWidth() {
		return width;
	}

	/**
	 * Sets the width.
	 *
	 * @param width the new width
	 */
	public void setWidth(double width) {
		this.width = width;
	}

	/**
	 * Gets the tipo.
	 *
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * Sets the tipo.
	 *
	 * @param tipo the new tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Checks if is cut.
	 *
	 * @return true, if is cut
	 */
	public boolean isCut() {
		return isCut;
	}

	/**
	 * Sets the cut.
	 *
	 * @param isCut the new cut
	 */
	public void setCut(boolean isCut) {
		this.isCut = isCut;
	}

	/**
	 * Checks if is basic.
	 *
	 * @return true, if is basic
	 */
	public boolean isBasic() {
		return isBasic;
	}

	/**
	 * Sets the basic.
	 *
	 * @param isBasic the new basic
	 */
	public void setBasic(boolean isBasic) {
		this.isBasic = isBasic;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		if(isBasic) {
			int a = getId();
			return "'" + a + "'";
		} else {
			return "'" + tipo + "'";
		}
	}

	/**
	 * Calculate area.
	 *
	 * @return the double
	 */
	public static double calculateArea() {
		double area = 0;
		for(int i=0; i<controledDimensionList.size();i++) {
			double a = controledDimensionList.get(i).getHeight() * controledDimensionList.get(i).getWidth();
			area += a;
		}
		return area;
	}

	/**
	 * Gets the coordinate.
	 *
	 * @return the coordinate
	 */
	public Point getCoordinate(){
		return bottomLeftCoordinate;
	}

}
