package ComparisonMethods;
import java.util.ArrayList;

import NewApproach.Rectangle;


// TODO: Auto-generated Javadoc
/**
 * The Class FFDH_teste.
 */
public class FFDH_teste {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
		Rectangle a = new Rectangle(25,20);
		Rectangle b = new Rectangle(15,40);
		Rectangle c = new Rectangle(35,25);
		Rectangle d = new Rectangle(30,10);
		Rectangle e = new Rectangle(50,50);
		ArrayList<Rectangle> list = new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		list.add(e);
		FFDH ffdh = new FFDH(60,list);
		System.out.println("Height: " + ffdh.getFinalHeight());
		System.out.println("Width: " + ffdh.getFinalWidth());
		
		//blf.sort(list);
		/*ArrayList<Rectangle> sortedList = blf.getListOfSortedRectangles();
		for(int i = 0; i < sortedList.size(); i++) {
			System.out.println(sortedList.get(i).getHeight());
		}*/
	}

}
