package ComparisonMethods;

import java.util.ArrayList;

import NewApproach.Rectangle;

/**
 * The Class BottomUpVLSI.
 */
public class BottomUpVLSI {
	
	/** The list of modules. */
	private ArrayList<Rectangle> listOfModules;
	
	/** The list of sorted modules descending area. */
	private ArrayList<Rectangle> listOfSortedModulesDescendingArea;
	
	/** The list of composite blocks. */
	private ArrayList<Rectangle> listOfCompositeBlocks;
	
	/** The num of modules. */
	private int numOfModules;
	
	/** The fitness. */
	private double fitness;
	
	/** The Cn. */
	int Cn;
	
	/**
	 * Instantiates a new bottom up VLSI.
	 *
	 * @param listOfRectangles the list of rectangles
	 */
	public BottomUpVLSI(ArrayList<Rectangle> listOfRectangles){
		this.listOfModules = listOfRectangles;
		listOfSortedModulesDescendingArea = new ArrayList<>();
		listOfCompositeBlocks = new ArrayList<>();
		sortDescendingArea(listOfModules);
		numOfModules = listOfRectangles.size();
		
		while(numOfModules != 0) {
			createCompositeBlocks();
			numOfModules = listOfSortedModulesDescendingArea.size();
		}
		sortDescendingArea(listOfCompositeBlocks);
	}
	
	/**
	 * Sort descending area.
	 *
	 * @param listToSort the list to sort
	 */
	@SuppressWarnings("unchecked")
	public void sortDescendingArea(ArrayList<Rectangle> listToSort) {
		ArrayList<Rectangle> listOfAuxRectangles = new ArrayList<>();
		listOfAuxRectangles = (ArrayList<Rectangle>) listToSort.clone();
		Rectangle maxAreaRectangle = new Rectangle();
		
		int length = listOfAuxRectangles.size();
		int iterator = 0;
		int indexOfRectangleToRemove = 0;
		listOfSortedModulesDescendingArea.clear();
		
		while(iterator < length){
			double area = 0;
			for(int i = 0; i< listOfAuxRectangles.size(); i++) {
				area = listOfAuxRectangles.get(i).getHeight() * listOfAuxRectangles.get(i).getWidth();
				double maxArea = maxAreaRectangle.getHeight() * maxAreaRectangle.getWidth();
				if(area > maxArea) {
					maxAreaRectangle = listOfAuxRectangles.get(i);
					indexOfRectangleToRemove = i;
				}
			}
			
			//adds the current rectangle with larger width to the sorted list
			listOfSortedModulesDescendingArea.add(maxAreaRectangle);
			
			//removes the rectangle with larger width from the original array
			listOfAuxRectangles.remove(indexOfRectangleToRemove);
			
			indexOfRectangleToRemove = 0;
			iterator++;
			maxAreaRectangle = new Rectangle(0,0);
		}
	}
	
	/**
	 * Creates the composite blocks.
	 */
	//As composite blocks are created, modules are removed from the sorted list 
	public void createCompositeBlocks() {
		if(listOfCompositeBlocks.isEmpty()){
			Rectangle first = listOfSortedModulesDescendingArea.get(0);
			listOfSortedModulesDescendingArea.remove(0);
			Rectangle second = listOfSortedModulesDescendingArea.get(0);
			listOfSortedModulesDescendingArea.remove(0);

			Rectangle compositeBlockSide = new Rectangle();
			compositeBlockSide.setHeight(Math.max(first.getHeight(), second.getHeight()));
			compositeBlockSide.setWidth(first.getWidth() + second.getWidth());

			Rectangle compositeBlockTop = new Rectangle();
			compositeBlockTop.setHeight(first.getHeight() + second.getHeight());
			compositeBlockTop.setWidth(Math.max(first.getWidth(), second.getWidth()));

			listOfCompositeBlocks.add(compositeBlockSide);
			listOfCompositeBlocks.add(compositeBlockTop);
			
			
		} else {
			Rectangle next = listOfSortedModulesDescendingArea.get(0);
			listOfSortedModulesDescendingArea.remove(0);
			ArrayList<Rectangle> listOfAuxCompositeBlocks = new ArrayList<>();
			for(int i = 0; i < listOfCompositeBlocks.size(); i++) {
				Rectangle compositeBlockSide = new Rectangle();
				compositeBlockSide.setHeight(Math.max(next.getHeight(), listOfCompositeBlocks.get(i).getHeight()));
				compositeBlockSide.setWidth(next.getWidth() + listOfCompositeBlocks.get(i).getWidth());

				Rectangle compositeBlockTop = new Rectangle();
				compositeBlockTop.setHeight(next.getHeight() + listOfCompositeBlocks.get(i).getHeight());
				compositeBlockTop.setWidth(Math.max(next.getWidth(), listOfCompositeBlocks.get(i).getWidth()));

				listOfAuxCompositeBlocks.add(compositeBlockSide);
				listOfAuxCompositeBlocks.add(compositeBlockTop);
			}

			listOfCompositeBlocks.clear();
			listOfCompositeBlocks = listOfAuxCompositeBlocks;
		}
		
		//verificar qual o menor composite block
		Rectangle compositeBlockMinArea = new Rectangle();
		compositeBlockMinArea = listOfCompositeBlocks.get(0);
		for(int i = 1; i < listOfCompositeBlocks.size(); i++) {
			double currentArea = listOfCompositeBlocks.get(i).getHeight() * listOfCompositeBlocks.get(i).getWidth();
			if((compositeBlockMinArea.getHeight() * compositeBlockMinArea.getWidth()) > currentArea) {
				compositeBlockMinArea = listOfCompositeBlocks.get(i);
			}
		}
		listOfCompositeBlocks.clear();
		listOfCompositeBlocks.add(compositeBlockMinArea);
	}
	
	/**
	 * Compute cn.
	 */
	public void computeCn() {
		if(numOfModules % 4 == 0) {
			Cn = numOfModules/4;
		} else {
			if (numOfModules % 4 == 3) {
				Cn = numOfModules/4 + 3;
			} else {
				if(numOfModules % 4 == 2) {
					Cn = numOfModules/4 + 2;
				} else {
					if(numOfModules % 4 == 1) {
						Cn = numOfModules/4 + 1;
					}
				}
			}
		}
	}
	
	/**
	 * Calculate fitness.
	 *
	 * @param objectiveFunction the objective function
	 */
	public void calculateFitness(String objectiveFunction) {
		if(objectiveFunction == "�rea") {
			fitness = listOfSortedModulesDescendingArea.get(listOfSortedModulesDescendingArea.size() - 1).getHeight() * 
				      listOfSortedModulesDescendingArea.get(listOfSortedModulesDescendingArea.size() - 1).getWidth();
		} else {
			if(objectiveFunction == "Semiper�metro") {
				fitness = Math.pow(listOfSortedModulesDescendingArea.get(listOfSortedModulesDescendingArea.size() - 1).getHeight(),2) + 
					      Math.pow(listOfSortedModulesDescendingArea.get(listOfSortedModulesDescendingArea.size() - 1).getWidth(),2);
			}
		}
	}
	
	/**
	 * Gets the list of modules.
	 *
	 * @return the list of modules
	 */
	public ArrayList<Rectangle> getListOfModules() {
		return listOfModules;
	}
	
	/**
	 * Gets the num of modules.
	 *
	 * @return the num of modules
	 */
	public int getNumOfModules() {
		return numOfModules;
	}
	
	/**
	 * Gets the list of composite blocks.
	 *
	 * @return the list of composite blocks
	 */
	public ArrayList<Rectangle> getListOfCompositeBlocks() {
		return listOfCompositeBlocks;
	}
	
	/**
	 * Gets the fitness.
	 *
	 * @return the fitness
	 */
	public double getFitness() {
		return fitness;
	}
}
