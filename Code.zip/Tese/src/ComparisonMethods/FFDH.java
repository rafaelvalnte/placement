package ComparisonMethods;
import java.util.ArrayList;

import NewApproach.Rectangle;


/**
 * The Class FFDH.
 */
public class FFDH {
	
	/** The final height. */
	private double finalHeight;
	
	/** The final width. */
	private double finalWidth;
	
	/** The list of widths per level. */
	private ArrayList<Double> listOfWidthsPerLevel; //this lists will be used to compare each width per level to know which level's width is the largest
	
	/** The curr width. */
	private double currWidth;
	/** The list of sorted rectangles. */
	private ArrayList<Rectangle> listOfSortedRectangles;
	
	/** The fitness. */
	private double fitness;

	
	/**
	 * Instantiates a new ffdh.
	 *
	 * @param maxWidth the max width
	 * @param listOfRectangles the list of rectangles
	 */
	//constructor for the Bottom-Left Fill heuristic		
	public FFDH(double maxWidth, ArrayList<Rectangle> listOfRectangles) {
				
		//initializations
		listOfSortedRectangles = new ArrayList<>();
		listOfWidthsPerLevel = new ArrayList<>();
		finalHeight = 0;
		finalWidth = 0;
		currWidth = 0;
		
		//sort list of rectangles by non-increasing height
		sort(listOfRectangles);
		
		//start of the cycle
		for(int i = 0; i < listOfSortedRectangles.size(); i++){
			
			//as the list is sorted by non-increasing height, the first element defines the height of the current level
			if(i==0) {
				finalHeight += listOfSortedRectangles.get(i).getHeight();
			}
			//if the current width inside the bin plus the width of the rectangle
			//to place is larger than the maximum width then the current rectangle will be placed
			//on top of the previous highest rectangle
			if(currWidth + listOfSortedRectangles.get(i).getWidth() > maxWidth) {
				finalHeight += listOfSortedRectangles.get(i).getHeight();
				listOfWidthsPerLevel.add(currWidth);
				currWidth = listOfSortedRectangles.get(i).getWidth();
			} else {
				currWidth += listOfSortedRectangles.get(i).getWidth();
			}
		}
		
		//cycle to discover the largest width
		for(int j = 0; j < listOfWidthsPerLevel.size(); j++) {
			if(finalWidth <= listOfWidthsPerLevel.get(j)) {
				finalWidth = listOfWidthsPerLevel.get(j);
			}	
		}
	
	}

	/**
	 * Instantiates a new ffdh.
	 */
	public FFDH() {
		listOfSortedRectangles = new ArrayList<>();
	}

	/**
	 * Sort.
	 *
	 * @param listOfRectangles the list of rectangles
	 */
	//sorts an array list of rectangles by non-increasing heigth
	@SuppressWarnings("unchecked")
	public void sort(ArrayList<Rectangle> listOfRectangles) {
		ArrayList<Rectangle> listOfAuxRectangles = new ArrayList<>();
		listOfAuxRectangles = (ArrayList<Rectangle>) listOfRectangles.clone();
		Rectangle maxHeightRectangle = new Rectangle();
		
		int length = listOfAuxRectangles.size();
		int iterator = 0;
		int indexOfRectangleToRemove = 0;
		
		while(iterator < length){
			for(int i = 0; i< listOfAuxRectangles.size(); i++) {
				if(listOfAuxRectangles.get(i).getHeight() > maxHeightRectangle.getHeight()) {
					maxHeightRectangle = listOfAuxRectangles.get(i);
					indexOfRectangleToRemove = i;
				}
			}
			
			//adds the current rectangle with larger height to the sorted list
			listOfSortedRectangles.add(maxHeightRectangle);
			
			//removes the rectangle with larger height from the original array
			listOfAuxRectangles.remove(indexOfRectangleToRemove);
			
			indexOfRectangleToRemove = 0;
			iterator++;
			maxHeightRectangle = new Rectangle(0,0);
		}
		
	}
	
	/**
	 * Gets the FFD hfitness.
	 *
	 * @return the FFD hfitness
	 */
	public double getFFDHfitness() {
		return fitness;
	}

	/**
	 * Sets the FFD hfitness.
	 *
	 * @param objectiveFunction the new FFD hfitness
	 */
	public void setFFDHfitness(String objectiveFunction) {
		if(objectiveFunction == "�rea") {
			fitness = finalHeight * finalWidth;
		} else {
			if(objectiveFunction == "Semiper�metro") {
				fitness = Math.pow(finalHeight,2) + Math.pow(finalWidth, 2);
			}
		}
	}
	
	/**
	 * Gets the list of sorted rectangles.
	 *
	 * @return the list of sorted rectangles
	 */
	public ArrayList<Rectangle> getListOfSortedRectangles() {
		return listOfSortedRectangles;
	}
	
	/**
	 * Gets the final height.
	 *
	 * @return the final height
	 */
	public double getFinalHeight() {
		return finalHeight;
	}

	/**
	 * Gets the final width.
	 *
	 * @return the final width
	 */
	public double getFinalWidth() {
		return finalWidth;
	}
	
}
