package ComparisonMethods;
import java.awt.Point;
import java.util.ArrayList;

import NewApproach.Rectangle;


/**
 * The Class BLF.
 */
public class BLF {

	/** The x. */
	private ArrayList<Double> x;
	
	/** The y. */
	private ArrayList<Double> y;
	
	/** The list of points. */
	private ArrayList<Point> listOfPoints;
	
	/** The list of sorted rectangles. */
	private ArrayList<Rectangle> listOfSortedRectangles;
	
	/** The choose point. */
	private Point choosePoint;
	
	/** The final height. */
	private int finalHeight;
	
	/** The final width. */
	private int finalWidth;
	
	/** The fitness. */
	private double fitness;
	
	/** The has unplaced items. */
	private boolean hasUnplacedItems;
	
	/**
	 * Instantiates a new blf.
	 *
	 * @param listOfRectangles the list of rectangles
	 * @param maxWidth the max width
	 */
	//procedure BLF (article 1210.4502) start
	public BLF(ArrayList<Rectangle> listOfRectangles, double maxWidth){
		listOfSortedRectangles = new ArrayList<>();
		listOfPoints = new ArrayList<>();
		sort(listOfRectangles);
		
		finalHeight = 0;
		finalWidth = 0;
		hasUnplacedItems = false;
		
		//initialize the arrays x and y
		x = new ArrayList<>();
		y = new ArrayList<>();		
		
		//initialize the list and add the null point
		listOfPoints.add(new Point(0,0));
		
		//for all rectangles
		for(int j = 0; j < listOfSortedRectangles.size(); j++) {
			Rectangle currRectangle = listOfSortedRectangles.get(j);
			//initialize choosePoint as impossible
			choosePoint = null;
			//while choosePoint is impossible
			while(choosePoint == null) {
				for(int i = 0; i < listOfPoints.size(); i++) {
					//if the rectangle could be placed in a specific point
					if(listOfPoints.get(i).getX() + currRectangle.getWidth() <= maxWidth){
						//choose the point
						choosePoint = new Point();
						choosePoint.setLocation(listOfPoints.get(i).getX(), listOfPoints.get(i).getY());
						break;
					}
				}
				break;
			}
			//if choosePoint is possible
			if(choosePoint != null) {
				//update the arrays x and y
				x.add(choosePoint.getX());
				y.add(choosePoint.getY());
				//remove the point from the position choosePoint from list
				listOfPoints.remove(choosePoint);
				//add the points (xi+width,yi),(xi,yi+height) to the points list
				Point currRectangle_Width = new Point();
				currRectangle_Width.setLocation(choosePoint.getX() + currRectangle.getWidth(), choosePoint.getY());
				listOfPoints.add(currRectangle_Width);
				Point currRectangle_Height = new Point();
				currRectangle_Height.setLocation(choosePoint.getX(), choosePoint.getY() + currRectangle.getHeight());
				listOfPoints.add(currRectangle_Height);	
			} else {
				//if (width > maxWidth) the problem has no solution
				if(currRectangle.getWidth() > maxWidth) {
					hasUnplacedItems = true;
				} else {
					Point newLevelPoint = new Point();
					//else xi = 0 and yi = max(heightk + yk) where k e (1, . . . , i − 1)
					newLevelPoint.setLocation(0,(listOfSortedRectangles.get(j-1).getWidth() + y.get(y.size()-1).intValue()));
					listOfPoints.add(newLevelPoint);
				}
				
			}
			
		}
		
		findFinalHeight();
		findFinalWidth();
	}
	
	/**
	 * Sort.
	 *
	 * @param listOfRectangles the list of rectangles
	 */
	//sorts an array list of rectangles by decreasing width
	@SuppressWarnings("unchecked")
	public void sort(ArrayList<Rectangle> listOfRectangles) {
		ArrayList<Rectangle> listOfAuxRectangles = new ArrayList<>();
		listOfAuxRectangles = (ArrayList<Rectangle>) listOfRectangles.clone();
		Rectangle maxWidthRectangle = new Rectangle();
		
		int length = listOfAuxRectangles.size();
		int iterator = 0;
		int indexOfRectangleToRemove = 0;
		
		while(iterator < length){
			for(int i = 0; i< listOfAuxRectangles.size(); i++) {
				if(listOfAuxRectangles.get(i).getWidth() > maxWidthRectangle.getWidth()) {
					maxWidthRectangle = listOfAuxRectangles.get(i);
					indexOfRectangleToRemove = i;
				}
			}
			
			//adds the current rectangle with larger width to the sorted list
			listOfSortedRectangles.add(maxWidthRectangle);
			
			//removes the rectangle with larger width from the original array
			listOfAuxRectangles.remove(indexOfRectangleToRemove);
			
			indexOfRectangleToRemove = 0;
			iterator++;
			maxWidthRectangle = new Rectangle(0,0);
		}
	}
	
	/**
	 * Find final width.
	 */
	public void findFinalWidth() {
		for(int i = 0; i < listOfPoints.size(); i++) {
			if(listOfPoints.get(i).getX() > finalWidth) {
				finalWidth = (int)listOfPoints.get(i).getX();
			}
		}
	}

	/**
	 * Find final height.
	 */
	public void findFinalHeight() {
		for(int i = 0; i < listOfPoints.size(); i++) {
			if(listOfPoints.get(i).getY() > finalHeight) {
				finalHeight = (int)listOfPoints.get(i).getY();
			}
		}
	}
	
	/**
	 * Gets the list of sorted rectangles.
	 *
	 * @return the list of sorted rectangles
	 */
	public ArrayList<Rectangle> getListOfSortedRectangles() {
		return listOfSortedRectangles;
	}
	
	/**
	 * Gets the BLF fitness.
	 *
	 * @return the BLF fitness
	 */
	public double getBLFfitness(){
		return fitness;
	}
	
	/**
	 * Sets the BLF fitness.
	 *
	 * @param objectiveFunction the new BLF fitness
	 */
	public void setBLFfitness(String objectiveFunction) {
		if(objectiveFunction == "Área") {
			fitness = finalHeight * finalWidth;
		} else {
			if(objectiveFunction == "Semiperímetro") {
				fitness = Math.pow(finalHeight,2) + Math.pow(finalWidth, 2);
			}
		}
	}
	
	/**
	 * Checks for unplaced items.
	 *
	 * @return true, if successful
	 */
	public boolean hasUnplacedItems() {
		return hasUnplacedItems;
	}
	
}
