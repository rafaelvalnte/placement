package ComparisonMethods;
import java.util.ArrayList;

import NewApproach.Cromossoma;
import NewApproach.Rectangle;


// TODO: Auto-generated Javadoc
/**
 * The Class GA_BLF.
 */
public class GA_BLF {
	
	/** The best initial fitness. */
	private double bestInitialFitness;
	
	/** The population. */
	private ArrayList<Cromossoma> population;
	
	/** The list rectangles. */
	private ArrayList<Rectangle> listRectangles;
	
	/** The Constant numberOfRectangles. */
	private static final int numberOfRectangles = 10; //o teste de dimens�es controladas s� conta quando o n�mero de ret�ngulos � 10 
	
	/** The Constant numberOfCuts. */
	private static final int numberOfCuts = numberOfRectangles - 1;
	
	/** The Constant mutationProb. */
	private static final double mutationProb = 0.02; //decidir qual a probabilidade de muta��o da componente do cromossoma
	
	/** The number of chromossomes. */
	private final int numberOfChromossomes = 50;
	
	/** The blf. */
	private BLF blf;
	
	/** The max width. */
	private int maxWidth;

	/**
	 * Instantiates a new ga blf.
	 *
	 * @param listOfRectangles the list of rectangles
	 * @param maxWidth the max width
	 */
	public GA_BLF(ArrayList<Rectangle> listOfRectangles, int maxWidth) {
		listRectangles = listOfRectangles;
		this.maxWidth = maxWidth;
		setFitness();
	}
	
	/**
	 * Crossover G A BLF.
	 */
	public void crossoverGA_BLF() {
		ArrayList<Cromossoma> newGenome = new ArrayList<>();
		for (int i=0; i<(numberOfChromossomes/2); i++) {
			int cont = 0;
			int contador = 0;
			int rectanglesCopied = 0;
			int father = (int)(Math.random()*numberOfChromossomes);
			int mother = (int)(Math.random()*numberOfChromossomes);
			int crossPoint = (int)(Math.random()*(numberOfRectangles+numberOfCuts));
			Cromossoma fatherCrom = population.get(father);
			Cromossoma motherCrom = population.get(mother);
			Cromossoma filho = new Cromossoma();
			ArrayList<Rectangle> listAuxRect = new ArrayList<>();
			for (int j=0; j<listRectangles.size();j++) {
				listAuxRect.add(listRectangles.get(j));
			}
			if(crossPoint<numberOfCuts) { //se o �ndice do crossover for inferior ao n�mero de cortes
				while(cont<crossPoint) {
					filho.getCromossoma().add(fatherCrom.getCromossoma().get(cont));
					cont++;
				}
				while(cont<motherCrom.getCromossoma().size()) {
					filho.getCromossoma().add(motherCrom.getCromossoma().get(cont));
					cont++;
				}
			} else {
				while(cont<crossPoint) {
					filho.getCromossoma().add(fatherCrom.getCromossoma().get(cont));
					if(cont >= numberOfCuts) {
						Rectangle comp = fatherCrom.getCromossoma().get(cont);
						listAuxRect.remove(comp);
						rectanglesCopied++;	
					}
					cont++;
					
				}
				while(contador < (numberOfRectangles-rectanglesCopied)) {
					filho.getCromossoma().add(listAuxRect.get(contador));
					contador++;
				}
			}
		}
	}
	
	/**
	 * Mutation G A BLF.
	 *
	 * @param filho the filho
	 * @param newGenome the new genome
	 */
	public void mutationGA_BLF(Cromossoma filho, ArrayList<Cromossoma> newGenome) {
		boolean allow = false;
		double mutProb = Math.random();
		if(mutProb <= mutationProb) {
			allow = true;
			boolean last = false; // boolean para saber se o �ndice random vai ser o �ndice do �ltimo rect�ngulo do cromossoma
			int mut = (int)(Math.random()*(numberOfCuts+numberOfRectangles));
			Cromossoma novoFilho = new Cromossoma();
			int a = 0;
			if(mut == (filho.getCromossoma().size()-1)) { // para trocar o �ltimo rect�ngulo com o primeiro
				last = true;
			}
			while (a < mut && !last) {
				novoFilho.getCromossoma().add(filho.getCromossoma().get(a));
				a++;
			}
			if(mut<numberOfCuts) { //cortes
				if (filho.getCromossoma().get(mut).getTipo() == "V") {
					Rectangle horizontal = new Rectangle();
					horizontal.setCut(true);
					horizontal.setTipo("H");
					novoFilho.getCromossoma().add(horizontal);
				} else {
					Rectangle vertical = new Rectangle();
					vertical.setCut(true);
					vertical.setTipo("V");
					novoFilho.getCromossoma().add(vertical);
				}
				mut++;
				while (mut < filho.getCromossoma().size()) {
					novoFilho.getCromossoma().add(filho.getCromossoma().get(mut));
					mut++;
				}
			} else { //rect�ngulos
				if (last) {
					int b = 0;
					while (b<numberOfCuts) {
						novoFilho.getCromossoma().add(filho.getCromossoma().get(b));
						b++;
					}
					b++; 
					Rectangle firstOfRectangles = filho.getCromossoma().get(numberOfCuts);
					Rectangle lastOfRectangles = filho.getCromossoma().get(filho.getCromossoma().size()-1);
					novoFilho.getCromossoma().add(lastOfRectangles);
					while (b<(filho.getCromossoma().size()-1)) {
						novoFilho.getCromossoma().add(filho.getCromossoma().get(b));
						b++;
					}
					novoFilho.getCromossoma().add(firstOfRectangles);
				} else { //se mut n�o apontar para o �ltimo rect�ngulo do cromossoma
					Rectangle firstToSwap = filho.getCromossoma().get(mut);
					Rectangle lastToSwap = filho.getCromossoma().get(mut+1);
					novoFilho.getCromossoma().add(lastToSwap);
					novoFilho.getCromossoma().add(firstToSwap);
					a = a+2;
					while (a < filho.getCromossoma().size()) {
						novoFilho.getCromossoma().add(filho.getCromossoma().get(a));
						a++;
					}
				}
			}	
		}
		if(!allow) {
			newGenome.add(filho);
		}
	}
	
	/**
	 * Sets the fitness.
	 */
	public void setFitness() {
		blf = new BLF(listRectangles, maxWidth);
		
	}
}
