package ComparisonMethods;

import java.util.ArrayList;

import NewApproach.Rectangle;

// TODO: Auto-generated Javadoc
/**
 * The Class BottomUpVLSI_teste.
 */
public class BottomUpVLSI_teste {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		Rectangle a = new Rectangle(25,20);
		Rectangle b = new Rectangle(15,40);
		Rectangle c = new Rectangle(35,25);
		Rectangle d = new Rectangle(30,10);
		Rectangle e = new Rectangle(50,50);
		ArrayList<Rectangle> list = new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		list.add(e);
		BottomUpVLSI buVLSI = new BottomUpVLSI(list);
	}

}
